package com.tyche.fuelmaps;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.ClusterManager;

public class ClusterManagerItem implements ClusterItem {

    private LatLng mPosition;
    private String mTitle = null;
    private String mSnippet = null;

    public ClusterManagerItem(LatLng latlng) {
        this.mPosition = latlng;
    }

    public ClusterManagerItem(LatLng latlng, String title, String snippet) {
        this.mPosition = latlng;
        this.mTitle = title;
        this.mSnippet = snippet;
    }

    @NonNull
    @Override
    public LatLng getPosition() {
        return mPosition;
    }

    @Nullable
    @Override
    public String getTitle() {
        return mTitle;
    }

    @Nullable
    @Override
    public String getSnippet() {
        return mSnippet;
    }
}
