package com.tyche.fuelmaps;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.squareup.picasso.Picasso;

public class ProfileInfoActivity extends AppCompatActivity {

    // Variables

        // Local
            ImageView profile_image;
            TextView user_name;
            TextView user_email;

        // Google
            GoogleSignInAccount account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_info);

        // Get Profile Image
        profile_image = (ImageView) findViewById(R.id.profile_image);

        user_email = (TextView) findViewById(R.id.user_email);

        user_name = (TextView) findViewById(R.id.user_name);

        // Get Current Signed In Account
        account = GoogleSignIn.getLastSignedInAccount(this);

        Picasso.get().load(account.getPhotoUrl()).placeholder(R.mipmap.ic_launcher).into(profile_image);

        user_name.setText(account.getDisplayName());

        user_email.setText(account.getEmail());
    }
}
