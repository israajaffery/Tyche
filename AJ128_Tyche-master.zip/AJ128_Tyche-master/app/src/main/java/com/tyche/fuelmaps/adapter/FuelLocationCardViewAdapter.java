package com.tyche.fuelmaps.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.tyche.fuelmaps.GetDirectionData;
import com.tyche.fuelmaps.models.Model;
import com.tyche.fuelmaps.R;

import java.text.DecimalFormat;
import java.util.List;

public class FuelLocationCardViewAdapter extends RecyclerView.Adapter<FuelLocationCardViewAdapter.FuelLocationCardViewAdapterViewHolder> {

    private List<Model> modelList;
    String TAG = "Fuel Maps";
    String TAG2 = "FuelLocationCardViewAdapter Class";
    CoordinatorLayout coordinatorLayout;
    Context context;
    int positionTemp;
    BottomSheetBehavior behavior;
    CoordinatorLayout fuelPumpDetails;
    DecimalFormat df = new DecimalFormat("0.00");
    ViewPager2 fuelLocationPager;
    GoogleMap mMap;
    LatLng currentLocation;
    List<Marker> markers;
    ViewGroup parent;


    public FuelLocationCardViewAdapter(List<Model> models, CoordinatorLayout coordinatorLayout, Context context, BottomSheetBehavior behavior, CoordinatorLayout fuelPumpDetails, ViewPager2 fuelLocationPager, GoogleMap mMap, LatLng currentLocation, List<Marker> markers, ViewGroup parent) {

        Log.d(TAG, "FuelLocationCardViewAdapter: " + TAG2 + " Object Created");

        this.modelList = models;
        this.coordinatorLayout = coordinatorLayout;
        this.context = context;
        this.behavior = behavior;
        this.fuelPumpDetails = fuelPumpDetails;
        this.fuelLocationPager = fuelLocationPager;
        this.mMap = mMap;
        this.currentLocation = currentLocation;
        this.markers = markers;
        this.parent = parent;
    }

    @NonNull
    @Override
    public FuelLocationCardViewAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FuelLocationCardViewAdapterViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.fuel_location_card_view_item,
                        parent,
                        false
                )
        );
    }

    private void setCoordinatorLayout() {
        TranslateAnimation translateAnimation = new TranslateAnimation(0,0,650,0);
        translateAnimation.setDuration(500);
        translateAnimation.setFillAfter(true);
        coordinatorLayout.startAnimation(translateAnimation);
    }

    @Override
    public void onBindViewHolder(@NonNull FuelLocationCardViewAdapterViewHolder holder,int position) {
        holder.setPetrolPumpData(modelList.get(position));
        holder.listViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(context, "List Button Clicked", Toast.LENGTH_SHORT).show();
                if (coordinatorLayout.getVisibility() == View.GONE) {
                    coordinatorLayout.setVisibility(View.VISIBLE);
                    TranslateAnimation translateAnimation = new TranslateAnimation(0, 0, 650, 0);
                    translateAnimation.setDuration(500);
                    translateAnimation.setFillAfter(true);
                    coordinatorLayout.startAnimation(translateAnimation);
                    behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                } else if (behavior.getState() == BottomSheetBehavior.STATE_HIDDEN) {
                    behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                }
            }
        });
        positionTemp = position;
        holder.petrolPumpName.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if (fuelPumpDetails.getVisibility() == View.GONE) {
                    fuelPumpDetails.setVisibility(View.VISIBLE);
                }
                ImageButton directions = (ImageButton) fuelPumpDetails.findViewById(R.id.fuel_pump_details_directions);
                directions.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int post = fuelLocationPager.getCurrentItem();
                        LatLng destination = modelList.get(post).getLatLng();

                        Object[] dataTransfer = new Object[5];
                        dataTransfer[0] = currentLocation;
                        dataTransfer[1] = destination;
                        dataTransfer[2] = mMap;
                        dataTransfer[3] = markers;
                        dataTransfer[4] = parent;

                        GetDirectionData getDirectionData = new GetDirectionData();
                        getDirectionData.execute(dataTransfer);
                    }
                });
                BottomSheetBehavior behavior;
                CoordinatorLayout coordinatorLayout = fuelPumpDetails.findViewById(R.id.fuel_pump_details);
                View bottomSheet = coordinatorLayout.findViewById(R.id.fuel_pump_details_page_bottom_slider);
                behavior = BottomSheetBehavior.from(bottomSheet);
                if (behavior.getState() == BottomSheetBehavior.STATE_HIDDEN) {
                    behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
                behavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                    @Override
                    public void onStateChanged(@NonNull View bottomSheet, int newState) {
                        if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                            fuelPumpDetails.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                    }
                });

            }
        });
        holder.directions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int post = fuelLocationPager.getCurrentItem();
                LatLng destination = modelList.get(post).getLatLng();

                Object[] dataTransfer = new Object[5];
                dataTransfer[0] = currentLocation;
                dataTransfer[1] = destination;
                dataTransfer[2] = mMap;
                dataTransfer[3] = markers;
                dataTransfer[4] = parent;

                GetDirectionData getDirectionData = new GetDirectionData();
                getDirectionData.execute(dataTransfer);
            }
        });
    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    class FuelLocationCardViewAdapterViewHolder extends RecyclerView.ViewHolder {

        ImageView petrolPumpImage;
        TextView petrolPumpName, locationType, petrolPumpAddress, distance;
        ImageButton listViewButton, directions;
        float rating;
        RatingBar ratingBar;

        FuelLocationCardViewAdapterViewHolder(@NonNull View itemView) {
            super(itemView);

            petrolPumpImage = itemView.findViewById(R.id.petrol_pump_image);
            petrolPumpName = itemView.findViewById(R.id.petrol_pump_name);
            locationType = itemView.findViewById(R.id.location_type);
            petrolPumpAddress = itemView.findViewById(R.id.petrol_pump_address);
            distance = itemView.findViewById(R.id.fuel_locations_card_distance);
            ratingBar = itemView.findViewById(R.id.ratingBar);
            listViewButton = itemView.findViewById(R.id.list_view_button);
            directions = itemView.findViewById(R.id.directions);
        }

        @SuppressLint("SetTextI18n")
        void setPetrolPumpData(Model model) {
            petrolPumpImage.setImageResource(R.drawable.ic_background_red_can);
            petrolPumpName.setText(model.getPetrol_pump_name());
            locationType.setText(model.getLocation_type());
            petrolPumpAddress.setText(model.getAddress());
            distance.setText("Distance : " + df.format(model.getDistance()/1000) + " KM");
            ratingBar.setRating(Float.parseFloat(model.getRating()));
            if (model.getPetrol_pump_name().contains("HP")
                    || model.getPetrol_pump_name().contains("HP Petrol Pump")
                    || model.getPetrol_pump_name().contains("Hindustan")
                    || model.getPetrol_pump_name().contains("Hindustance Petroleum")
                    || model.getPetrol_pump_name().contains("HP PETROL PUMP")
                    || model.getPetrol_pump_name().contains("hp")
                    || model.getPetrol_pump_name().contains("hindustan")) {
                petrolPumpImage.setImageResource(R.drawable.ic_hindustan_petroleum);
            } else if (model.getPetrol_pump_name().contains("Indian Oil")
                    || model.getPetrol_pump_name().contains("Indian Oil Petrol Pump")
                    || model.getPetrol_pump_name().contains("Indian")
                    || model.getPetrol_pump_name().contains("Indian Oil Petroleum")
                    || model.getPetrol_pump_name().contains("INDIAN OIL PETROL PUMP")
                    || model.getPetrol_pump_name().contains("indian oil")
                    || model.getPetrol_pump_name().contains("indian")) {
                petrolPumpImage.setImageResource(R.drawable.ic_indian_oil);
            } else if (model.getPetrol_pump_name().contains("Bharat")
                    || model.getPetrol_pump_name().contains("Bharat Petroleum")
                    || model.getPetrol_pump_name().contains("Bharat Petrol Pump")
                    || model.getPetrol_pump_name().contains("bharat")
                    || model.getPetrol_pump_name().contains("bharat petrol pump")
                    || model.getPetrol_pump_name().contains("BHARAT PETROL PUMP")
                    || model.getPetrol_pump_name().contains("BHARAT PETROLEUM")) {
                petrolPumpImage.setImageResource(R.drawable.ic_bharat_petroleum);
            } else if (model.getPetrol_pump_name().contains("Shell")
                    || model.getPetrol_pump_name().contains("Shell Petrol Pump")
                    || model.getPetrol_pump_name().contains("Shell Petroleum")
                    || model.getPetrol_pump_name().contains("SHELL")
                    || model.getPetrol_pump_name().contains("SHELL PETROLEUM")
                    || model.getPetrol_pump_name().contains("shell")
                    || model.getPetrol_pump_name().contains("shell petroleum")) {
                petrolPumpImage.setImageResource(R.drawable.ic_shell);
            } else if (model.getPetrol_pump_name().contains("Essar")
                    || model.getPetrol_pump_name().contains("Essar Oil")
                    || model.getPetrol_pump_name().contains("Essar Petrol Pump")
                    || model.getPetrol_pump_name().contains("ESSAR")
                    || model.getPetrol_pump_name().contains("Essar Petroleum")
                    || model.getPetrol_pump_name().contains("essar")
                    || model.getPetrol_pump_name().contains("essar petroleum")) {
                petrolPumpImage.setImageResource(R.drawable.ic_essar_oil);
            } else if (model.getPetrol_pump_name().contains("Reliance")
                    || model.getPetrol_pump_name().contains("Reliance Petrol Pump")
                    || model.getPetrol_pump_name().contains("Reliance Petroleum")
                    || model.getPetrol_pump_name().contains("RELIANCE")
                    || model.getPetrol_pump_name().contains("RELIACNCE PETROL PUMP")
                    || model.getPetrol_pump_name().contains("reliance")
                    || model.getPetrol_pump_name().contains("reliance petrol pump")) {
                petrolPumpImage.setImageResource(R.drawable.ic_reliance_petroleum);
            } else {
                petrolPumpImage.setImageResource(R.drawable.ic_background_red_can);
            }
        }
    }
}
