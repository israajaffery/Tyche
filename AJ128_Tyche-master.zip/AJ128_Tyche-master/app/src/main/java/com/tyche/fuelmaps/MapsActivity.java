package com.tyche.fuelmaps;

import androidx.annotation.LongDef;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import androidx.viewpager2.widget.ViewPager2;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;
import com.tyche.fuelmaps.adapter.AutoCompleteRecyclerViewAdapter;
import com.tyche.fuelmaps.models.AutoCompleteModel;
import com.tyche.fuelmaps.models.Model;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MapsActivity extends FragmentActivity implements
        OnMapReadyCallback,
        GoogleMap.OnCameraMoveListener,
        GoogleMap.OnCameraMoveStartedListener,
        GoogleMap.OnCameraMoveCanceledListener,
        GoogleMap.OnCameraIdleListener {
    //private static final int PERMISSIONS_REQUEST_ENABLE_GPS = 9002;
    private static final String TAG = "Fuel Maps";
    private static final int PERMISSIONS_REQUEST_ACCESS_LOCATION = 1;
    public static final String CHANNEL_ID = "FuelMapsBackgroundService";

    // Variables

    // Local
    private Boolean locationPermissionGranted = false;
    private Boolean gpsState = false;
    //private Boolean exit = false;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    //private static final int DEFAULT_ZOOM = 15;
    private static final int REQUEST_CHECK_SETTINGS = 1;
    ImageView profile_image;
    Intent profile_info;
    Context context;
    ImageButton gpsLocateMe;
    ArrayList<String> selectedPumpPreferences;
    int PROXIMITY_RADIUS = 50000;
    double latitude;
    double longitude;
    ProgressBar progressBar;
    ViewPager2 fuelLocationPager;
    SeekBar radiusSeekBar;
    TextView seekBarValue;
    ImageButton seekBarMinimizeButton;
    ImageButton radiusSearchButton;
    ViewGroup parent;
    ConstraintLayout constraintLayout;
    View mOriginalContentView;
    ImageButton showNearByPetrolPumpsButton;
    boolean isViewPagerOut;
    CoordinatorLayout coordinatorLayout;
    BottomSheetBehavior behavior;
    CoordinatorLayout fuelPumpDetailsPageBottomSlider;
    ImageButton hamburgerMenuIcon;
    EditText searchTextView;
    ConstraintLayout searchBar;
    RecyclerView autocompleteRecyclerView;
    ConstraintLayout autocompleteRecyclerConstraint;
    int AUTOCOMPLETE_REQUEST_CODE = 1;
    ImageView autocompleteRecyclerViewSearchImage;
    TextView autocompleteRecyclerViewSearchText;
    CardView placeInfoCardView;
    ImageButton searchTextClearButton;
    boolean isPlaceInfoCardViewOut;
    ImageButton placeInfoPlaceGPSButton;
    AutoCompleteRecyclerViewAdapter autoCompleteRecyclerViewAdapter;
    BluetoothDevice mmDevice;
    InputStream mmInputStream;
    OutputStream mmOutputStream;
    Marker nearestPetrolPumpMarker;

    // Google
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    Location currentLocation;
    GoogleSignInAccount account;
    GoogleSignInOptions gso;
    GoogleSignInClient googleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        Log.d(TAG, "onCreate: Maps Activity");
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        searchBar = (ConstraintLayout) findViewById(R.id.search_bar);
        searchBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchTextView.performClick();
            }
        });

        autocompleteRecyclerViewSearchImage =
                findViewById(R.id.autocomplete_recycler_view_search_image);

        autocompleteRecyclerViewSearchText =
                findViewById(R.id.autocomplete_recycler_view_search_text);

        placeInfoCardView = findViewById(R.id.place_info_card_view);
        placeInfoCardView.setVisibility(View.GONE);

        searchTextClearButton = findViewById(R.id.search_text_clear_button);
        searchTextClearButton.setVisibility(View.GONE);

        fuelPumpDetailsPageBottomSlider = findViewById(R.id.fuel_pump_details);
        fuelPumpDetailsPageBottomSlider.setVisibility(View.GONE);
        View bottomSheet1 = fuelPumpDetailsPageBottomSlider.findViewById(R.id.fuel_pump_details_page_bottom_slider);
        behavior = BottomSheetBehavior.from(bottomSheet1);
        behavior.setState(BottomSheetBehavior.STATE_HIDDEN);

        autocompleteRecyclerConstraint = findViewById(R.id.autocomplete_constraint);
        autocompleteRecyclerConstraint.setVisibility(View.GONE);
        ConstraintLayout.LayoutParams lp =
                (ConstraintLayout.LayoutParams) autocompleteRecyclerConstraint.getLayoutParams();
        lp.height = convertDPtoPix(50);
        autocompleteRecyclerConstraint.setLayoutParams(lp);

        autocompleteRecyclerView = (RecyclerView) findViewById(R.id.autocomplete_recycler_view);
        autocompleteRecyclerView.setVisibility(View.GONE);

        fuelLocationPager = findViewById(R.id.fuel_locations_pager);
        fuelLocationPager.setVisibility(View.GONE);

        placeInfoPlaceGPSButton = findViewById(R.id.place_info_locate_place_button);
        placeInfoPlaceGPSButton.setVisibility(View.INVISIBLE);

        searchTextView = findViewById(R.id.search_text_view);
        searchTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (autocompleteRecyclerConstraint.getVisibility() == View.GONE) {
                    autocompleteRecyclerConstraint.setVisibility(View.VISIBLE);
                    slideView(autocompleteRecyclerConstraint, convertDPtoPix(50), convertDPtoPix(400),
                            250);
                }
                searchTextView.setFocusable(true);
                searchTextView.setFocusableInTouchMode(true);
                searchTextView.requestFocus();
                hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_arrow_back_ios_24);
                profile_image.setVisibility(View.INVISIBLE);
                searchTextClearButton.setVisibility(View.VISIBLE);

                if (autocompleteRecyclerView.getVisibility() == View.VISIBLE) {
                    autocompleteRecyclerView.setVisibility(View.INVISIBLE);
                }

                if (autocompleteRecyclerViewSearchImage.getVisibility() == View.INVISIBLE && autocompleteRecyclerViewSearchText.getVisibility() == View.INVISIBLE) {
                    autocompleteRecyclerViewSearchImage.setVisibility(View.VISIBLE);
                    autocompleteRecyclerViewSearchText.setVisibility(View.VISIBLE);
                }

                gpsLocateMe.setVisibility(View.INVISIBLE);
                showNearByPetrolPumpsButton.setVisibility(View.INVISIBLE);
                fuelLocationPager.setVisibility(View.GONE);
                radiusSearchButton.setVisibility(View.GONE);
                radiusSeekBar.setVisibility(View.GONE);
                ImageButton userPreference = (ImageButton) findViewById(R.id.user_preference_button);
                userPreference.setVisibility(View.GONE);

                Context context = getApplicationContext();
                InputMethodManager inputMethodManager =
                        (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);

                if (inputMethodManager != null) {
                    inputMethodManager.showSoftInput(searchTextView,
                            InputMethodManager.SHOW_IMPLICIT);
                }

                searchTextView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                            getPredictions(searchTextView.getText().toString());
                            return true;
                        }
                        return false;
                    }
                });

                searchTextView.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        String string = s.toString();
                        getPredictions(string);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });

                hamburgerMenuIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Context context = getApplicationContext();

                        mMap.clear();

                        hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);

                        searchTextView.clearFocus();

                        searchTextView.setText("");

                        searchTextView.setFocusableInTouchMode(false);
                        searchTextView.setFocusable(false);

                        gpsLocateMe.setVisibility(View.VISIBLE);
                        showNearByPetrolPumpsButton.setVisibility(View.VISIBLE);
                        fuelLocationPager.setVisibility(View.GONE);
                        radiusSearchButton.setVisibility(View.GONE);
                        radiusSeekBar.setVisibility(View.GONE);
                        ImageButton userPreference = (ImageButton) findViewById(R.id.user_preference_button);
                        userPreference.setVisibility(View.GONE);


                        if (autocompleteRecyclerConstraint.getVisibility() == View.VISIBLE) {
                            autocompleteRecyclerConstraint.setVisibility(View.GONE);
                            slideView(autocompleteRecyclerConstraint, convertDPtoPix(400),
                                    convertDPtoPix(50),
                                    250);
                        }

                        InputMethodManager imm =
                                (InputMethodManager) parent.getContext().getSystemService(Activity.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.hideSoftInputFromWindow(parent.getWindowToken(), 0);
                        }

                        ConstraintSet constraintSet = new ConstraintSet();
                        constraintSet.clone(constraintLayout);
                        constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM,
                                R.id.main_constraint,
                                ConstraintSet.BOTTOM);
                        constraintSet.applyTo(constraintLayout);

                        profile_image.setVisibility(View.VISIBLE);
                        searchTextClearButton.setVisibility(View.GONE);

                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()),17));

                        if (placeInfoCardView.getVisibility() == View.VISIBLE) {
                            TranslateAnimation translateAnimation = new TranslateAnimation(0,0,0,600);
                            translateAnimation.setDuration(300);
                            translateAnimation.setFillAfter(true);
                            translateAnimation.setInterpolator(getApplicationContext(), android.R.interpolator.linear);

                            placeInfoCardView.startAnimation(translateAnimation);

                            placeInfoCardView.setVisibility(View.GONE);
                        }

                        if (fuelLocationPager.getVisibility() == View.VISIBLE) {
                            fuelLocationPager.setVisibility(View.GONE);
                        }
                        //autocompleteRecyclerConstraint.setVisibility(View.GONE);
                    }
                });

                searchTextClearButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (searchTextView.getText().length() > 0) {
                            searchTextView.getText().clear();
                        } else {
                            hamburgerMenuIcon.performClick();
                        }
                    }
                });
            }
        });

        parent = (ViewGroup) findViewById(R.id.main_constraint);

        coordinatorLayout = findViewById(R.id.bottomSheetCoordinatorLayout);
        coordinatorLayout.setVisibility(View.GONE);

        seekBarMinimizeButton = (ImageButton) findViewById(R.id.seekbar_minimize_button);
        seekBarMinimizeButton.setVisibility(View.GONE);
        Log.d(TAG, "onCreate: Maps Activity: seekBarMinimizeButton.setVisibility(View.GONE)");

        radiusSearchButton = (ImageButton) findViewById(R.id.search_button_radius);
        radiusSearchButton.setVisibility(View.GONE);
        radiusSearchButton.setTranslationY(120);
        Log.d(TAG, "onCreate: Maps Activity: radiusSearchButton.setVisibility(View.GONE)");

        seekBarValue = (TextView) findViewById(R.id.seekBarValueText);
        seekBarValue.setVisibility(View.GONE);
        Log.d(TAG, "onCreate: Maps Activity: seekBarValue.setVisibility(View.GONE)");

        radiusSeekBar = (SeekBar) findViewById(R.id.radiusSeekBar);
        radiusSeekBar.setVisibility(View.GONE);
        Log.d(TAG, "onCreate: Maps Activity: radiusSeekBar.setVisibility(View.GONE)");

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        Log.d(TAG, "onCreate: Maps Activity: progressBar.setVisibility(View.GONE)");
        progressBar.setProgress(0);

        hamburgerMenuIcon = findViewById(R.id.hamburger_menu_icon);

        View bottomSheet = findViewById(R.id.bottomSheetBehaviour);
        behavior = BottomSheetBehavior.from(bottomSheet);

        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        context = this;
        // Get Profile Image
        getProfileImage();

        // To get nearby petrol pumps button
        showNearByPetrolPumpsButton = (ImageButton) findViewById(R.id.show_nearby_petrol_pumps);
        showNearByPetrolPumpsButton.setVisibility(View.GONE);
        showNearByPetrolPumpsButton.setTranslationY(120);
        showNearByPetrolPumpsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "ShowNearbyPetrolPumpsButton onClick: Maps Activity: Button Clicked");
                if (fuelLocationPager.getVisibility() == View.GONE) {
                    getNearbyPetrolPumps();
                } else {
                    Toast.makeText(getApplicationContext(), "Already Showing nearby petrol pumps!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        constraintLayout = (ConstraintLayout) findViewById(R.id.main_constraint);
        gpsLocateMe = findViewById(R.id.gps_locate_me_button);
        gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp);
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(constraintLayout);
        constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.main_constraint, ConstraintSet.BOTTOM);
        constraintSet.applyTo(constraintLayout);
        gpsLocateMe.setTranslationY(120);
        Log.d(TAG, "onCreate: Maps Activity: gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp)");
        gpsLocateMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick (gps Locate Me Button): Maps Activity: Clicked");

                ObjectAnimator rotate = ObjectAnimator.ofFloat(gpsLocateMe ,
                        "rotation", 0f, 360f);
                rotate.setDuration(1000);
                rotate.setInterpolator(new AccelerateDecelerateInterpolator());
                rotate.start();

                if (placeInfoCardView.getVisibility() == View.VISIBLE) {
                    placeInfoGPSBut();
                } else {
                    gpsLocateMeBut();
                }
            }
        });

        // To get shared pump preference
        getPumpPreferences();

        // Create fusedLocation Client Object
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (checkMapServices()) {
            gpsState = true;
        } else {
            getLocationPermission();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d(TAG, "onMapReady: Maps Activity");
        Toast.makeText(this, "Map is Ready!", Toast.LENGTH_SHORT).show();
        mMap = googleMap;
        mMap.getUiSettings().setMyLocationButtonEnabled(false);
        mMap.getUiSettings().setCompassEnabled(false);
        mMap.getUiSettings().setTiltGesturesEnabled(true);
        mMap.getUiSettings().setMapToolbarEnabled(true);
        mMap.getUiSettings().setAllGesturesEnabled(true);
        mMap.getUiSettings().setRotateGesturesEnabled(true);

        mMap.setOnCameraIdleListener(this);
        mMap.setOnCameraMoveStartedListener(this);
        mMap.setOnCameraMoveListener(this);
        mMap.setOnCameraMoveCanceledListener(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            getLocationPermission();
            return;
        }
        mMap.setMyLocationEnabled(true);

        mMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                if (gpsState) {
                    getCurrentLocation();
                }
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Maps Activity");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        int count;
        Log.d(TAG, "onBackPressed: Maps Activity: Back Pressed.");
        Toast.makeText(this, "Press back again to exit.", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Maps Activity");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Maps Activity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: Maps Activity");
    }

    // Local Methods

    // Get User Profile Image And onClickListener for same
    private void getProfileImage() {
        Log.d(TAG, "getProfileImage: Maps Activity: Called");
        // Get Current Signed In Account
        account = GoogleSignIn.getLastSignedInAccount(this);
        profile_image = findViewById(R.id.profile_image);
        profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick (Profile Image): Maps Activity: Set");
                //profile_info = new Intent("com.tyche.fuelmaps.profileinfo");
                //startActivity(profile_info);
                profileInfoDialog();
                Log.d(TAG, "onClick (Profile Image): Maps Activity: Intent ProfileInfo Activity");
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        if (account != null) {
            Log.d(TAG, "getProfileImage: Maps Activity: account != null");
            // Profile Image
            Picasso.get().load(account.getPhotoUrl()).placeholder(R.mipmap.ic_launcher).into(profile_image);
            Log.d(TAG, "getProfileImage: Maps Activity: Image Loaded");
        }
    }

    // Check If user has enabled GPS
    public boolean isMapsEnabled() {
        Log.d(TAG, "isMapsEnabled: Maps Activity: Called");
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        assert manager != null;
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Log.d(TAG, "isMapsEnabled: Maps Activity: GPS not turned on");
            gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp);
            Log.d(TAG, "isMapsEnabled: Maps Activity: gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp");
            buildAlertMessageNoGps();
            gpsState = false;
            Log.d(TAG, "isMapsEnabled: Maps Activity: gpsState = false");
            Log.d(TAG, "isMapsEnabled: Maps Activity: returned false");
            return false;
        }
        gpsLocateMe.setImageResource(R.drawable.ic_gps_not_fixed_black_24dp);
        Log.d(TAG, "isMapsEnabled: Maps Activity: gpsLocateMe.setImageResource(R.drawable.ic_gps_not_fixed_black_24dp);");
        gpsState = true;
        Log.d(TAG, "isMapsEnabled: Maps Activity: gpsState = true");
        Log.d(TAG, "isMapsEnabled: Maps Activity: returned true");
        return true;
    }

    // To check is maps are enabled
    private boolean checkMapServices() {
        Log.d(TAG, "checkMapServices: Maps Activity: Called");
        if (isMapsEnabled()) {
            Log.d(TAG, "checkMapServices: Maps Activity: returned true");
            return true;
        } else {
            Log.d(TAG, "checkMapServices: Maps Activity: returned false");
            return false;
        }
    }

    // Build Alert Message is user has not enabled GPS
    private void buildAlertMessageNoGps() {
        Log.d(TAG, "buildAlertMessageNoGps: Maps Activity: Called");
        final AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
        builder.setMessage("This application requires GPS to work properly, do you want to enable it?")
                .setTitle("Use Location Services?")
                .setCancelable(true)
                .setIcon(R.drawable.ic_gps_fixed_black_24dp)
                .setPositiveButton("Use Location Services", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Intent enableGpsIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        //startActivityForResult(enableGpsIntent, PERMISSIONS_REQUEST_ENABLE_GPS);
                        Log.d(TAG, "onClick (+ Button Alert Dialog): Maps Activity: Clicked");
                        dialog.cancel();
                        Log.d(TAG, "onClick (+ Button Alert Dialog): Maps Activity: dialog.cancel()");
                        createLocationRequest();
                    }
                })
                .setNegativeButton("Don't Use", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d(TAG, "onClick (- Button Alert Dialog): Maps Activity: Clicked");
                        Log.d(TAG, "onClick (- Button Alert Dialog): App Moved to background");
                        moveTaskToBack(true);
                    }
                })
                .create()
                .show();
        Log.d(TAG, "buildAlertMessageNoGps: Maps Activity: Alert Dialog Created");
        Log.d(TAG, "buildAlertMessageNoGps: Maps Activity: Alert Dialog Shown");
    }

    // To get current location of user
    private void getCurrentLocation() {
        Log.d(TAG, "getCurrentLocation: Maps Activity: Called");
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            getLocationPermission();
            return;
        }
        fusedLocationClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {
                if (task.isSuccessful()) {
                    Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: task successful");
                    Location location = task.getResult();
                    if (location != null) {
                        Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: location != null");
                        currentLocation = task.getResult();
                        Toast.makeText(getApplicationContext(), currentLocation.getLatitude()
                                + "" + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: Location Co-ord Toast Called");
                        Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: User Current Location: Long = " + currentLocation.getLongitude() + " lat = " + currentLocation.getLatitude());
                        moveCamera(currentLocation);
                        mMap.clear();
                        searchTextView.setText("");
                        hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);
                        showNearByPetrolPumpsButton.setVisibility(View.VISIBLE);
                        gpsLocateMe.setImageResource(R.drawable.ic_gps_fixed_black_24dp);
                        Intent intent = getIntent();
                        if (intent != null && intent.getAction() == "SHOW_POLYLINE") {
                            Log.d(TAG, "onMapReady: Intent Action == " + intent.getAction());
                            Bundle bundle = new Bundle();
                            bundle = getIntent().getExtras();
                            if (bundle != null) {

                                ArrayList<? extends Model> nearestPetrolPumpModelsList = intent.getParcelableArrayListExtra("model");
                                showNearestPetrolPump((PolylineOptions) bundle.getParcelable("polylineOptions"),
                                        (LatLng) bundle.getParcelable("destinationLatLng"),
                                        (String) bundle.getString("distance"),
                                        (String) bundle.getString("duration"),
                                        (String) bundle.getString("placeName"),
                                        (String) bundle.getString("placeAddress"),
                                        (String) bundle.getString("placeRating"),
                                        nearestPetrolPumpModelsList);

                            } else {
                                Log.d(TAG, "onMapReady: bundle == null");
                            }
                        } else {
                            createNotificationChannel();
                            startBackgroundService();
                        }
                        Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: gpsLocateMe.setImageResource(R.drawable.ic_gps_fixed_black_24dp)");
                    } else {
                        Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: location object == null");
                        //Toast.makeText(getApplicationContext(), "Location Object = Null!", Toast.LENGTH_SHORT).show();
                        Toast.makeText(getApplicationContext(), "Couldn't retrieve your location right now! Please try again!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: location object == null Toast Called");
                        buildAlertMessageNoGps();
                    }
                } else {
                    Log.d(TAG, "onComplete (getCurrentLocation): Maps Activity: task failed");
                    Toast.makeText(getApplicationContext(), "Couldn't retrieve your location right now! Please try again!", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "onComplete: (getCurrentLocation) Maps Activity: task failed toast called");
                    buildAlertMessageNoGps();
                }
            }
        });
    }

    // Move Camera to specified latlng
    private void moveCamera(Location location) {
        Log.d(TAG, "moveCamera: Maps Activity: Called");
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        Log.d(TAG, "moveCamera: Maps Activity: Location Passed: lat = " + latLng.latitude + " lon = " + latLng.longitude);
        if (fuelLocationPager.getVisibility() == View.VISIBLE) {
            mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12));
        } else {
            mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
        }
    }

    // Create Location Request
    private void createLocationRequest() {
        Log.d(TAG, "createLocationRequest: Maps Activity: Called");
        gpsLocateMe.setImageResource(R.drawable.ic_gps_not_fixed_black_24dp);
        // Create a location request to specify the requirement of the app (in ms)
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(500);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        Log.d(TAG, "createLocationRequest: Maps Activity: Current Location Request: Interval = " + locationRequest.getInterval() + " Fastest Interval = " + locationRequest.getFastestInterval() + " Priority = " + locationRequest.getPriority());

        // Checks the current location settings of user and builds the location request
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest);
        Log.d(TAG, "createLocationRequest: Maps Activity: LocationSettingRequest.builder created");

        // To Check Current Location Settings
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                // All location settings are satisfied.
                Log.d(TAG, "onSuccess (Settings Client): Maps Activity: Success: All Location Conditions Satisfied");
                gpsState = true;
                Log.d(TAG, "onSuccess (Settings Client): Maps Activity: gpsState = true");
            }
        });
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d(TAG, "onFailure (Settings Client): Maps Activity: Failure: Location Conditions are not Satisfied");
                if (e instanceof ResolvableApiException) {
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    try {
                        // Show the dialog by calling startResolutionForResult(),
                        // and check the result in onActivityResult().
                        Log.d(TAG, "onFailure (Settings Client): Maps Activity: Failure: show enable location dialog");
                        gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp);
                        Log.d(TAG, "onFailure (Settings Client): Maps Activity: Failure: try{} gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp)");
                        ResolvableApiException resolvable = (ResolvableApiException) e;
                        resolvable.startResolutionForResult(MapsActivity.this,
                                REQUEST_CHECK_SETTINGS);
                    } catch (IntentSender.SendIntentException sendEx) {
                        // Ignore the error.
                    }
                }
            }
        });
    }

    // Get Location Permission
    // To get location Permission
    private void getLocationPermission() {
        Log.d(TAG, "getLocationPermission: Maps Activity: Called");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_BACKGROUND_LOCATION};

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "getLocationPermission: Maps Activity: Location Permissions FINE Not Satisfied.");
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "getLocationPermission: Maps Activity: All Location Permissions Not Satisfied.");
                ActivityCompat.requestPermissions(this,
                        permissions,
                        PERMISSIONS_REQUEST_ACCESS_LOCATION);
            } else {
                Log.d(TAG, "getLocationPermission: Maps Activity: Location Permissions BACKGROUND Satisfied.");
                getCurrentLocation();
            }
        } else {
            Log.d(TAG, "getLocationPermission: Maps Activity: Location FINE Not Satisfied.");
            ActivityCompat.requestPermissions(this,
                    permissions,
                    PERMISSIONS_REQUEST_ACCESS_LOCATION);
        }
    }

    // To check user response to getLocationPermission
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult: Maps Activity: (Response to getLocationPermission)Called");
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_LOCATION: {
                if (grantResults.length > 0 &&
                        grantResults[0]
                                + grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "onRequestPermissionsResult: Maps Activity: (Response to getLocationPermission) All Location permission Granted");
                    locationPermissionGranted = true;
                } else {
                    Log.d(TAG, "onRequestPermissionsResult: Maps Activity: (Response to getLocationPermission) All Location Not Granted");
                    locationPermissionGranted = false;
                    permissionNotGranted();
                    Toast.makeText(this, "Permission Not Granted!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // Permission Not granted
    private void permissionNotGranted() {
        Log.d(TAG, "permissionNotGranted: Maps Activity: Called");
        if(ActivityCompat.shouldShowRequestPermissionRationale(MapsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                || ActivityCompat.shouldShowRequestPermissionRationale(MapsActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
            builder.setMessage(" Please allow the Location Permission for background location as the app needs to track you properly!");
            builder.setTitle("Permission Not Granted!");
            builder.setCancelable(false);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                    getLocationPermission();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    moveTaskToBack(true);
                }
            });
            builder.create();
            builder.show();
            Log.d(TAG, "permissionNotGranted: Maps Activity: Dialog Shown");
        } else {
            Log.d(TAG, "permissionNotGranted: Maps Activity: Asking Permission Manually");
            getLocationPermission();
        }
    }

    // Gps Locate Me Button Function
    private void gpsLocateMeBut() {
        Log.d(TAG, "gpsLocateMeBut: Maps Activity: Called");
        gpsLocateMe.setImageResource(R.drawable.ic_gps_not_fixed_black_24dp);
        Log.d(TAG, "gpsLocateMeBut: Maps Activity: gpsLocateMe.setImageResource(R.drawable.ic_gps_not_fixed_black_24dp)");
        if (checkMapServices()) {
            getCurrentLocation();
        } else {
            gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp);
            Log.d(TAG, "gpsLocateMeBut: Maps Activity: gpsLocateMe.setImageResource(R.drawable.ic_gps_off_black_24dp)");
        }
    }

    // Profile Info Dialog
    private void profileInfoDialog() {

        Log.d(TAG, "profileInfoDialog: Maps Activity: Called");
        
        final Dialog dialog = new Dialog(MapsActivity.this);
        dialog.setContentView(R.layout.profile_info_dialog);
        dialog.setCancelable(true);
        final ImageView profile_info_image = (ImageView) dialog.findViewById(R.id.profile_info_image);

        final TextView user_email = (TextView) dialog.findViewById(R.id.user_email);

        final TextView user_name = (TextView) dialog.findViewById(R.id.user_name);

        final Button signoOutSignIn = (Button) dialog.findViewById(R.id.sign_out_sign_in);

        if (account!= null) {
            signoOutSignIn.setText("Sign Out");
            signoOutSignIn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Log.d(TAG, "ProfileInfoDialogSignOutButton onClick: Maps Activity: Button Clicked");

                    googleSignInClient.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getApplicationContext(), "Signed Out!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MapsActivity.this, MapsActivity.class);
                            startActivity(intent);
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        }
                    });
                }
            });
            Picasso.get().load(account.getPhotoUrl()).placeholder(R.mipmap.ic_launcher).into(profile_info_image);
            user_name.setText(account.getDisplayName());
            user_email.setText(account.getEmail());
        } else {
            signoOutSignIn.setText("Sign In!");
            user_name.setText("Sign In Now!");
            user_email.setVisibility(View.INVISIBLE);
            signoOutSignIn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Log.d(TAG, "ProfileInfoDialogSignInButton onClick: Maps Activity: Button Clicked");

                    Intent intent = new Intent("com.tyche.fuelmaps.login");
                    startActivity(intent);

                    Log.d(TAG, "ProfileInfoDialogSignInButton onClick: Maps Activity: Intent to Login");
                }
            });
        }
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }

    // To get pump preferences from shared preferences
    private void getPumpPreferences() {

        Log.d(TAG, "getPumpPreferences: Maps Activity: Called");
        
        Gson gson = new Gson();
        SharedPreferences pumpPreference = getSharedPreferences("PUMP_PREFERENCES", MODE_PRIVATE);
        String json = pumpPreference.getString(getResources().getString(R.string.selected_pump_pref), null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        selectedPumpPreferences = gson.fromJson(json, type);

        Log.d(TAG, "getPumpPreferences: Maps Activity: Selected Pump Preference is: selectedPumpPreference = " + selectedPumpPreferences);
    }

    // To get nearbyPetrol pumps
    private void getNearbyPetrolPumps() {

        Log.d(TAG, "getNearbyPetrolPumps: Maps Activity: Called");
        
        mMap.clear();
        String petrolPumps = "gas_station";
        String url = getURL(currentLocation.getLatitude(), currentLocation.getLongitude(), petrolPumps, null);
        Log.d(TAG, "getNearbyPetrolPumps: URL = " + url);
        Object[] dataTransfer = new Object[12];
        dataTransfer[0] = mMap;
        dataTransfer[1] = url;

        Log.d(TAG, "getNearbyPetrolPumps: Maps Activity: url = " + url);

        LatLng latLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        dataTransfer[2] = latLng;
        dataTransfer[3] = progressBar;
        dataTransfer[4] = fuelLocationPager;
        dataTransfer[5] = context;
        dataTransfer[6] = radiusSeekBar;
        dataTransfer[7] = seekBarValue;
        dataTransfer[8] = seekBarMinimizeButton;
        dataTransfer[9] = parent;
        dataTransfer[10] = constraintLayout;
        Object[] dataTransferCopy = dataTransfer;
        dataTransfer[11] = dataTransferCopy;
        List<HashMap<String, String>> masterNearbyPlacesList;

        final GetNearbyPlacesData getNearbyPlacesData = new GetNearbyPlacesData();
        getNearbyPlacesData.execute(dataTransfer);

        progressBar.setVisibility(View.VISIBLE);
        TranslateAnimation translateAnimation = new TranslateAnimation(0,0,-120, 320);
        translateAnimation.setDuration(300);
        translateAnimation.setFillAfter(true);
        progressBar.startAnimation(translateAnimation);

        Log.d(TAG, "getNearbyPetrolPumps: Maps Activity: progressBar.setVisibility(View.VISIBLE)");

        Log.d(TAG, "getNearbyPetrolPumps: Maps Activity: CountDownTimer Started");

        CountDownTimer countDownTimer = new CountDownTimer(10000, 1000) {
            
            @Override
            public void onTick(long millisUntilFinished) {
                Log.d(TAG, "onTick: getNearbyPetrolPumps: Maps Activity: time passed = " + millisUntilFinished);
            }

            @Override
            public void onFinish() {

                Log.d(TAG, "onFinish: getNearbyPetrolPumps: Maps Activity: Timer finished");

                if (getNearbyPlacesData.getStatus() == AsyncTask.Status.RUNNING || getNearbyPlacesData.nearbyPlaceListMaster.isEmpty()) {

                    Log.d(TAG, "onFinish: getNearbyPetrolPumps: Maps Activity: Task Failed");
                    
                    getNearbyPlacesData.cancel(true);
                    TranslateAnimation translateAnimation = new TranslateAnimation(0,0,320, -120);
                    translateAnimation.setDuration(300);
                    translateAnimation.setFillAfter(true);
                    progressBar.startAnimation(translateAnimation);
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), "Oops! Can't connect to the server! Please try again.", Toast.LENGTH_SHORT).show();

                    Log.d(TAG, "onFinish: getNearbyPetrolPumps: Maps Activity: Showing Toast: toast = Oops! Can't connect to the server! Please try again.");
                }
            }
        }.start();
        Toast.makeText(MapsActivity.this, "Showing Nearby Petrol Pumps!", Toast.LENGTH_LONG).show();

        Log.d(TAG, "onFinish: getNearbyPetrolPumps: Maps Activity: Showing Toast: toast = Showing Nearby Petrol Pumps!");
    }

    // TO get URL
    private String getURL(double latitude, double longitude, String nearbyPlace, String token) {

        Log.d(TAG, "getURL: Maps Activity Called");
        
        StringBuilder googlePlaceURL = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        if (token == null) {
            googlePlaceURL.append("location=" + latitude + "," + longitude);
            googlePlaceURL.append("&radius=" + PROXIMITY_RADIUS);
            googlePlaceURL.append("&type=" + nearbyPlace);
            googlePlaceURL.append("&hasNextPage=true");
            googlePlaceURL.append("&nextpage()=true");
            googlePlaceURL.append("&keyword=" + "petrolpump");
            googlePlaceURL.append("&sensor=true");
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        } else{
            googlePlaceURL.append("pagetoken="+token);
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        }

        Log.d(TAG, "getURL: Maps Acitivity: googlePlaceURL = " + googlePlaceURL.toString());
        
        return googlePlaceURL.toString();
    }

    // Touch Event Listeners
    @Override
    public void onCameraIdle() {
        /*Toast.makeText(this, "The camera has stopped moving.",
                Toast.LENGTH_SHORT).show();*/
        if (fuelLocationPager.getVisibility() == View.VISIBLE && isViewPagerOut && placeInfoCardView.getVisibility() != View.VISIBLE) {
            TranslateAnimation translateAnimation = new TranslateAnimation(0,0,250,0);
            translateAnimation.setDuration(300);
            translateAnimation.setFillAfter(true);
            fuelLocationPager.startAnimation(translateAnimation);
            gpsLocateMe.startAnimation(translateAnimation);
            showNearByPetrolPumpsButton.startAnimation(translateAnimation);
            if (radiusSearchButton.getVisibility() == View.VISIBLE) {
                radiusSearchButton.startAnimation(translateAnimation);
            }
            if (radiusSeekBar.getVisibility() == View.VISIBLE) {
                radiusSeekBar.startAnimation(translateAnimation);
            }
            if (seekBarValue.getVisibility() == View.VISIBLE) {
                seekBarValue.startAnimation(translateAnimation);
            }
            if (seekBarMinimizeButton.getVisibility() == View.VISIBLE) {
                seekBarMinimizeButton.startAnimation(translateAnimation);
            }

            isViewPagerOut = false;

            Log.d(TAG, "onCameraIdle: Maps Activity: isViewPager = false");
        } else if (placeInfoCardView.getVisibility() == View.VISIBLE && isPlaceInfoCardViewOut && fuelLocationPager.getVisibility() != View.VISIBLE) {
            TranslateAnimation translateAnimation = new TranslateAnimation(0,0,250,0);
            translateAnimation.setDuration(300);
            translateAnimation.setFillAfter(true);

            placeInfoCardView.startAnimation(translateAnimation);

            isPlaceInfoCardViewOut = false;

            if (gpsLocateMe.getVisibility() == View.VISIBLE) {

                gpsLocateMe.startAnimation(translateAnimation);
            }

        }
    }

    @Override
    public void onCameraMoveCanceled() {
        /*Toast.makeText(this, "Camera movement canceled.",
                Toast.LENGTH_SHORT).show();*/
    }

    @Override
    public void onCameraMove() {
        /*Toast.makeText(this, "The camera is moving.",
                Toast.LENGTH_SHORT).show();*/
    }

    @Override
    public void onCameraMoveStarted(int reason) {
        if (reason == GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE) {
            /*Toast.makeText(this, "The user gestured on the map.",
                    Toast.LENGTH_SHORT).show();*/
            if (fuelLocationPager.getVisibility() == View.VISIBLE && fuelLocationPager.getTranslationY() != 250 && placeInfoCardView.getVisibility() != View.VISIBLE) {
                TranslateAnimation translateAnimation = new TranslateAnimation(0,0,0,250);
                translateAnimation.setDuration(300);
                translateAnimation.setFillAfter(true);

                fuelLocationPager.startAnimation(translateAnimation);
                gpsLocateMe.startAnimation(translateAnimation);
                showNearByPetrolPumpsButton.startAnimation(translateAnimation);
                if (radiusSearchButton.getVisibility() == View.VISIBLE) {
                    radiusSearchButton.startAnimation(translateAnimation);
                }
                if (radiusSeekBar.getVisibility() == View.VISIBLE) {
                    radiusSeekBar.startAnimation(translateAnimation);
                }
                if (seekBarValue.getVisibility() == View.VISIBLE) {
                    seekBarValue.startAnimation(translateAnimation);
                }
                if (seekBarMinimizeButton.getVisibility() == View.VISIBLE) {
                    seekBarMinimizeButton.startAnimation(translateAnimation);
                }
                if (coordinatorLayout.getVisibility() == View.VISIBLE && behavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                }

                isViewPagerOut = true;

                Log.d(TAG, "onCameraMoveStarted: Maps Activity: isViewPagerOut = " + isViewPagerOut);
            } else if (placeInfoCardView.getVisibility() == View.VISIBLE && fuelLocationPager.getVisibility() != View.VISIBLE) {
                TranslateAnimation translateAnimation = new TranslateAnimation(0,0,0,250);
                translateAnimation.setDuration(300);
                translateAnimation.setFillAfter(true);

                placeInfoCardView.startAnimation(translateAnimation);

                isPlaceInfoCardViewOut = true;

                if (gpsLocateMe.getVisibility() == View.VISIBLE) {

                    gpsLocateMe.startAnimation(translateAnimation);
                }
            }
        } else if (reason == GoogleMap.OnCameraMoveStartedListener
                .REASON_API_ANIMATION) {
            /*Toast.makeText(this, "The user tapped something on the map.",
                    Toast.LENGTH_SHORT).show();*/
        } else if (reason == GoogleMap.OnCameraMoveStartedListener
                .REASON_DEVELOPER_ANIMATION) {
            /*Toast.makeText(this, "The app moved the camera.",
                    Toast.LENGTH_SHORT).show();*/
        }
    }

    private void getPredictions(String s) {

        AutocompleteSessionToken token = AutocompleteSessionToken.newInstance();

        autocompleteRecyclerView.setVisibility(View.VISIBLE);
        autocompleteRecyclerViewSearchImage.setVisibility(View.INVISIBLE);
        autocompleteRecyclerViewSearchText.setVisibility(View.INVISIBLE);

        RectangularBounds bounds = RectangularBounds.newInstance(
                new LatLng(23.63936, 68.14712),
                new LatLng(28.20453, 97.34466)
        );

        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setLocationBias(bounds)
                .setTypeFilter(TypeFilter.CITIES)
                .setOrigin(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()))
                .setSessionToken(token)
                .setQuery(s)
                .build();

        Places.initialize(getApplicationContext(), "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        PlacesClient placesClient = Places.createClient(getApplicationContext());

        placesClient.findAutocompletePredictions(request).addOnSuccessListener(new OnSuccessListener<FindAutocompletePredictionsResponse>() {
            List<AutoCompleteModel> autoCompleteModelList = new ArrayList<>();

            @Override
            public void onSuccess(FindAutocompletePredictionsResponse findAutocompletePredictionsResponse) {

                for(AutocompletePrediction prediction :
                        findAutocompletePredictionsResponse.getAutocompletePredictions()) {
                    String primaryText = prediction.getPrimaryText(null).toString();
                    String secondaryText = prediction.getSecondaryText(null).toString();
                    //int distance = prediction.getDistanceMeters();
                    String placeID = prediction.getPlaceId();
                    int distance;
                    if (prediction.getDistanceMeters() != null) {
                        distance = (int) prediction.getDistanceMeters();
                        Log.d(TAG, "onSuccess: distance = " + distance);
                    } else {
                        distance = 0;
                    }

                    autoCompleteModelList.add(new AutoCompleteModel(primaryText,
                            secondaryText, distance, placeID));

                    Log.i(TAG, prediction.getPlaceId());
                    Log.i(TAG, prediction.getPrimaryText(null).toString());
                }

                LinearLayoutManager linearLayoutManager =
                        new LinearLayoutManager(getApplicationContext());

                /*ImageView autocompleteRecyclerViewSearchImage =
                        findViewById(R.id.autocomplete_recycler_view_search_image);
                autocompleteRecyclerViewSearchImage.setVisibility(View.GONE);*/

                autoCompleteRecyclerViewAdapter = new AutoCompleteRecyclerViewAdapter(autoCompleteModelList,
                        context,
                        mMap,
                        parent,
                        constraintLayout,
                        new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()));

                autocompleteRecyclerView.setAdapter(autoCompleteRecyclerViewAdapter);
                autocompleteRecyclerView.setLayoutManager(linearLayoutManager);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                if (exception instanceof ApiException) {
                    ApiException apiException = (ApiException) exception;
                    Log.e(TAG, "Place not found: " + apiException.getStatusCode());
                }
            }
        });
    }


    public static void slideView(final View view,
                                 int currentHeight,
                                 int newHeight,
                                 int duration) {

        ValueAnimator slideAnimator = ValueAnimator
                .ofInt(currentHeight, newHeight)
                .setDuration(duration);

        slideAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                Integer value = (Integer) animation.getAnimatedValue();
                view.getLayoutParams().height = value.intValue();
                view.requestLayout();
            }
        });

        AnimatorSet animationSet = new AnimatorSet();
        animationSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animationSet.setDuration(duration);
        animationSet.play(slideAnimator);
        animationSet.start();
    }

    private int convertDPtoPix(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics());
    }

    private void placeInfoGPSBut() {

        if (placeInfoPlaceGPSButton.getVisibility() == View.INVISIBLE) {
            placeInfoPlaceGPSButton.setVisibility(View.VISIBLE);

            Animation fadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
            placeInfoPlaceGPSButton.startAnimation(fadeIn);
        }

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), 15));
    }

    private void createNotificationChannel() {
        NotificationChannel fuelMapsBackgroundServiceNotificationChannel = new NotificationChannel(
                CHANNEL_ID,
                "Fuel Maps Background Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(fuelMapsBackgroundServiceNotificationChannel);

        Log.d(TAG, "createNotificationChannel: Notification Channel Created!");
        
    }

    private void startBackgroundService() {
        Intent service = new Intent(this, FuelMapsBackgroundService.class);
        startService(service);
    }

    private void showNearestPetrolPump(PolylineOptions options,
                                       LatLng destinationLatLng,
                                       String distance,
                                       String duration,
                                       String placeName,
                                       String placeAddress,
                                       String placeRating,
                                       ArrayList<? extends Model> modelsList) {
        Log.d(TAG, "showNearestPetrolPump: Called");
        Polyline polyline = mMap.addPolyline(options);

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.icon(bitmapDescriptorFromVector(getApplicationContext(), R.drawable.ic_fuel_pump_spotlight_marker));
        markerOptions.position(destinationLatLng);

        nearestPetrolPumpMarker = mMap.addMarker(markerOptions);

        Log.d(TAG, "showNearestPetrolPump: destinationLatLng = " + destinationLatLng.latitude + " | " + destinationLatLng.longitude);

        boolean hasPoints = false;
        Double maxLat = null, minLat = null, minLon = null, maxLon = null;

        if (options != null && options.getPoints() != null) {
            List<LatLng> pts = options.getPoints();
            for (LatLng coordinate : pts) {
                // Find out the maximum and minimum latitudes & longitudes
                // Latitude
                maxLat = maxLat != null ? Math.max(coordinate.latitude, maxLat) : coordinate.latitude;
                minLat = minLat != null ? Math.min(coordinate.latitude, minLat) : coordinate.latitude;

                // Longitude
                maxLon = maxLon != null ? Math.max(coordinate.longitude, maxLon) : coordinate.longitude;
                minLon = minLon != null ? Math.min(coordinate.longitude, minLon) : coordinate.longitude;

                hasPoints = true;
            }
        }

        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        if (hasPoints) {
            builder.include(new LatLng(maxLat, maxLon));
            builder.include(new LatLng(minLat, minLon));
            builder.include(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()));
            builder.include(destinationLatLng);
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 300));
        }

        if (placeInfoCardView.getVisibility() == View.GONE) {
            TextView placeInfoPlaceName = findViewById(R.id.place_info_place_name);
            TextView placeInfoPlaceAddress = findViewById(R.id.place_info_place_address);
            TextView placeInfoPlaceDistance = findViewById(R.id.place_info_place_distance_text);
            TextView placeInfoPlaceDuration = findViewById(R.id.place_info_place_time_text);

            placeInfoPlaceName.setText(placeName);
            placeInfoPlaceAddress.setText(placeAddress);
            placeInfoPlaceDuration.setText(duration);
            placeInfoPlaceDistance.setText(distance);

            ImageButton placeInfoNearbyPetrolPumps = findViewById(R.id.place_info_place_nearby_fuel_pumps);
            placeInfoNearbyPetrolPumps.setVisibility(View.GONE);

            ImageButton placeInfoDirectionsButton = findViewById(R.id.place_info_place_get_directions);
            placeInfoDirectionsButton.setVisibility(View.GONE);

            ImageView placeInfoPlaceImage = findViewById(R.id.place_info_place_photo);
            placeInfoPlaceImage.setVisibility(View.GONE);

            Button placeInfoStartBut = findViewById(R.id.place_info_start_journey);
            placeInfoStartBut.setVisibility(View.VISIBLE);

            placeInfoStartBut.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startNavigationMode();
                }
            });

            showNearByPetrolPumpsButton.setVisibility(View.GONE);

            ConstraintLayout.LayoutParams placeInfoStartButtonLayout = (ConstraintLayout.LayoutParams) placeInfoStartBut.getLayoutParams();
            placeInfoStartButtonLayout.horizontalBias = (float) 1.0;
            placeInfoStartBut.setLayoutParams(placeInfoStartButtonLayout);

            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.clone(constraintLayout);
            constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.place_info_card_view, ConstraintSet.TOP);
            constraintSet.applyTo(constraintLayout);

            placeInfoCardView.setVisibility(View.VISIBLE);
        }

    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: Called");

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: vectorResId = " + vectorResId);

        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        assert vectorDrawable != null;
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void startNavigationMode() {
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()))
                .zoom(17)
                .bearing(180)
                .tilt(30)
                .build();

        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

        Button placeInfoStartBut = findViewById(R.id.place_info_start_journey);
        placeInfoStartBut.setVisibility(View.GONE);

        ImageView placeInfoPlaceImage = findViewById(R.id.place_info_place_photo);
        placeInfoPlaceImage.setVisibility(View.GONE);

        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) placeInfoCardView.getLayoutParams();
        layoutParams.verticalBias = (float) 1.12;
        placeInfoCardView.setLayoutParams(layoutParams);

        hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_arrow_back_ios_24);
        hamburgerMenuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nearestPetrolPumpMarker.remove();

                mMap.clear();

                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()))
                        .zoom(17)
                        .bearing(0)
                        .tilt(0)
                        .build();

                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);
                constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.parent, ConstraintSet.BOTTOM);
                constraintSet.applyTo(constraintLayout);

                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) gpsLocateMe.getLayoutParams();
                layoutParams.verticalBias = (float) 1.0;
                gpsLocateMe.setLayoutParams(layoutParams);

                layoutParams = (ConstraintLayout.LayoutParams) placeInfoCardView.getLayoutParams();
                layoutParams.verticalBias = (float) 1.0;
                placeInfoCardView.setLayoutParams(layoutParams);

                hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);

                placeInfoCardView.setVisibility(View.GONE);
                showNearByPetrolPumpsButton.setVisibility(View.VISIBLE);
            }
        });
    }

}
