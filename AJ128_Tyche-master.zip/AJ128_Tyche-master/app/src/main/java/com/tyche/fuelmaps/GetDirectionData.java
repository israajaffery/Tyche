package com.tyche.fuelmaps;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.PolyUtil;
import com.tyche.fuelmaps.parser.DataParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static android.view.View.VISIBLE;

public class GetDirectionData extends AsyncTask<Object, String, String> {

    // Local Variables
    LatLng currentLocation;
    LatLng destination;
    GoogleMap mMap;
    String googledirectionsData;
    String duration = "";
    String distance = "";
    String TAG = "Fuel Maps";
    String TAG2 = "GetDirectionData Class:";
    List<Marker> markers;
    @SuppressLint("StaticFieldLeak")
    ViewGroup parent;
    ViewPager2 fuelLocationPager;
    Context context;

    public GetDirectionData() {
        super();
        Log.d(TAG, "GetDirectionData: Object created");
    }

    @Override
    protected String doInBackground(Object... objects) {
        Log.d(TAG, "GetDirectionData: Called");
        currentLocation = (LatLng) objects[0];
        destination = (LatLng) objects[1];
        mMap = (GoogleMap) objects[2];
        markers = (List<Marker>) objects[3];
        parent = (ViewGroup) objects[4];
        if (objects.length == 6) {
            context = (Context) objects[5];
        }

        Log.d(TAG, "doInBackground: " + TAG2 + " current location passed: lat = " + currentLocation.latitude + " | lng = " + currentLocation.longitude);
        Log.d(TAG, "doInBackground: " + TAG2 + " destination location passed: lat = " + destination.latitude + " | lng = " + destination.longitude);

        if (mMap != null) {
            Log.d(TAG, "doInBackground: " + TAG2 + " mMap != null");
        } else {
            Log.d(TAG, "doInBackground: " + TAG2 + " mMap == null");
        }

        DownloadURL URL = new DownloadURL();

        try {
            String url = getDirectionsURL(currentLocation, destination);
            Log.d(TAG, "doInBackground: " + TAG2 + " url generated: url = " + url);
            googledirectionsData = URL.readURL(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.d(TAG, "doInBackground: " + TAG2 + " googleDirectionsData = " + googledirectionsData);
        return googledirectionsData;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        String[] directionsList = null;
        DataParser parser = new DataParser();
        List<Object> polyLines = new ArrayList<>();

        polyLines = parser.parseDirections(s);

        directionsList = (String[]) polyLines.get(0);

        String distance = (String) polyLines.get(1);

        String duration = (String) polyLines.get(2);

        Log.d(TAG, "onPostExecute: " + TAG2 + " directionsList = " + Arrays.toString(directionsList));

        displayDirections(directionsList, distance, duration);
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onCancelled(String s) {
        super.onCancelled(s);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    private String getDirectionsURL(LatLng currentLocation, LatLng destination) {
        Log.d(TAG, "getDirectionsURL: " + TAG2 + " Called");
        Log.d(TAG, "getDirectionURL: " + TAG2 + " current location passed: lat = " + currentLocation.latitude + " | lng = " + currentLocation.longitude);
        Log.d(TAG, "getDirectionURL: " + TAG2 + " destination location passed: lat = " + destination.latitude + " | lng = " + destination.longitude);

        StringBuilder directionURL = new StringBuilder("https://maps.googleapis.com/maps/api/directions/json?");
        directionURL.append("origin=" + currentLocation.latitude + "," + currentLocation.longitude);
        directionURL.append("&destination=" + destination.latitude + "," + destination.longitude);
        directionURL.append("&alternatives=true");
        directionURL.append("&units=metric");
        directionURL.append("&departure_time=now");
        directionURL.append("&traffic_model=best_guess");
        directionURL.append("&key=AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        String url = directionURL.toString();

        Log.d(TAG, "getDirectionsURL: " + TAG2 + " url = " + url);
        return url;
    }

    public void displayDirections(final String[] directionsList, String distance, String duration) {

        Log.d(TAG, "displayDirections: " + TAG2 + " Called");

        Log.d(TAG, "displayDirections:  " + TAG2 + " directionsList passed: directionsList = " + Arrays.toString(directionsList));

        fuelLocationPager = (ViewPager2) parent.findViewById(R.id.fuel_locations_pager);

        int count = directionsList.length;

        if (markers != null) {
            for (int i = 0; i < markers.size(); i++) {
                Marker marker = markers.get(i);
                marker.setVisible(false);
                if (i == fuelLocationPager.getCurrentItem()) {
                    marker.setVisible(true);
                }
            }
        }

        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        PolylineOptions options = new PolylineOptions();
        options.color(Color.argb(255, 110, 73, 161));
        options.width(15);
        options.jointType(2);

        for (int i = 0; i < count; i++) {
            options.addAll(PolyUtil.decode(directionsList[i]));
        }

        boolean hasPoints = false;
        Double maxLat = null, minLat = null, minLon = null, maxLon = null;

        if (options != null && options.getPoints() != null) {
            List<LatLng> pts = options.getPoints();
            for (LatLng coordinate : pts) {
                // Find out the maximum and minimum latitudes & longitudes
                // Latitude
                maxLat = maxLat != null ? Math.max(coordinate.latitude, maxLat) : coordinate.latitude;
                minLat = minLat != null ? Math.min(coordinate.latitude, minLat) : coordinate.latitude;

                // Longitude
                maxLon = maxLon != null ? Math.max(coordinate.longitude, maxLon) : coordinate.longitude;
                minLon = minLon != null ? Math.min(coordinate.longitude, minLon) : coordinate.longitude;

                hasPoints = true;
            }
        }

        Polyline polyline = mMap.addPolyline(options);

        Button placeInfoStartJourney = parent.findViewById(R.id.place_info_start_journey);

        if (placeInfoStartJourney.getVisibility() == View.GONE) {
            Animation aniFadeIn = AnimationUtils.loadAnimation(context, R.anim.fade_in);
            placeInfoStartJourney.startAnimation(aniFadeIn);
            placeInfoStartJourney.setVisibility(View.VISIBLE);
        }

        TextView placeInfoPlaceDuration = (TextView) parent.findViewById(R.id.place_info_place_time_text);

        ConstraintLayout placeInfoPlaceTimeConstraint = (ConstraintLayout) parent.findViewById(R.id.place_info_time_text_constraint);

        if (placeInfoPlaceTimeConstraint.getVisibility() == View.VISIBLE) {
            placeInfoPlaceDuration.setText(duration);
        } else {
            placeInfoPlaceTimeConstraint.setVisibility(View.VISIBLE);
            Animation aniFade = AnimationUtils.loadAnimation(context,R.anim.fade_in);
            placeInfoPlaceDuration.setText(duration);
            placeInfoPlaceTimeConstraint.startAnimation(aniFade);
        }

        if (hasPoints) {
            builder.include(new LatLng(maxLat, maxLon));
            builder.include(new LatLng(minLat, minLon));
            builder.include(currentLocation);
            builder.include(destination);
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 300));
        }

        final ImageButton getNearbyPetrolPumpsOnRoute = (ImageButton) parent.findViewById(R.id.place_info_place_nearby_fuel_pumps);

        getNearbyPetrolPumpsOnRoute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Object[] objects = new Object[1];
                objects[0] = directionsList;

                new GetNearbyPetrolPumpsOnRoute(parent, mMap, currentLocation).execute(objects);

                Animation aniFadeOut = AnimationUtils.loadAnimation(context, R.anim.fade_out);
                getNearbyPetrolPumpsOnRoute.startAnimation(aniFadeOut);
                getNearbyPetrolPumpsOnRoute.setVisibility(View.GONE);

                Button placeInfoStartJourney = parent.findViewById(R.id.place_info_start_journey);

                TranslateAnimation placeInfoStartJourneyAnim = new TranslateAnimation(0, 120, 0, 0);
                placeInfoStartJourneyAnim.setDuration(200);
                placeInfoStartJourneyAnim.setFillAfter(true);
                placeInfoStartJourneyAnim.setInterpolator(parent.getContext(), android.R.interpolator.linear);

                placeInfoStartJourney.startAnimation(placeInfoStartJourneyAnim);
            }
        });

        hideViewElements();
    }

    private void hideViewElements() {
        TextView seekBarValue = (TextView) parent.findViewById(R.id.seekBarValueText);
        SeekBar radiusSeekBar = (SeekBar) parent.findViewById(R.id.radiusSeekBar);
        ImageButton getNearbyPetrolPumps = (ImageButton) parent.findViewById(R.id.show_nearby_petrol_pumps);
        ImageButton seekBarMinimizeButton = (ImageButton) parent.findViewById(R.id.seekbar_minimize_button);

        if (seekBarValue.getVisibility() == VISIBLE) {
            seekBarValue.setVisibility(View.GONE);
        }
        if (radiusSeekBar.getVisibility() == VISIBLE) {
            radiusSeekBar.setVisibility(View.GONE);
        }
        /*if (getNearbyPetrolPumps.getVisibility() == View.VISIBLE) {
            getNearbyPetrolPumps.setVisibility(View.GONE);
        }*/
        if (seekBarMinimizeButton.getVisibility() == VISIBLE) {
            seekBarMinimizeButton.setVisibility(View.GONE);
        }
    }
}
