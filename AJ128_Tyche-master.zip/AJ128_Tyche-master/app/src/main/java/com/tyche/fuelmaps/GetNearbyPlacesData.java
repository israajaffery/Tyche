package com.tyche.fuelmaps;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;
import com.tyche.fuelmaps.adapter.FuelLocationCardViewAdapter;
import com.tyche.fuelmaps.adapter.FuelLocationRecyclerViewAdapter;
import com.tyche.fuelmaps.models.Model;
import com.tyche.fuelmaps.parser.DataParser;
import com.tyche.fuelmaps.transformer.ZoomOutPageTransformer;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;


public class GetNearbyPlacesData extends AsyncTask<Object, Integer, String> {

    // Variables
    String googlePlacesData;
    String googlePlacesData2;
    String googlePlacesData3;
    GoogleMap mMaps;
    String URL;
    String TAG = "Fuel Maps";
    String nextTokenValue;
    LatLng currentLocation;
    @SuppressLint("StaticFieldLeak")
    ProgressBar progressBar;
    @SuppressLint("StaticFieldLeak")
    ViewPager2 fuelLocationPager;
    @SuppressLint("StaticFieldLeak")
    Context context;
    @SuppressLint("StaticFieldLeak")
    SeekBar radiusSeekBar;
    @SuppressLint("StaticFieldLeak")
    TextView seekBarValue;
    @SuppressLint("StaticFieldLeak")
    ImageButton seekBarMinimizeButton;
    @SuppressLint("StaticFieldLeak")
    ViewGroup parent;
    @SuppressLint("StaticFieldLeak")
    ConstraintLayout constraintLayout;
    @SuppressLint("StaticFieldLeak")
    ImageButton radiusSearchButton;
    Button listViewButton;
    BottomSheetBehavior behavior;
    Object[] dataTransfer;
    List<Marker> markers = new ArrayList<>();
    List<Marker> markerTemp = new ArrayList<>();
    Marker marker;
    CoordinatorLayout coordinatorLayout;
    CoordinatorLayout fuelPumpDetails;
    List<Model> models = new ArrayList<>();
    List<HashMap<String, String>> nearbyPlaceListMaster = null;
    OnPageChangeCallback onPageChangeCallback;
    ArrayList<String> selectedPumpPreferences = new ArrayList<>();
    ImageButton userPreferenceButton;
    Boolean isClicked = false;

    // Before the async task starts
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        Log.d(TAG, "onPreExecute: GetNearbyPlaces Class : Initiated");
    }

    // Gets the HTML java class
    @SuppressLint("WrongThread")
    @Override
    protected String doInBackground(Object... objects) {
        Log.d(TAG, "doInBackground: GetNearbyPlaces Class : Started");
        mMaps = (GoogleMap) objects[0];
        URL = (String) objects[1];
        currentLocation = (LatLng) objects[2];
        progressBar = (ProgressBar) objects[3];
        fuelLocationPager = (ViewPager2) objects[4];
        context = (Context) objects[5];
        radiusSeekBar = (SeekBar) objects[6];
        seekBarValue = (TextView) objects[7];
        seekBarMinimizeButton = (ImageButton) objects[8];
        parent = (ViewGroup) objects[9];
        constraintLayout = (ConstraintLayout) objects[10];
        dataTransfer = (Object[]) objects[11];

        radiusSearchButton = parent.findViewById(R.id.search_button_radius);
        getPumpPreferences();
        Log.d(TAG, "doInBackground: GetNearbyPlaces Class : URL Passed : " + URL);
        Log.d(TAG, "doInBackground: GetNearbyPlaces Class : Current Location Passed : Lat = " + currentLocation.latitude + " Lng = " + currentLocation.longitude);

        DownloadURL downloadURL = new DownloadURL();
        try {
            googlePlacesData = downloadURL.readURL(URL);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.d(TAG, "doInBackground: GetNearbyPlaces Class : googlePlacesData after parsing : "  + googlePlacesData);

        String token = getToken(googlePlacesData);
        if (!token.isEmpty()) {

            Log.d(TAG, "doInBackground: GetNearbyPlaces Class: Token 1 Received and Not Empty: token = " + token);

            StringBuilder googlePlaceURL = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
            googlePlaceURL.append("pagetoken=").append(token);
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
            String url = googlePlaceURL.toString();

            Log.d(TAG, "doInBackground: GetNearbyPlaces Class: URL Passed after receiving 1st token: URL = " + url);

            try {
                Thread.sleep(2000);

                Log.d(TAG, "doInBackground: GetNearbyPlacesData Class: Sleep: 2000ms");

                googlePlacesData2 = downloadURL.readURL(url);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }

            Log.d(TAG, "doInBackground: GetNearbyPlaces Class : googlePlacesData2 after parsing : "  + googlePlacesData2);

            token = getToken(googlePlacesData);
            if (!token.isEmpty()) {

                Log.d(TAG, "doInBackground: GetNearbyPlaces Class: Token 2 Received and Not Empty: token = " + token);

                googlePlaceURL = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
                googlePlaceURL.append("pagetoken=").append(token);
                googlePlaceURL.append("&key="+"AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
                url = googlePlaceURL.toString();

                Log.d(TAG, "doInBackground: GetNearbyPlaces Class: URL Passed after receiving 2nd token: URL = " + url);

                try {
                    Thread.sleep(2000);

                    Log.d(TAG, "doInBackground: GetNearbyPlacesData Class: Sleep: 2000ms");

                    googlePlacesData3 = downloadURL.readURL(url);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }

                Log.d(TAG, "doInBackground: GetNearbyPlaces Class : googlePlacesData3 after parsing : "  + googlePlacesData3);
            } else {
                Log.d(TAG, "doInBackground: GetNearbyPlacesData Class: token 2 Returned Empty!");
            }
        } else {
            Log.d(TAG, "doInBackground: GetNearbyPlacesData Class: token 1 Returned Empty!");
        }

        Log.d(TAG, "doInBackground: GetNearbyPlaces Class: Background task complete: Result = " + googlePlacesData + googlePlacesData2 + googlePlacesData3);
        
        return googlePlacesData+googlePlacesData2+googlePlacesData3;
    }

    // Progress update
    @Override
    protected void onProgressUpdate(Integer... values) {

        Log.d(TAG, "onProgressUpdate: GetNearbyPlacesData Class: Called");
        
    }

    // After the background task is complete
    @Override
    protected void onPostExecute(String s) {

        Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: Called");

        DataParser parser = new DataParser();
        nearbyPlaceListMaster = parser.parse(s);

        Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: nearbyPlaceListMaster = " + nearbyPlaceListMaster);

        Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: nearbyPlaceListMaster Size: nearbyPlaceListMaster.size() = " + nearbyPlaceListMaster.size());

        for (int i = 0; i < nearbyPlaceListMaster.size(); i++) {

            Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: nearbyPlaceList[" + i + "] = " + nearbyPlaceListMaster.get(i));

        }
        List<HashMap<String, String>> nearbyPlaceList3;
        nearbyPlaceList3 = nearbyPlaceListMaster;

        Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: nearbyPlaceList3 = " + nearbyPlaceList3);

        if (!nearbyPlaceListMaster.isEmpty()) {

            Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: nearbyPlaceListMaster Not Empty: nearbyPlaceList = " + nearbyPlaceListMaster);
            
            showNearbyPlaces(nearbyPlaceList3, 50000);
        } else {
            Log.d(TAG, "onPostExecute: GetNearbyPlacesData Class: nearbyPlaceListMaster Returned Empty");
        }
    }

    // Adds Marker
    public void showNearbyPlaces(List<HashMap<String, String>> nearbyPlaceList, float radius) {
        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: showNearbyPlaces: Called");
        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: Radius Passed: radius = " + radius);
        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: nearbyPlaceList Before Removing : " + nearbyPlaceList);
        double latTotal = 0.00;
        double lngTotal = 0.00;
        LatLng averageLatLng;
        for (int i = 0; i < nearbyPlaceList.size(); i++) {
            MarkerOptions markerOptions = new MarkerOptions();
            HashMap<String, String> googlePlace = nearbyPlaceList.get(i);

            Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: googlePlace[" + i + "] = " + googlePlace);

            String placeName = googlePlace.get("place_name");
            String vicinity = googlePlace.get("vicinity");

            double lat = 0.00;
            double lng = 0.00;

            if (!googlePlace.get("lat").isEmpty() && !googlePlace.get("lng").isEmpty() && googlePlace.get("lat") != null && googlePlace.get("lng") != null) {
                lat = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lat")))));
                lng = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lng")))));
            }

            latTotal = latTotal + lat;
            lngTotal = lngTotal + lng;
            LatLng latLng = new LatLng(lat, lng);
            float[] results = new float[1];
            Location.distanceBetween(currentLocation.latitude, currentLocation.longitude,
                    lat, lng, results);

            Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: googlePlace: Place Name = " + placeName + " | vicinity = " + vicinity + " | lat = " + lat + " | lng = " + lng + " | distance = " + results[0]);

            if (results[0] <= radius) {

                Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: Result : " + results[0]);

                Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: result <= result: googlePlace[" + i + "]: Place Name = " + placeName + " | vicinity = " + vicinity + " | lat = " + lat + " | lng = " + lng + " | distance = " + results[0]);

                markerOptions.position(latLng);
                markerOptions.icon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                markerOptions.title(placeName);
                marker = mMaps.addMarker(markerOptions);
                marker.setTag(i);
                markers.add(i, marker);

                Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: Markers Array Size: Markers.size() = " + markers.size());

                Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: Marker Placed at : lat = " + latLng.latitude + " lng = " + latLng.longitude);

            } else {

                Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: result !<= result: googlePlace[" + i + "]: Place Name = " + placeName + " | vicinity = " + vicinity + " | lat = " + lat + " | lng = " + lng + " | distance = " + results[0]);

                nearbyPlaceList.remove(i);
            }
        }
        averageLatLng = new LatLng(latTotal/nearbyPlaceList.size(), lngTotal/nearbyPlaceList.size());

        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: Average LatLng: lat = " + averageLatLng.latitude + " lng  = " + averageLatLng.longitude);

        mMaps.animateCamera(CameraUpdateFactory.newLatLngZoom(averageLatLng, 12));

        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: animated Camera to: lat = " + averageLatLng.latitude + " lng = " + averageLatLng.longitude);

        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: nearbyPlaceList After Removing : " + nearbyPlaceList);
        for (int i = 0; i < nearbyPlaceList.size(); i++) {
            Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: nearbyPlaceList[" + i + "] = " + nearbyPlaceList.get(i));
        }

        markerTemp.addAll(markers);

        setViewPager(nearbyPlaceList, radius, markerTemp);
        setRadiusBar();
        TranslateAnimation translateAnimation = new TranslateAnimation(0,0,320, -120);
        translateAnimation.setDuration(300);
        translateAnimation.setFillAfter(true);
        progressBar.startAnimation(translateAnimation);
        progressBar.setVisibility(View.GONE);
        Log.d(TAG, "showNearbyPlaces: GetNearbyPlacesData Class: progressBar.setVisibility(View.GONE)");
    }

    // Gets next page token
    public String getToken(String string) {

        Log.d(TAG, "getToken: GetNearbyPlacesData Class: Called");

        Log.d(TAG, "getToken: GetNearbyPlacesData Class: Argument Passed = " + string);

        if (string != null) {

            Log.d(TAG, "getToken: GetNearbyPlacesData Class: string != null");

            String[] keyValuePairs = string.split(",");
            String[] tokenValue = keyValuePairs[1].split(":");
            nextTokenValue = tokenValue[1];
            nextTokenValue = nextTokenValue.substring(1,nextTokenValue.length()-1);
            nextTokenValue = nextTokenValue.substring(1);
            Log.d(TAG, "getToken: GetNearbyPlacesData Class: token = "+nextTokenValue);
            Log.d(TAG, "getToken: GetNearbyPlacesData Class: " + tokenValue[0] + " = " + tokenValue[1]);
        }
        return nextTokenValue;
    }

    // returns nearby place List
    public List<HashMap<String, String>> returnPlacesList() {

        Log.d(TAG, "returnPlacesList: GetNearbyPlacesData Class: Called");
        
        return nearbyPlaceListMaster;
    }

    // Set View Pager
    private void setViewPager(List<HashMap<String, String>> nearbyPlaceList, float radius, final List<Marker> markers) {

        Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: Called");

        for (int i = 0; i < markers.size(); i++) {
            marker = markers.get(i);
            if (!marker.isVisible()) {
                marker.setVisible(true);
            }
            marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
        }
        float[] distance = new float[1];
        for (int i = 0; i < nearbyPlaceList.size(); i++) {
            HashMap<String, String> googlePlace = nearbyPlaceList.get(i);

            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: nearbyPlaceList[" + i + "] = " + nearbyPlaceList.get(i));

            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: googleplace[" + i + "] = " + googlePlace);

            LatLng latLng = new LatLng(Double.parseDouble(Objects.requireNonNull(googlePlace.get("lat"))), Double.parseDouble(Objects.requireNonNull(googlePlace.get("lng"))));
            Location.distanceBetween(currentLocation.latitude, currentLocation.longitude,
                    latLng.latitude, latLng.longitude, distance);

            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: PlaceName = " + googlePlace.get("place_name") + "Distance = " + distance[0]);

            models.add(new Model(R.drawable.ic_background_red_can, googlePlace.get("place_name"), "Petrol Pump", googlePlace.get("vicinity"), latLng, distance[0], googlePlace.get("rating"), googlePlace.get("photo_reference")));
        }

        Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: Models List = " + models);

        for (int i = 0; i < models.size(); i++) {
            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: models[" + i + "] = " + models.get(i));
            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: models[" + i + "]: " + "Place Name = " + models.get(i).getPetrol_pump_name() + " | lat = " + models.get(i).getLatLng().latitude + " | lng = " + models.get(i).getLatLng().longitude + " | distance = " + models.get(i).getDistance());
        }

        if (fuelLocationPager.getVisibility() == View.GONE) {
            fuelLocationPager.setVisibility(View.VISIBLE);
        }

        coordinatorLayout = parent.findViewById(R.id.bottomSheetCoordinatorLayout);

        bottomSheetBehaviourCallback(models, markers);

        fuelPumpDetails = parent.findViewById(R.id.fuel_pump_details);

        fuelLocationPager.setAdapter(new FuelLocationCardViewAdapter(models,
                coordinatorLayout,
                context,
                behavior,
                fuelPumpDetails,
                fuelLocationPager,
                mMaps,
                currentLocation,
                markers,
                parent));

        fuelLocationPager.setClipToPadding(false);
        fuelLocationPager.setClipChildren(false);
        fuelLocationPager.setOffscreenPageLimit(3);
        //fuelLocationPager.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);
        fuelLocationPager.setPageTransformer(new ZoomOutPageTransformer());
        fuelLocationPager.setVisibility(View.VISIBLE);
        fuelLocationPager.setCurrentItem(0);
        fuelLocationPager.setSaveEnabled(false);
        fuelLocationPager.setSaveFromParentEnabled(false);
        setOnMarkerClickListener();
        setBackButton();
        setUserPreferenceListener();

        Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: modelsList size = " + models.size());
        fuelLocationPager.registerOnPageChangeCallback(onPageChangeCallback = new ViewPager2.OnPageChangeCallback() {
            int currentCardPostion;
            boolean isGoingToRight;

            @Override
            public void onPageSelected(int position) {
                currentCardPostion = position;

                marker = markers.get(position);
                marker.showInfoWindow();
                if (marker.getTag() == null) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(marker.getPosition());
                    marker = mMaps.addMarker(markerOptions);
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                    markers.remove(position);
                    markers.add(position, marker);
                }

                Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: modelsList size = " + models.size());

                Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: currentPosition = " + currentCardPostion);

                if (!models.isEmpty()) {
                    setPetrolPumpDetails(position);
                } else {
                    Toast.makeText(context, "Models List Empty!", Toast.LENGTH_SHORT).show();
                }

                Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: Markers size = " + markers.size());

                if (position == 0) {

                    Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: position == 0");

                    Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: Markers size = " + markers.size());
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                }
                mMaps.animateCamera(CameraUpdateFactory.newLatLngZoom(markers.get(position).getPosition(), 12), 400, null);

                Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: animated Camera at: lat = " + models.get(position).getLatLng().latitude + " | lng = " + models.get(position).getLatLng().longitude);

                if (isGoingToRight) {

                    Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: User Scrolling to the right: isGoingToRight = " + isGoingToRight);

                    if (position > 0) {
                        int previousPosition = position - 1;

                        Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: previousPosition = " + previousPosition);

                        if (markers.get(position) != null) {

                            Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + position + "] != null");

                            marker = markers.get(position);

                            marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                        }
                        if (markers.get(position) != null) {
                            if (markers.get(previousPosition) != null) {

                                Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + previousPosition + "] != null");

                                marker = markers.get(previousPosition);

                                if (marker.getTag() == null) {
                                    MarkerOptions markerOptions = new MarkerOptions();
                                    markerOptions.position(marker.getPosition());
                                    marker = mMaps.addMarker(markerOptions);
                                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                                    markers.remove(previousPosition);
                                    markers.add(previousPosition, marker);
                                }

                                marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                            }
                        }
                    }
                } else {

                    Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: User going Left");

                    if (position >= 0) {
                        if (markers.get(position) != null) {

                            Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + position + "] != null");

                            marker = markers.get(position);

                            marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                        }
                        if (position < markers.size()) {
                            int nextPosition = position + 1;
                            if (markers.get(nextPosition) != null) {

                                Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + nextPosition + "] != null");

                                marker = markers.get(nextPosition);

                                marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                            }
                        }
                    }
                }
                
            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                isGoingToRight = position == currentCardPostion;

                marker = markers.get(position);
                if (marker.getTag() == null) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(marker.getPosition());
                    marker = mMaps.addMarker(markerOptions);
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                    markers.add(position,marker);
                }
            }
        });
    }

    // To convert vector to BitmapDescriptor
    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: Called");

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: vectorResId = " + vectorResId);
        
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        assert vectorDrawable != null;
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    // Set Radius bar
    private void setRadiusBar() {

        Log.d(TAG, "setRadiusBar: GetNearbyPlacesData Class: Called");
        
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(constraintLayout);
        constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.radiusSeekBar, ConstraintSet.TOP);
        constraintSet.applyTo(constraintLayout);
        seekBarValue.setVisibility(View.VISIBLE);

        Log.d(TAG, "setRadiusBar: GetNearbyPlacesData Class: seekBarValue.setVisibility(View.VISIBLE)");
        
        seekBarValue.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {

                Log.d(TAG, "RadiusSeekBar onClick: GetNearbyPlacesData Class: started");

                if (radiusSeekBar.getVisibility() == View.GONE) {

                    seekBarValue.setWidth(300);
                    seekBarValue.setText("Radius : 50 KM");
                    radiusSeekBar.setVisibility(View.VISIBLE);
                    seekBarMinimizeButton.setVisibility(View.VISIBLE);

                    seekBarMinimizeButton.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {

                            Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: Button Clicked");

                            if (radiusSeekBar.getVisibility() == View.GONE) {

                                Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: radiusSeekBar.getVisibility() == View.GONE");

                                radiusSeekBar.setVisibility(View.VISIBLE);

                                seekBarValue.setVisibility(View.VISIBLE);

                                Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: radiusSeekBar.setVisibility(View.VISIBLE)");

                                seekBarMinimizeButton.setImageResource(R.drawable.ic_minimize_button);

                                Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: seekBarMinimizeButton.setImageResource(R.drawable.ic_minimize_button)");

                                ConstraintSet constraintSet = new ConstraintSet();
                                constraintSet.clone(constraintLayout);
                                constraintSet.connect(R.id.seekbar_minimize_button, ConstraintSet.BOTTOM, R.id.radiusSeekBar, ConstraintSet.TOP);
                                constraintSet.applyTo(constraintLayout);

                                ConstraintSet constraintSet1 = new ConstraintSet();
                                constraintSet1.clone(constraintLayout);
                                constraintSet1.connect(R.id.seekBarValueText, ConstraintSet.BOTTOM, R.id.radiusSeekBar, ConstraintSet.TOP);
                                constraintSet1.applyTo(constraintLayout);

                                ConstraintSet constraintSet2 = new ConstraintSet();
                                constraintSet2.clone(constraintLayout);
                                constraintSet2.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.radiusSeekBar, ConstraintSet.TOP);
                                constraintSet2.applyTo(constraintLayout);

                            } else if (radiusSeekBar.getVisibility() == View.VISIBLE) {

                                Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: radiusSeekBar.getVisibility() == View.VISIBLE");

                                radiusSeekBar.setVisibility(View.GONE);

                                seekBarValue.setVisibility(View.GONE);

                                Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: radiusSeekBar.setVisibility(View.GONE)");

                                seekBarMinimizeButton.setImageResource(R.drawable.ic_maximize_button);

                                Log.d(TAG, "SeekBarMinimizebutton onClick: GetNearbyPlacesData Class: seekBarMinimizeButton.setImageResource(R.drawable.ic_maximize_button)");

                                ConstraintSet constraintSet = new ConstraintSet();
                                constraintSet.clone(constraintLayout);
                                constraintSet.connect(R.id.seekbar_minimize_button, ConstraintSet.BOTTOM, R.id.fuel_locations_pager, ConstraintSet.TOP);
                                constraintSet.applyTo(constraintLayout);

                                ConstraintSet constraintSet1 = new ConstraintSet();
                                constraintSet1.clone(constraintLayout);
                                constraintSet1.connect(R.id.seekBarValueText, ConstraintSet.BOTTOM, R.id.fuel_locations_pager, ConstraintSet.TOP);
                                constraintSet1.applyTo(constraintLayout);

                                ConstraintSet constraintSet2 = new ConstraintSet();
                                constraintSet2.clone(constraintLayout);
                                constraintSet2.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.fuel_locations_pager, ConstraintSet.TOP);
                                constraintSet2.applyTo(constraintLayout);
                            }
                        }
                    });
                } else {
                    Toast.makeText(context, seekBarValue.getText().toString(), Toast.LENGTH_SHORT).show();
                }
                radiusSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    float radius;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                        Log.d(TAG, "RadiusSeekBar onProgressChanged: GetNearbyPlacesData Class: progress = " + progress);

                        if (progress == 0) {
                            radius = 500;
                            seekBarValue.setText("Radius : 500 M");
                        } else if (progress == 1) {
                            radius = 1000;
                            seekBarValue.setText("Radius : 1 KM");
                        } else if (progress == 2) {
                            radius = 5000;
                            seekBarValue.setText("Radius : 5 KM");
                        } else if (progress == 3) {
                            radius = 10000;
                            seekBarValue.setText("Radius : 10 KM");
                        } else if (progress == 4) {
                            radius = 15000;
                            seekBarValue.setText("Radius : 15 KM");
                        } else if (progress == 5) {
                            radius = 20000;
                            seekBarValue.setText("Radius : 20 KM");
                        } else if (progress == 6) {
                            radius = 25000;
                            seekBarValue.setText("Radius : 25 KM");
                        } else if (progress == 7) {
                            radius = 30000;
                            seekBarValue.setText("Radius : 30 KM");
                        } else if (progress == 8) {
                            radius = 40000;
                            seekBarValue.setText("Radius : 40 KM");
                        } else if (progress == 9) {
                            radius = 50000;
                            seekBarValue.setText("Radius : 50 KM");
                        }

                        Log.d(TAG, "RadiusSeekBar onProgressChanged: GetNearbyPlacesData Class: Radius = " + radius);
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                        Log.d(TAG, "RadiusSeekBar onStartTrackingTouch: GetNearbyPlacesData Class: Called");

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                        Log.d(TAG, "RadiusSeekbar onStopTrackingTouch: GetNearbyPlacesData Class: Radius = " + radius);

                        radiusSearchButton.setVisibility(View.VISIBLE);

                        Log.d(TAG, "RadiusSeekBar onStopTrackingTouch: GetNearbyPlacesData Class: radiusSearchButton.setVisibility(View.VISIBLE)");

                        radiusSearchButton.setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {

                                Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: Button Clicked!");

                                List<Model> models2 = new ArrayList<>();
                                if (!models2.isEmpty()) {

                                    Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2 not empty: models2 = " + models2);

                                    for (int i = 0; i < models2.size(); i++) {
                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2[" + i + "] = " + models2.get(i));
                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2[" + i + "]: " + "Place Name = " + models2.get(i).getPetrol_pump_name() + " | lat = " + models2.get(i).getLatLng().latitude + " | lng = " + models2.get(i).getLatLng().longitude + " | distance = " + models2.get(i).getDistance());
                                    }

                                    models2.removeAll(models);

                                    Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2.clear(): models2 = " + models2);

                                }

                                if (!markerTemp.isEmpty()) {
                                    markerTemp.clear();
                                }

                                progressBar.setVisibility(View.VISIBLE);
                                TranslateAnimation translateAnimation = new TranslateAnimation(0,0,-120, 320);
                                translateAnimation.setDuration(300);
                                translateAnimation.setFillAfter(true);
                                progressBar.startAnimation(translateAnimation);

                                Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: progressBar.setVisibility(View.VISIBLE)");

                                for (int i = 0; i < models.size(); i++) {
                                    if (models.get(i).getDistance() <= radius) {

                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models[" + i + "] <= radius  = " + radius);
                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models[" + i + "]: " + "Place Name = " + models.get(i).getPetrol_pump_name() + " | lat = " + models.get(i).getLatLng().latitude + " | lng = " + models.get(i).getLatLng().longitude + " | distance = " + models.get(i).getDistance());

                                        if (models.get(i).getLatLng() != null) {

                                            Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: Models Added in models2: models[" + i + "]: " + "Place Name = " + models.get(i).getPetrol_pump_name() + " | lat = " + models.get(i).getLatLng().latitude + " | lng = " + models.get(i).getLatLng().longitude + " | distance = " + models.get(i).getDistance());

                                            models2.add(models.get(i));
                                        }
                                        marker = markers.get(i);
                                        marker.setVisible(true);
                                        markerTemp.add(marker);

                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: marker.setVisible(true): marker: lat = " + marker.getPosition().latitude + " | lng = " + marker.getPosition().longitude);

                                    } else {
                                        marker = markers.get(i);
                                        marker.setVisible(false);

                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: Model greater than radius: models[" + i + "]: " + "Place Name = " + models.get(i).getPetrol_pump_name() + " | lat = " + models.get(i).getLatLng().latitude + " | lng = " + models.get(i).getLatLng().longitude + " | distance = " + models.get(i).getDistance());

                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: marker.setVisible(false): marker: lat = " + marker.getPosition().latitude + " | lng = " + marker.getPosition().longitude);
                                    }
                                }

                                Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: Models Size : " + models2.size());

                                fuelLocationPager.setAdapter(null);
                                if (!models2.isEmpty()) {

                                    Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2 != empty");

                                    Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2 = " + models2);

                                    for (int i = 0; i < models2.size(); i++) {
                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2[" + i + "] = " + models2.get(i));
                                        Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: models2[" + i + "]: " + "Place Name = " + models2.get(i).getPetrol_pump_name() + " | lat = " + models2.get(i).getLatLng().latitude + " | lng = " + models2.get(i).getLatLng().longitude + " | distance = " + models2.get(i).getDistance());
                                    }

                                    updateViewPager(models2, markerTemp);
                                } else {
                                    Toast.makeText(context, "No Petrol Pumps found!", Toast.LENGTH_SHORT).show();

                                    Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: Toast shown: toast = No Petrol Pumps found!");

                                    fuelLocationPager.setVisibility(View.GONE);

                                    Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: fuelLocationPager.setVisibility(View.GONE)");

                                    ConstraintSet constraintSet = new ConstraintSet();
                                    constraintSet.clone(constraintLayout);
                                    constraintSet.connect(R.id.radiusSeekBar, ConstraintSet.BOTTOM, R.id.main_constraint, ConstraintSet.BOTTOM);
                                    constraintSet.applyTo(constraintLayout);
                                }
                                translateAnimation = new TranslateAnimation(0,0,320, -120);
                                translateAnimation.setDuration(300);
                                translateAnimation.setFillAfter(true);
                                progressBar.startAnimation(translateAnimation);
                                progressBar.setVisibility(View.GONE);

                                Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: progressBar.setVisibility(View.GONE)");
                            }
                        });
                    }
                });
            }
        });
    }

    // Updates viewPager after dataset change
    private void updateViewPager(final List<Model> models, List<Marker> markerTemp) {

        Log.d(TAG, "updateViewPager: GetNearbyPlacesData Class: Called");
        
        if (fuelLocationPager.getVisibility() == View.GONE) {
            fuelLocationPager.setVisibility(View.VISIBLE);
        }

        Log.d(TAG, "updateViewPager: GetNearbyPlacesData Class: Models Size : " + models.size());

        for (int i = 0; i < models.size(); i++) {
            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: models[" + i + "] = " + models.get(i));
            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: models[" + i + "]: " + "Place Name = " + models.get(i).getPetrol_pump_name() + " | lat = " + models.get(i).getLatLng().latitude + " | lng = " + models.get(i).getLatLng().longitude + " | distance = " + models.get(i).getDistance());
        }


        FuelLocationCardViewAdapter fuelLocationCardViewAdapter = new FuelLocationCardViewAdapter(models,
                coordinatorLayout,
                context,
                behavior,
                fuelPumpDetails,
                fuelLocationPager,
                mMaps,
                currentLocation,
                markerTemp,
                parent);
        fuelLocationPager.setAdapter(fuelLocationCardViewAdapter);
        bottomSheetBehaviourCallback(models, markerTemp);
        fuelLocationCardViewAdapter.notifyDataSetChanged();
        for (int i = 0; i < markers.size(); i++) {
            marker = markers.get(i);
            marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));

            Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: marker: lat = " + marker.getPosition().latitude + " | lng = " + marker.getPosition().longitude);
        }
    }

    // Bottom Sheet Initializer
    private void bottomSheetBehaviourCallback(List<Model> models, List<Marker> markers) {

        final CoordinatorLayout coordinatorLayout;
        RecyclerView recyclerView;

        coordinatorLayout = parent.findViewById(R.id .bottomSheetCoordinatorLayout);
        recyclerView = parent.findViewById(R.id.petrol_pump_list_view);
        recyclerView.setHasFixedSize(false);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        View bottomSheet = parent.findViewById(R.id.bottomSheetBehaviour);
        behavior = BottomSheetBehavior.from(bottomSheet);
        recyclerView.setAdapter(new FuelLocationRecyclerViewAdapter(models, behavior, mMaps,
                fuelLocationPager, markers, context, recyclerView, currentLocation, parent));

    }

    @SuppressLint("SetTextI18n")
    private void setPetrolPumpDetails(int positionTemp) {
        DecimalFormat df = new DecimalFormat("0.00");
        TextView fuelPumpDetailsPetrolPumpName = fuelPumpDetails.findViewById(R.id.fuel_pump_details_petrol_pump_name);
        ImageView fuelPumpDetailsPetrolPumpImage = fuelPumpDetails.findViewById(R.id.fuel_pump_details_petrol_pump_image);
        TextView fuelPumpDetailsAddress = fuelPumpDetails.findViewById(R.id.fuel_pump_details_address);
        RatingBar fuelPumpDetailsRatingBar = fuelPumpDetails.findViewById(R.id.fuel_pump_details_rating_bar);
        TextView fuelPumpDetailsDistance = fuelPumpDetails.findViewById(R.id.fuel_pump_details_distance);

        Log.d(TAG, "setPetrolPumpDetails: GetNearbyPlaces Class: modelsList size = " + models.size());

        if (!models.isEmpty() && positionTemp<models.size()) {
            fuelPumpDetailsPetrolPumpName.setText(models.get(positionTemp).getPetrol_pump_name());
            fuelPumpDetailsDistance.setText("Distance : " + df.format(models.get(positionTemp).getDistance() / 1000) + " KM");
            fuelPumpDetailsRatingBar.setRating(Float.parseFloat(models.get(positionTemp).getRating()));
            fuelPumpDetailsAddress.setText(models.get(positionTemp).getAddress());
            Picasso.get().load(getPhotoURL(models, positionTemp)).error(R.drawable.ic_fuel_pump_spotlight_marker).placeholder(R.drawable.ic_background_red_can).into(fuelPumpDetailsPetrolPumpImage);
        } else {
            Toast.makeText(context, "Models is Empty!", Toast.LENGTH_SHORT).show();
        }
    }

    private String getPhotoURL(List<Model> models, int position) {
        String photo_reference;

        StringBuilder stringBuilder = new StringBuilder("https://maps.googleapis.com/maps/api/place/photo?");
        stringBuilder.append("maxwidth=400");

        if (models.get(position).getPhoto_reference() != null) {
            photo_reference = models.get(position).getPhoto_reference();
            photo_reference = photo_reference.substring(1, photo_reference.length() - 1);
            Log.d(TAG, "getPhotoURL: GetNearbyPlacesData Class: photo_reference = " + photo_reference);
            stringBuilder.append("&reference=" + photo_reference);
        }

        stringBuilder.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        String url = stringBuilder.toString();
        Log.d(TAG, "getPhotoURL: GetNearbyPlacesData Class: Photo_URL = " + url);
        return url;
    }

    private void setOnMarkerClickListener() {
        mMaps.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                if (fuelLocationPager.getVisibility() == View.VISIBLE) {
                    for (int i = 0; i < markers.size(); i++) {
                        Marker marker3 = markers.get(i);
                        marker3.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                    }
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                    fuelLocationPager.setCurrentItem(markers.indexOf(marker));
                    mMaps.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.getPosition(), 12), 400, null);
                } else {
                    marker.showInfoWindow();
                }
                return false;
            }
        });
    }

    private void setBackButton() {
        final ImageButton hamburgerMenuIcon = (ImageButton) parent.findViewById(R.id.hamburger_menu_icon);

        if (fuelLocationPager.getVisibility() == View.VISIBLE) {
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat = AnimatedVectorDrawableCompat.create(context, R.drawable.avd_anim);
            hamburgerMenuIcon.setImageDrawable(animatedVectorDrawableCompat);
            hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_arrow_back_ios_24);
        }

        hamburgerMenuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimatedVectorDrawableCompat animatedVectorDrawableCompat = AnimatedVectorDrawableCompat.create(context, R.drawable.avd_anim_rev);
                hamburgerMenuIcon.setImageDrawable(animatedVectorDrawableCompat);
                hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);
                //markers.removeAll(markers);
                for (Marker marker : markers) {
                    marker.remove();
                }
                for (Marker marker : markerTemp) {
                    marker.remove();
                }
                mMaps.clear();
                markers.clear();
                //markerTemp.clear();
                fuelLocationPager.setVisibility(View.GONE);
                radiusSeekBar.setVisibility(View.GONE);
                seekBarMinimizeButton.setVisibility(View.GONE);
                seekBarValue.setVisibility(View.GONE);
                radiusSearchButton.setVisibility(View.GONE);
                userPreferenceButton.setVisibility(View.GONE);
                
               CoordinatorLayout bottomSheetCoordinatorLayout = (CoordinatorLayout)
                       parent.findViewById(R.id.bottomSheetCoordinatorLayout);

               if (bottomSheetCoordinatorLayout.getVisibility() == View.VISIBLE) {
                   bottomSheetCoordinatorLayout.setVisibility(View.GONE);
               }
                models.clear();
                /*new FuelLocationCardViewAdapter(models,
                        coordinatorLayout,
                        context,
                        behavior,
                        fuelPumpDetails,
                        fuelLocationPager,
                        mMaps,
                        currentLocation,
                        markers,
                        parent).notifyDataSetChanged();*/
                fuelLocationPager.getAdapter().notifyDataSetChanged();

                fuelLocationPager.unregisterOnPageChangeCallback(onPageChangeCallback);
                Log.d(TAG, "setBackButton onClick: GetNearbyPlacesData Class: models Cleared");
                hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);

                InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(parent.getWindowToken(), 0);
                }

                mMaps.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 16), 400, null);
            }
        });
    }

    private void getPumpPreferences() {

        Log.d(TAG, "getPumpPreferences: Maps Activity: Called");

        Gson gson = new Gson();

        Context context = parent.getContext();

        SharedPreferences pumpPreference = context.getSharedPreferences("PUMP_PREFERENCES", Context.MODE_PRIVATE);
        String json = pumpPreference.getString(context.getResources().getString(R.string.selected_pump_pref), null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        selectedPumpPreferences = gson.fromJson(json, type);

        Log.d(TAG, "getPumpPreferences: Maps Activity: Selected Pump Preference is: selectedPumpPreference = " + selectedPumpPreferences);
    }

    private void setUserPreferenceListener() {
        userPreferenceButton = (ImageButton) parent.findViewById(R.id.user_preference_button);
        if (userPreferenceButton.getVisibility() == View.GONE) {
            userPreferenceButton.setVisibility(View.VISIBLE);
        }
        userPreferenceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isClicked) {
                    if (selectedPumpPreferences == null) {
                        Toast.makeText(parent.getContext(), "No User Preferred Petrol Pumps!", Toast.LENGTH_SHORT).show();
                    } else {
                        fuelLocationPager.setAdapter(null);

                        List<Model> modelsTemp = new ArrayList<>();
                        List<Marker> markerTemp = new ArrayList<>();
                        Boolean no = false;

                        for (int i=0; i<models.size(); i++) {
                            for (String petrolPump : selectedPumpPreferences) {
                                if (models.get(i).getPetrol_pump_name().contains(petrolPump)) {
                                    if (models.get(i).getLatLng() != null) {
                                        modelsTemp.add(models.get(i));
                                        marker = markers.get(i);
                                        marker.setVisible(true);
                                        markerTemp.add(marker);
                                        no = true;
                                        break;
                                    }
                                }
                            }
                            if (!no) {
                                marker = markers.get(i);
                                marker.setVisible(false);
                                no = false;
                            }
                        }

                        if (modelsTemp.size() == 0) {
                            Toast.makeText(parent.getContext(), "No User Preferred Petrol Pumps found on Route!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(parent.getContext(), "Showing User Preferred Petrol Pumps!", Toast.LENGTH_SHORT).show();
                            updateViewPager(modelsTemp, markerTemp);
                            ObjectAnimator flip = ObjectAnimator.ofFloat(userPreferenceButton, "rotationY", 0f, 180f);
                            flip.setDuration(300);
                            flip.start();

                            userPreferenceButton.setImageResource(R.drawable.ic_round_account_circle_24);
                            isClicked = true;
                        }
                    }
                } else {
                    for(Marker marker : markers) {
                        marker.setVisible(true);
                    }
                    Toast.makeText(parent.getContext(), "Show All Petrol Pumps!", Toast.LENGTH_SHORT).show();
                    ObjectAnimator flip = ObjectAnimator.ofFloat(userPreferenceButton, "rotationY", 0f, 180f);
                    flip.setDuration(300);
                    flip.start();
                    userPreferenceButton.setImageResource(R.drawable.ic_round_add_circle_24);
                    isClicked=false;
                    updateViewPager(models, markers);
                }
            }
        });
    }
}
