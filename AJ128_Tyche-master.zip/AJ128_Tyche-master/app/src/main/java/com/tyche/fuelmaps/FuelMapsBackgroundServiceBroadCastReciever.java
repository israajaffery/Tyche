package com.tyche.fuelmaps;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.RemoteInput;

import static com.tyche.fuelmaps.MapsActivity.CHANNEL_ID;

public class FuelMapsBackgroundServiceBroadCastReciever extends BroadcastReceiver {

    private static final String KEY_TEXT_DESTINATION = "KEY_TEXT_DESTINATION";
    private String TAG = "FuelMapsBackgroundServiceBroadCastReciever";

    public FuelMapsBackgroundServiceBroadCastReciever() {
        super();
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        String action = intent.getStringExtra("Stop");

        CharSequence destination = getMessageText(intent);
        Log.d(TAG, "onReceive: destination = " + destination);

    }

    @Override
    public IBinder peekService(Context myContext, Intent service) {
        return super.peekService(myContext, service);
    }

    private CharSequence getMessageText(Intent intent) {
        Bundle remoteInput = RemoteInput.getResultsFromIntent(intent);
        if(remoteInput != null){
            return remoteInput.getCharSequence(KEY_TEXT_DESTINATION);
        }
        return null;
    }
}
