package com.tyche.fuelmaps.adapter;

import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.hardware.input.InputManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.PhotoMetadata;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.api.net.FetchPhotoRequest;
import com.google.android.libraries.places.api.net.FetchPhotoResponse;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FetchPlaceResponse;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.tyche.fuelmaps.GetDirectionData;
import com.tyche.fuelmaps.MapsActivity;
import com.tyche.fuelmaps.R;
import com.tyche.fuelmaps.models.AutoCompleteModel;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AutoCompleteRecyclerViewAdapter extends RecyclerView.Adapter<AutoCompleteRecyclerViewAdapter.AutoCompleteRecyclerViewHolder> {

    List<AutoCompleteModel> autocompleteModel;
    Context context;
    GoogleMap mMap;
    ViewGroup parent;
    ImageButton gpsLocateMe;
    EditText searchEditText;
    CardView placeInfoCardView;
    Bitmap placePhoto;
    Place place;
    LatLng currentLocation;
    ConstraintLayout constraintLayout;
    ConstraintLayout autocompleteRecyclerConstraint;
    ImageButton hamburgerMenuIcon;
    ImageView profile_image;
    ImageButton searchTextClearButton;
    RecyclerView autocompleteRecyclerView;
    ImageView autocompleteRecyclerViewSearchImage;
    TextView autocompleteRecyclerViewSearchText;
    ImageButton showNearByPetrolPumpsButton;

    String TAG = "AutoCompleteRecyclerViewAdapter";

    public AutoCompleteRecyclerViewAdapter(List<AutoCompleteModel> autocompleteModel,
                                           Context context,
                                           GoogleMap mMap,
                                           ViewGroup parent,
                                           ConstraintLayout constraintLayout,
                                           LatLng currentLocation) {
        this.autocompleteModel = autocompleteModel;
        this.context = context;
        this.mMap = mMap;
        this.currentLocation = currentLocation;
        this.parent = parent;
        this.constraintLayout = constraintLayout;
    }

    @NonNull
    @Override
    public AutoCompleteRecyclerViewAdapter.AutoCompleteRecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.autocomplete_recycler_view_item, parent, false);
        return new AutoCompleteRecyclerViewAdapter.AutoCompleteRecyclerViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final AutoCompleteRecyclerViewAdapter.AutoCompleteRecyclerViewHolder holder, int position) {

        holder.setAutoCompleteText(autocompleteModel.get(position));

        gpsLocateMe = (ImageButton) parent.findViewById(R.id.gps_locate_me_button);

        searchEditText = (EditText) parent.findViewById(R.id.search_text_view);

        holder.primaryText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: Primary Text CLicked");
                String placeID = autocompleteModel.get(holder.getAdapterPosition()).getPlaceID();

                showPlace(placeID, holder.getAdapterPosition());

                Log.d(TAG, "onClick: placeID = " + placeID);
            }
        });
        holder.secondaryText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String placeID = autocompleteModel.get(holder.getAdapterPosition()).getPlaceID();
                showPlace(placeID, holder.getAdapterPosition());
                Log.d(TAG, "onClick: placeID = " + placeID);
            }
        });
        holder.distance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String placeID = autocompleteModel.get(holder.getAdapterPosition()).getPlaceID();
                showPlace(placeID, holder.getAdapterPosition());
                Log.d(TAG, "onClick: placeID = " + placeID);
            }
        });
        holder.showOnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String placeID = autocompleteModel.get(holder.getAdapterPosition()).getPlaceID();
                showPlace(placeID, holder.getAdapterPosition());
                Log.d(TAG, "onClick: placeID = " + placeID);
            }
        });
        holder.placeAutoCompletePredictionItemConstraint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String placeID = autocompleteModel.get(holder.getAdapterPosition()).getPlaceID();
                showPlace(placeID, holder.getAdapterPosition());
                Log.d(TAG, "onClick: placeID = " + placeID);
            }
        });
    }

    @Override
    public int getItemCount() {
        return autocompleteModel.size();
    }


    public class AutoCompleteRecyclerViewHolder extends RecyclerView.ViewHolder {

        TextView primaryText, secondaryText, distance;
        ImageView showOnMap;
        ConstraintLayout placeAutoCompletePredictionItemConstraint;

        public AutoCompleteRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            primaryText = itemView.findViewById(R.id.place_autocomplete_prediction_primary_text);
            secondaryText =
                    itemView.findViewById(R.id.place_autocomplete_prediction_secondary_text);
            distance = itemView.findViewById(R.id.place_autocomplete_prediction_distance_text);
            showOnMap = itemView.findViewById(R.id.show_on_map);
            placeAutoCompletePredictionItemConstraint = (ConstraintLayout)
                    itemView.findViewById(R.id.place_autocomplete_prediction_item_constraint);
        }

        void setAutoCompleteText(AutoCompleteModel autocompleteModel) {

            primaryText.setText(autocompleteModel.getPrimaryText());

            secondaryText.setText(autocompleteModel.getSecondaryText());

            DecimalFormat formatter = new DecimalFormat("#,###,###");

            String distanceKM = formatter.format(autocompleteModel.getDistance()/1000);

            distance.setText("Distance: " + distanceKM + " KM");

        }
    }

    private void showPlace(String s, final int adapterPosition) {

        if (gpsLocateMe.getVisibility() == View.INVISIBLE) {
            gpsLocateMe.setVisibility(View.VISIBLE);
        }

        InputMethodManager imm =
                (InputMethodManager) context.getSystemService(MapsActivity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(parent.getWindowToken(), 0);

        Places.initialize(context, "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        final PlacesClient placesClient = Places.createClient(context);

        mMap.clear();

        final List<com.google.android.libraries.places.api.model.Place.Field> placeFields =
                Arrays.asList(com.google.android.libraries.places.api.model.Place.Field.ID,
                Place.Field.NAME, Place.Field.LAT_LNG);

        final FetchPlaceRequest request = FetchPlaceRequest.newInstance(s, placeFields);

        placesClient.fetchPlace(request).addOnSuccessListener(new OnSuccessListener<FetchPlaceResponse>() {
            @Override
            public void onSuccess(FetchPlaceResponse fetchPlaceResponse) {
                Marker marker;
                place = fetchPlaceResponse.getPlace();
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.icon(bitmapDescriptorFromVector(context,
                        R.drawable.ic_fuel_pump_spotlight_marker));
                markerOptions.position(place.getLatLng());
                marker = mMap.addMarker(markerOptions);

                ConstraintLayout constraintLayout =
                        (ConstraintLayout) parent.findViewById(R.id.autocomplete_constraint);
                if (constraintLayout.getVisibility() == View.VISIBLE) {
                    constraintLayout.setVisibility(View.GONE);
                }


                searchEditText.setText(place.getName());
                searchEditText.setFocusableInTouchMode(false);
                searchEditText.setFocusable(false);
                searchEditText.clearFocus();

                final ImageView placeInfoPlacePhoto =
                        (ImageView) parent.findViewById(R.id.place_info_place_photo);

                final CardView placeInfoPlacePhotoCardView = (CardView)
                        parent.findViewById(R.id.place_info_place_photo_card_view);

                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 15), 800,
                        null);

                final List<PhotoMetadata> metadata = fetchPlaceResponse.getPlace().getPhotoMetadatas();
                if (metadata == null || metadata.isEmpty()) {
                    Log.d(TAG, "No photo metadata.");
                    placeInfoPlacePhotoCardView.setVisibility(View.GONE);
                    return;
                }
                final PhotoMetadata photoMetadata = metadata.get(0);

                final String attributions = photoMetadata.getAttributions();

                final FetchPhotoRequest photoRequest = FetchPhotoRequest.builder(photoMetadata)
                        .setMaxWidth(500)
                        .setMaxHeight(300)
                        .build();

                placesClient.fetchPhoto(photoRequest).addOnSuccessListener(new OnSuccessListener<FetchPhotoResponse>() {
                    @Override
                    public void onSuccess(FetchPhotoResponse fetchPhotoResponse) {
                        placePhoto = fetchPhotoResponse.getBitmap();
                        placeInfoPlacePhoto.setImageBitmap(placePhoto);
                        Log.d(TAG, "onSuccess: Place Photo Fetched");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        if (exception instanceof ApiException) {
                            final ApiException apiException = (ApiException) exception;
                            Log.d(TAG, "Place not found: " + exception.getMessage());
                            final int statusCode = apiException.getStatusCode();
                        }
                    }
                });


            }
        });

        DecimalFormat formatter = new DecimalFormat("#,###,###");

        String distance = "Distance : " +
                formatter.format(autocompleteModel.get(adapterPosition).getDistance()/1000) + " KM";

        setPlaceInfo(autocompleteModel.get(adapterPosition).getPrimaryText(),
                autocompleteModel.get(adapterPosition).getSecondaryText(),
                distance);
    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: Called");

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: vectorResId = " + vectorResId);

        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        assert vectorDrawable != null;
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void setPlaceInfo(String placeName, String placeAddress, String placeDistance) {
        placeInfoCardView = (CardView) parent.findViewById(R.id.place_info_card_view);

        final ImageButton gpsLocateMe  = parent.findViewById(R.id.gps_locate_me_button);
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(constraintLayout);
        constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.place_info_card_view,
                ConstraintSet.TOP);
        constraintSet.applyTo(constraintLayout);

        TextView placeInfoPlaceName = (TextView) parent.findViewById(R.id.place_info_place_name);
        placeInfoPlaceName.setText(placeName);

        TextView placeInfoPlaceAddress = (TextView) parent.findViewById(R.id.place_info_place_address);
        placeInfoPlaceAddress.setText(placeAddress);

        TextView placeInfoPlaceDistance = (TextView) parent.findViewById(R.id.place_info_place_distance_text);
        placeInfoPlaceDistance.setText(placeDistance);

        TextView placeInfoPlaceTime = (TextView) parent.findViewById(R.id.place_info_place_time_text);

        ConstraintLayout placeInfoPlaceTimeConstraint = parent.findViewById(R.id.place_info_time_text_constraint);
        placeInfoPlaceTimeConstraint.setVisibility(View.GONE);

        ImageButton gpsLocatePlace = parent.findViewById(R.id.place_info_locate_place_button);
        gpsLocatePlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 15));
            }
        });

        final ImageButton getDirections = (ImageButton) parent.findViewById(R.id.place_info_place_get_directions);
        if (getDirections.getVisibility() == View.GONE) {
            getDirections.setVisibility(View.VISIBLE);
        }

        final Button placeInfoStartJourney = parent.findViewById(R.id.place_info_start_journey);
        placeInfoStartJourney.setVisibility(View.GONE);

        getDirections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LatLng destination = place.getLatLng();
                List<Marker> markers = null;

                Object[] dataTransfer = new Object[6];
                dataTransfer[0] = currentLocation;
                dataTransfer[1] = destination;
                dataTransfer[2] = mMap;
                dataTransfer[3] = markers;
                dataTransfer[4] = parent;
                dataTransfer[5] = context;

                GetDirectionData getDirectionData = new GetDirectionData();
                getDirectionData.execute(dataTransfer);

                getDirections.setVisibility(View.GONE);
                Animation aniFadeOut = AnimationUtils.loadAnimation(context, R.anim.fade_out);
                getDirections.startAnimation(aniFadeOut);
            }
        });

        /*ImageButton getNearbyPetrolPumps = parent.findViewById(R.id.place_info_place_nearby_fuel_pumps);
        getNearbyPetrolPumps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/

        if (placeInfoCardView.getVisibility() ==  View.GONE) {
            placeInfoCardView.setVisibility(View.VISIBLE);
            TranslateAnimation translateAnimation = new TranslateAnimation(0,0,600,0);
            translateAnimation.setDuration(300);
            translateAnimation.setFillAfter(true);
            translateAnimation.setInterpolator(parent.getContext(), android.R.interpolator.linear);

            placeInfoCardView.startAnimation(translateAnimation);
        }

        autocompleteRecyclerConstraint = parent.findViewById(R.id.autocomplete_constraint);
        hamburgerMenuIcon = parent.findViewById(R.id.hamburger_menu_icon);
        profile_image = parent.findViewById(R.id.profile_image);
        searchTextClearButton = parent.findViewById(R.id.search_text_clear_button);
        autocompleteRecyclerView = parent.findViewById(R.id.autocomplete_recycler_view);
        autocompleteRecyclerViewSearchImage = parent.findViewById(R.id.autocomplete_recycler_view_search_image);
        autocompleteRecyclerViewSearchText = parent.findViewById(R.id.autocomplete_recycler_view_search_text);
        showNearByPetrolPumpsButton = parent.findViewById(R.id.show_nearby_petrol_pumps);

        final EditText searchTextView = parent.findViewById(R.id.search_text_view);
        searchTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "onClick: searchTextView");

                if (autocompleteRecyclerConstraint.getVisibility() == View.GONE) {
                    autocompleteRecyclerConstraint.setVisibility(View.VISIBLE);
                    slideView(autocompleteRecyclerConstraint, convertDPtoPix(50), convertDPtoPix(400),
                            250);
                }
                searchTextView.setFocusable(true);
                searchTextView.setFocusableInTouchMode(true);
                searchTextView.requestFocus();
                hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_arrow_back_ios_24);
                profile_image.setVisibility(View.INVISIBLE);
                searchTextClearButton.setVisibility(View.VISIBLE);

                if (autocompleteRecyclerView.getVisibility() == View.VISIBLE) {
                    autocompleteRecyclerView.setVisibility(View.INVISIBLE);
                }

                if (autocompleteRecyclerViewSearchImage.getVisibility() == View.INVISIBLE && autocompleteRecyclerViewSearchText.getVisibility() == View.INVISIBLE) {
                    autocompleteRecyclerViewSearchImage.setVisibility(View.VISIBLE);
                    autocompleteRecyclerViewSearchText.setVisibility(View.VISIBLE);
                }

                gpsLocateMe.setVisibility(View.INVISIBLE);
                showNearByPetrolPumpsButton.setVisibility(View.INVISIBLE);

                Context context = parent.getContext();
                InputMethodManager inputMethodManager =
                        (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);

                if (inputMethodManager != null) {
                    inputMethodManager.showSoftInput(searchTextView,
                            InputMethodManager.SHOW_IMPLICIT);
                }

                searchTextView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                            getPredictions(searchTextView.getText().toString());
                            return true;
                        }
                        return false;
                    }
                });

                searchTextView.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        String string = s.toString();
                        getPredictions(string);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });

                hamburgerMenuIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Context context = parent.getContext();

                        mMap.clear();

                        hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);

                        searchTextView.clearFocus();

                        searchTextView.setText("");

                        searchTextView.setFocusableInTouchMode(false);
                        searchTextView.setFocusable(false);

                        gpsLocateMe.setVisibility(View.VISIBLE);
                        showNearByPetrolPumpsButton.setVisibility(View.VISIBLE);


                        if (autocompleteRecyclerConstraint.getVisibility() == View.VISIBLE) {
                            autocompleteRecyclerConstraint.setVisibility(View.GONE);
                            slideView(autocompleteRecyclerConstraint, convertDPtoPix(400),
                                    convertDPtoPix(50),
                                    250);
                        }

                        InputMethodManager imm =
                                (InputMethodManager) parent.getContext().getSystemService(Activity.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.hideSoftInputFromWindow(parent.getWindowToken(), 0);
                        }

                        ConstraintSet constraintSet = new ConstraintSet();
                        constraintSet.clone(constraintLayout);
                        constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM,
                                R.id.main_constraint,
                                ConstraintSet.BOTTOM);
                        constraintSet.applyTo(constraintLayout);

                        profile_image.setVisibility(View.VISIBLE);
                        searchTextClearButton.setVisibility(View.GONE);

                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.latitude, currentLocation.longitude),17));

                        if (placeInfoCardView.getVisibility() == View.VISIBLE) {
                            TranslateAnimation translateAnimation = new TranslateAnimation(0,0,0,600);
                            translateAnimation.setDuration(300);
                            translateAnimation.setFillAfter(true);
                            translateAnimation.setInterpolator(parent.getContext(), android.R.interpolator.linear);

                            placeInfoCardView.startAnimation(translateAnimation);

                            placeInfoCardView.setVisibility(View.GONE);
                        }
                        //autocompleteRecyclerConstraint.setVisibility(View.GONE);
                    }
                });

                searchTextClearButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (searchTextView.getText().length() > 0) {
                            searchTextView.getText().clear();
                        } else {
                            hamburgerMenuIcon.performClick();
                        }
                    }
                });
            }
        });

    }

    public LatLng getPlaceLatLng() {
        return place.getLatLng();
    }

    public static void slideView(final View view,
                                 int currentHeight,
                                 int newHeight,
                                 int duration) {

        ValueAnimator slideAnimator = ValueAnimator
                .ofInt(currentHeight, newHeight)
                .setDuration(duration);

        slideAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                Integer value = (Integer) animation.getAnimatedValue();
                view.getLayoutParams().height = value.intValue();
                view.requestLayout();
            }
        });

        AnimatorSet animationSet = new AnimatorSet();
        animationSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animationSet.setDuration(duration);
        animationSet.play(slideAnimator);
        animationSet.start();
    }

    private int convertDPtoPix(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                parent.getResources().getDisplayMetrics());
    }

    private void getPredictions(String s) {

        AutocompleteSessionToken token = AutocompleteSessionToken.newInstance();

        autocompleteRecyclerView.setVisibility(View.VISIBLE);
        autocompleteRecyclerViewSearchImage.setVisibility(View.INVISIBLE);
        autocompleteRecyclerViewSearchText.setVisibility(View.INVISIBLE);

        RectangularBounds bounds = RectangularBounds.newInstance(
                new LatLng(23.63936, 68.14712),
                new LatLng(28.20453, 97.34466)
        );

        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setLocationBias(bounds)
                .setTypeFilter(TypeFilter.CITIES)
                .setOrigin(new LatLng(currentLocation.latitude, currentLocation.longitude))
                .setSessionToken(token)
                .setQuery(s)
                .build();

        Places.initialize(parent.getContext(), "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        PlacesClient placesClient = Places.createClient(parent.getContext());

        placesClient.findAutocompletePredictions(request).addOnSuccessListener(new OnSuccessListener<FindAutocompletePredictionsResponse>() {
            List<AutoCompleteModel> autoCompleteModelList = new ArrayList<>();

            @Override
            public void onSuccess(FindAutocompletePredictionsResponse findAutocompletePredictionsResponse) {

                for(AutocompletePrediction prediction :
                        findAutocompletePredictionsResponse.getAutocompletePredictions()) {
                    String primaryText = prediction.getPrimaryText(null).toString();
                    String secondaryText = prediction.getSecondaryText(null).toString();
                    //int distance = prediction.getDistanceMeters();
                    String placeID = prediction.getPlaceId();
                    int distance;
                    if (prediction.getDistanceMeters() != null) {
                        distance = (int) prediction.getDistanceMeters();
                        Log.d(TAG, "onSuccess: distance = " + distance);
                    } else {
                        distance = 0;
                    }

                    autoCompleteModelList.add(new AutoCompleteModel(primaryText,
                            secondaryText, distance, placeID));

                    Log.i(TAG, prediction.getPlaceId());
                    Log.i(TAG, prediction.getPrimaryText(null).toString());
                }

                LinearLayoutManager linearLayoutManager =
                        new LinearLayoutManager(parent.getContext());

                /*ImageView autocompleteRecyclerViewSearchImage =
                        findViewById(R.id.autocomplete_recycler_view_search_image);
                autocompleteRecyclerViewSearchImage.setVisibility(View.GONE);*/

                AutoCompleteRecyclerViewAdapter autoCompleteRecyclerViewAdapter = new AutoCompleteRecyclerViewAdapter(autoCompleteModelList,
                        context,
                        mMap,
                        parent,
                        constraintLayout,
                        new LatLng(currentLocation.latitude, currentLocation.longitude));

                autocompleteRecyclerView.setAdapter(autoCompleteRecyclerViewAdapter);
                autocompleteRecyclerView.setLayoutManager(linearLayoutManager);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                if (exception instanceof ApiException) {
                    ApiException apiException = (ApiException) exception;
                    Log.e(TAG, "Place not found: " + apiException.getStatusCode());
                }
            }
        });
    }
}
