package com.tyche.fuelmaps.models;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.android.gms.maps.model.LatLng;

public class Model implements Parcelable {

    private int petrol_pump_image;
    private String petrol_pump_name;
    private String location_type;
    private String address;
    private LatLng latLng;
    private String rating;
    private float distance;
    private String photo_reference;

    public Model(int petrol_pump_image, String petrol_pump_name, String location_type, String address, LatLng latLng, Float distance, String rating, String photo_reference) {
        this.petrol_pump_image = petrol_pump_image;
        this.petrol_pump_name = petrol_pump_name;
        this.location_type = location_type;
        this.address = address;
        this.latLng = latLng;
        this.distance = distance;
        this.rating = rating;
        this.photo_reference = photo_reference;
    }

    protected Model(Parcel in) {
        petrol_pump_image = in.readInt();
        petrol_pump_name = in.readString();
        location_type = in.readString();
        address = in.readString();
        latLng = in.readParcelable(LatLng.class.getClassLoader());
        rating = in.readString();
        distance = in.readFloat();
        photo_reference = in.readString();
    }

    public static final Creator<Model> CREATOR = new Creator<Model>() {
        @Override
        public Model createFromParcel(Parcel in) {
            return new Model(in);
        }

        @Override
        public Model[] newArray(int size) {
            return new Model[size];
        }
    };

    public int getPetrol_pump_image() {
        return petrol_pump_image;
    }

    public void setPetrol_pump_image(int petrol_pump_image) {
        this.petrol_pump_image = petrol_pump_image;
    }

    public String getPetrol_pump_name() {
        return petrol_pump_name;
    }

    public void setPetrol_pump_name(String petrol_pump_name) {
        this.petrol_pump_name = petrol_pump_name;
    }

    public String getLocation_type() {
        return location_type;
    }

    public void setLocation_type(String location_type) {
        this.location_type = location_type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LatLng getLatLng() {
        return latLng;
    }

    public void setLatLng(LatLng latLng) {
        this.latLng = latLng;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPhoto_reference() {
        return photo_reference;
    }

    public void setPhoto_reference(String photo_reference) {
        this.photo_reference = photo_reference;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(petrol_pump_image);
        dest.writeString(petrol_pump_name);
        dest.writeString(location_type);
        dest.writeString(address);
        dest.writeParcelable(latLng, flags);
        dest.writeString(rating);
        dest.writeFloat(distance);
        dest.writeString(photo_reference);
    }
}
