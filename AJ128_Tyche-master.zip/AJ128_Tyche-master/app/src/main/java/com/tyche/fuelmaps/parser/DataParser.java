package com.tyche.fuelmaps.parser;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class DataParser {

    String TAG = "Fuel Maps";
    String TAG2 = "DataParser Class:";

    private HashMap<String, String> getPlace(JSONObject googlePlaceJson) {

        // Variables
        HashMap<String, String> googlePlaceMap = new HashMap<>();
        String placeName = "-NA-";
        String vicinity = "-NA-";
        String latitude = "";
        String longitude = "";
        String reference  = "";
        String rating = "-NA-";
        String nextPageToken = "";
        String[] photos;

        Log.d(TAG, "getPlace: " + TAG2 + "Called");

        try {
            if (!googlePlaceJson.isNull("name")) {
                placeName = googlePlaceJson.getString("name");
            }
            if (!googlePlaceJson.isNull("vicinity")) {
                vicinity = googlePlaceJson.getString(   "vicinity");
            }
            latitude = googlePlaceJson.getJSONObject("geometry").getJSONObject("location").getString("lat");
            longitude= googlePlaceJson.getJSONObject("geometry").getJSONObject("location").getString("lng");

            reference = googlePlaceJson.getString("reference");

            rating = googlePlaceJson.getString("rating");

            if (!latitude.isEmpty() && !longitude.isEmpty() && latitude != null && longitude != null) {
                googlePlaceMap.put("place_name", placeName);
                googlePlaceMap.put("vicinity", vicinity);
                googlePlaceMap.put("lat", latitude);
                googlePlaceMap.put("lng", longitude);
                googlePlaceMap.put("reference", reference);
                googlePlaceMap.put("rating", rating);
            }

            JSONArray jsonArray = googlePlaceJson.getJSONArray("photos");
            photos = new String[jsonArray.length()];
            for(int i=0; i < jsonArray.length(); i++) {
                photos[i] = jsonArray.getString(i);
            }

            String photo_reference = photos[0];
            photo_reference = photo_reference.replace("[]{}", "");
            photos[0] = "";
            photos = photo_reference.split(",");
            String[] photo_temp = photos[2].split(":");
            photo_reference = photo_temp[1].trim();

            Log.d(TAG, "getPlace: Data Parser: photos = " + Arrays.toString(photos));
            Log.d(TAG, "getPlace: Data Parser: photos = " + photo_reference);

            googlePlaceMap.put("photo_reference", photo_reference);
            Log.d(TAG, "getPlace: " + TAG2 + " googlePlaceJson: PlaceName = " + placeName + " | lat = " + latitude + " | lng = " + longitude + " | rating = " + rating);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return googlePlaceMap;
    }

    private List<HashMap<String, String>> getPlaces(JSONArray jsonArray){

        Log.d(TAG, "getPlaces: " + TAG2 + " Called");

        int count = jsonArray.length();
        List<HashMap<String, String>> placesList = new ArrayList<>();
        HashMap<String, String> placeMap = null;

        for(int i = 0; i < count; i++) {
            try {
                placeMap = getPlace((JSONObject) jsonArray.get(i));
                placesList.add(placeMap);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        for (int i = 0; i < placesList.size(); i++) {
            Log.d(TAG, "getPlaces: " + TAG2 + " placeList[" + i + "] = " + placesList.get(i));
        }

        return placesList;
    }

    public List<HashMap<String, String>> parse(String jsonData) {

        Log.d(TAG, "parse: " + TAG2 + " Called");

        JSONArray jsonArray = null;
        JSONObject jsonObject;

        try {
            jsonObject = new JSONObject(jsonData);
            jsonArray = jsonObject.getJSONArray("results");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return getPlaces(jsonArray);
    }

    public List<Object> parseDirections(String jsonData) {
        JSONArray jsonArray = null;
        JSONObject jsonObject;

        Log.d(TAG, "parseDirections: " + TAG2 + " Called");

        try {
            jsonObject = new JSONObject(jsonData);
            jsonArray = jsonObject.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").getJSONObject(0).getJSONArray("steps");

            Log.d(TAG, "parseDirections: " + TAG2 + " jsonArray = " + jsonArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String duration = "";
        String distance = "";
        String durationValue = "";

        try {
            jsonObject = new JSONObject(jsonData);
            JSONArray jsonArray2 = jsonObject.getJSONArray("routes").getJSONObject(0).getJSONArray("legs");
            duration = jsonArray2.getJSONObject(0).getJSONObject("duration_in_traffic").getString("text");
            distance = jsonArray2.getJSONObject(0).getJSONObject("distance").getString("text");
            durationValue = jsonArray2.getJSONObject(0).getJSONObject("duration_in_traffic").getString("value");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.d(TAG, "parseDirections: duration = " + duration);
        Log.d(TAG, "parseDirections: duration value = " + durationValue);

        List<Object> polyLines = new ArrayList<>();
        polyLines = getPaths(jsonArray);
        polyLines.add(distance);
        polyLines.add(duration);

        return polyLines;
    }

    public List<Object> getPaths(JSONArray googleStepsJSON) {

        Log.d(TAG, "getPaths: " + TAG2 + " Called");

        Log.d(TAG, "getPaths: " + TAG2 + " googleStepsJSON = " + googleStepsJSON);

        int count = googleStepsJSON.length();
        String[] polylines = new String[count];

        for (int i = 0; i < googleStepsJSON.length(); i++) {
            try {
                polylines[i] = getPath(googleStepsJSON.getJSONObject(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        List<Object> polyLines = new ArrayList<Object>();
        polyLines.add(polylines);

        return polyLines;
    }

    private String getPath(JSONObject googlePathJSON) {

        Log.d(TAG, "getPath: " + TAG2 + " Called");

        String polyline = "";

        Log.d(TAG, "getPath: "  + TAG2 + " googlePathJSON = " + googlePathJSON);

        try {
            polyline = googlePathJSON.getJSONObject("polyline").getString("points");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return polyline;
    }

    private HashMap<String, String> getDirectionsData(JSONArray googleDirectionsJSONArray) {
        HashMap<String, String> googleDirectionsMap = new HashMap<>();

        String duration = "";
        String distance = "";

        try {
            duration = googleDirectionsJSONArray.getJSONObject(0).getJSONObject("duration").getString("text");
            distance = googleDirectionsJSONArray.getJSONObject(0).getJSONObject("distance").getString("text");

            googleDirectionsMap.put("duration", duration);
            googleDirectionsMap.put("distance", distance);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return googleDirectionsMap;
    }
}
