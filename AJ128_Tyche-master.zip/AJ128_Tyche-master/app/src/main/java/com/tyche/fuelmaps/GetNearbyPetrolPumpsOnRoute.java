package com.tyche.fuelmaps;

import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.AsyncTask;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.maps.android.PolyUtil;
import com.google.maps.android.clustering.ClusterManager;
import com.squareup.picasso.Picasso;
import com.tyche.fuelmaps.adapter.FuelLocationCardViewAdapter;
import com.tyche.fuelmaps.adapter.FuelLocationRecyclerViewAdapter;
import com.tyche.fuelmaps.models.Model;
import com.tyche.fuelmaps.parser.DataParser;
import com.tyche.fuelmaps.transformer.ZoomOutPageTransformer;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GetNearbyPetrolPumpsOnRoute extends AsyncTask<Object, Integer, List<Model>> {

    // Vars
    String TAG = "GetNearbyPetrolPumpsOnRoute";
    ViewGroup parent;
    GoogleMap mMap;
    String[] polylines;
    ImageButton hamburgerMenuIcon;
    LatLng currentLocation;
    String polyline;
    EditText searchTextView;
    ImageButton gpsLocateMe;
    ImageButton showNearByPetrolPumpsButton;
    ConstraintLayout autocompleteRecyclerConstraint;
    ConstraintLayout constraintLayout;
    ImageView profile_image;
    ImageButton searchTextClearButton;
    CardView placeInfoCardView;
    ViewPager2 fuelLocationPager;
    BottomSheetBehavior behavior;
    List<LatLng> latLngList = new ArrayList<>();
    int PROXIMITY_RADIUS = 500;
    DownloadURL downloadURL = new DownloadURL();
    List<HashMap<String, String> > nearbyPlacesListMaster = new ArrayList<>();
    List<Marker> markers = new ArrayList<Marker>();
    List<Model> modelsList = new ArrayList<Model>();
    List<LatLng> finalLatLngList = new ArrayList<LatLng>();
    Marker marker;
    OnPageChangeCallback onPageChangeCallback;
    CoordinatorLayout fuelPumpDetails;
    List<String> selectedPumpPreferences = new ArrayList<>();
    List<Model> models = new ArrayList<>();
    ImageButton userPreferenceButton;
    Boolean isClicked = false;

    public GetNearbyPetrolPumpsOnRoute(ViewGroup parent, GoogleMap mMap, LatLng currentLocation) {
        this.parent = parent;
        this.mMap = mMap;
        this.currentLocation = currentLocation;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        Log.d(TAG, "onPreExecute: Called");

        ProgressBar progressBar = parent.findViewById(R.id.progressBar);

        progressBar.setVisibility(View.VISIBLE);
        TranslateAnimation translateAnimation = new TranslateAnimation(0,0,-120, 320);
        translateAnimation.setDuration(300);
        translateAnimation.setFillAfter(true);
        progressBar.startAnimation(translateAnimation);

        hamburgerMenuIcon = parent.findViewById(R.id.hamburger_menu_icon);
        searchTextView = parent.findViewById(R.id.search_text_view);
        gpsLocateMe = parent.findViewById(R.id.gps_locate_me_button);
        showNearByPetrolPumpsButton = parent.findViewById(R.id.show_nearby_petrol_pumps);
        autocompleteRecyclerConstraint = parent.findViewById(R.id.autocomplete_constraint);
        constraintLayout = parent.findViewById(R.id.main_constraint);
        profile_image = parent.findViewById(R.id.profile_image);
        searchTextClearButton = parent.findViewById(R.id.search_text_clear_button);
        placeInfoCardView = parent.findViewById(R.id.place_info_card_view);
        fuelLocationPager = parent.findViewById(R.id.fuel_locations_pager);

        Log.d(TAG, "onPreExecute: Progress bar Shown.");

        getPumpPreferences();

    }

    @Override
    protected List<Model> doInBackground(Object... objects) {

        Log.d(TAG, "doInBackground: Called");

        polylines = (String[]) objects[0];

        Log.d(TAG, "doInBackground: polyline Passed: polyline = " + Arrays.toString(polylines));

        for (String polyline : polylines) {
            latLngList.addAll(PolyUtil.decode(polyline));
        }

        finalLatLngList.add(latLngList.get(0));

        for (int i = 0; i<latLngList.size(); i++) {
            for (int k = i + 1; k<latLngList.size(); k++) {
                float[] result = new float[1];
                Location.distanceBetween(latLngList.get(i).latitude, latLngList.get(i).longitude, latLngList.get(k).latitude, latLngList.get(k).longitude, result);

                if (result[0] >= 1000) {
                    i = k;
                    finalLatLngList.add(latLngList.get(k));
                    break;
                }
            }
        }

        Log.d(TAG, "doInBackground: finalLatLngList size = " + finalLatLngList.size());

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i =0; i<finalLatLngList.size()/2; i++) {

                    String googleNearbyPlaceParsed = "";
                    LatLng latlng = finalLatLngList.get(i);

                    String url = getURL(latlng.latitude, latlng.longitude, "petrolPumps", null);

                    try {
                        googleNearbyPlaceParsed = downloadURL.readURL(url);
                    } catch (IOException e) {
                        Log.d(TAG, "doInBackground: " + e);
                    }

                    Log.d(TAG, "doInBackground: googleNearbyPlaceParsed : " + googleNearbyPlaceParsed);

                    nearbyPlacesListMaster = new DataParser().parse(googleNearbyPlaceParsed);

                    Log.d(TAG, "doInBackground: nearbyPlacesListMaster = " + nearbyPlacesListMaster);

                    Log.d(TAG, "doInBackground: nearbyPlaceListMaster.size() = " + nearbyPlacesListMaster.size());

                    for (int j=0; j<nearbyPlacesListMaster.size(); j++) {
                        HashMap<String, String> googlePlace = nearbyPlacesListMaster.get(j);

                        String placeName = googlePlace.get("place_name");
                        String vicinity = googlePlace.get("vicinity");

                        double lat = 0.00;
                        double lng = 0.00;

                        if (!googlePlace.get("lat").isEmpty() && !googlePlace.get("lng").isEmpty() && googlePlace.get("lat") != null && googlePlace.get("lng") != null) {
                            lat = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lat")))));
                            lng = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lng")))));
                        }

                        LatLng latLng = new LatLng(lat, lng);

                        float[] result = new float[1];

                        Location.distanceBetween(currentLocation.latitude, currentLocation.longitude, lat, lng, result);

                        modelsList.add(new Model(R.id.petrol_pump_image, placeName, "Petrol Pump", vicinity, latLng, result[0],googlePlace.get("rating"), googlePlace.get("photo_reference")));
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t1.start();

        for (int i =finalLatLngList.size()/2; i<finalLatLngList.size(); i++) {

                String googleNearbyPlaceParsed = "";
                LatLng latlng = finalLatLngList.get(i);

                String url = getURL(latlng.latitude, latlng.longitude, "petrolPumps", null);

                try {
                    googleNearbyPlaceParsed = downloadURL.readURL(url);
                } catch (IOException e) {
                    Log.d(TAG, "doInBackground: " + e);
                }

                Log.d(TAG, "doInBackground: googleNearbyPlaceParsed : " + googleNearbyPlaceParsed);

                nearbyPlacesListMaster = new DataParser().parse(googleNearbyPlaceParsed);

                Log.d(TAG, "doInBackground: nearbyPlacesListMaster = " + nearbyPlacesListMaster);

                Log.d(TAG, "doInBackground: nearbyPlaceListMaster.size() = " + nearbyPlacesListMaster.size());

                for (int j=0; j<nearbyPlacesListMaster.size(); j++) {
                    HashMap<String, String> googlePlace = nearbyPlacesListMaster.get(j);

                    String placeName = googlePlace.get("place_name");
                    String vicinity = googlePlace.get("vicinity");

                    double lat = 0.00;
                    double lng = 0.00;

                    if (!googlePlace.get("lat").isEmpty() && !googlePlace.get("lng").isEmpty() && googlePlace.get("lat") != null && googlePlace.get("lng") != null) {
                        lat = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lat")))));
                        lng = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lng")))));
                    }

                    LatLng latLng = new LatLng(lat, lng);

                    float[] result = new float[1];

                    Location.distanceBetween(currentLocation.latitude, currentLocation.longitude, lat, lng, result);

                    modelsList.add(new Model(R.id.petrol_pump_image, placeName, "Petrol Pump", vicinity, latLng, result[0],googlePlace.get("rating"), googlePlace.get("photo_reference")));
                }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return modelsList;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(final List<Model> modelsListTemp) {
        super.onPostExecute(modelsListTemp);

        ProgressBar progressBar = parent.findViewById(R.id.progressBar);
        
        progressBar.setVisibility(View.VISIBLE);
        TranslateAnimation translateAnimation = new TranslateAnimation(0,0,320, -120);
        translateAnimation.setDuration(300);
        translateAnimation.setFillAfter(true);
        progressBar.startAnimation(translateAnimation);

        Log.d(TAG, "onPostExecute: Progress Bar Removed");

        MarkerOptions markerOptions = new MarkerOptions();

        int count = 0;

        /*ClusterManager<ClusterManagerItem> mClusterManager;

        mClusterManager = new ClusterManager<ClusterManagerItem>(parent.getContext(), mMap);

        mMap.setOnCameraIdleListener(mClusterManager);
        mMap.setOnMarkerClickListener(mClusterManager);*/

        /*for (int i=0; i<modelsListTemp.size(); i++) {
            if (i+1 < modelsListTemp.size()) {
                if (modelsListTemp.get(i).getLatLng() == modelsListTemp.get(i + 1).getLatLng()) {
                    modelsListTemp.remove(i + 1);
                }
            }
        }*/

        for (Model model : modelsListTemp) {
            markerOptions.position(model.getLatLng());
            markerOptions.icon(bitmapDescriptorFromVector(parent.getContext(), R.drawable.ic_fuel_pump_marker));
            markerOptions.title(model.getPetrol_pump_name());
            Marker marker = mMap.addMarker(markerOptions);
            marker.setTag(0);
            marker.setVisible(true);
            markers.add(count, marker);
            count += 1;
        }

        for (int i=0; i<modelsListTemp.size(); i++) {
            if (markers.get(i).getPosition() == modelsListTemp.get(i).getLatLng()) {
                markerOptions.position(modelsListTemp.get(i).getLatLng());
                markerOptions.icon(bitmapDescriptorFromVector(parent.getContext(), R.drawable.ic_fuel_pump_marker));
                Marker marker = mMap.addMarker(markerOptions);
                marker.setTag(0);
                marker.setVisible(true);
                markers.add(i, marker);
            } else {
                markers.remove(i);
                modelsListTemp.remove(i);
            }
        }

        Log.d(TAG, "onPostExecute: models size = " + modelsList.size());
        Log.d(TAG, "onPostExecute: markers size = " + markers.size());

        setBackButtonListener();

        constraintLayout = parent.findViewById(R.id.main_constraint);

        final CardView placeInfoCardView = parent.findViewById(R.id.place_info_card_view);

        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) placeInfoCardView.getLayoutParams();
        layoutParams.verticalBias = (float) 1.13;
        placeInfoCardView.setLayoutParams(layoutParams);
        placeInfoCardView.setCardElevation(0);

        final ViewPager2 fuelLocationPager = parent.findViewById(R.id.fuel_locations_pager);

        placeInfoCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        Button startJourneyButton = (Button) parent.findViewById(R.id.place_info_start_journey);
        layoutParams = (ConstraintLayout.LayoutParams) startJourneyButton.getLayoutParams();
        layoutParams.verticalBias = (float) 0.1;
        startJourneyButton.setLayoutParams(layoutParams);

        if (fuelLocationPager.getVisibility() == View.GONE) {
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.clone(constraintLayout);
            constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.fuel_locations_pager, ConstraintSet.TOP);
            constraintSet.connect(R.id.fuel_locations_pager, ConstraintSet.BOTTOM, R.id.place_info_card_view, ConstraintSet.TOP);
            constraintSet.applyTo(constraintLayout);

            fuelLocationPager.setVisibility(View.VISIBLE);
        }

        CoordinatorLayout coordinatorLayout = parent.findViewById(R.id.bottomSheetCoordinatorLayout);

        fuelPumpDetails = parent.findViewById(R.id.fuel_pump_details);

        modelsList = modelsListTemp;

        View bottomSheet = parent.findViewById(R.id.bottomSheetBehaviour);
        BottomSheetBehavior behavior = BottomSheetBehavior.from(bottomSheet);

        bottomSheetBehaviourCallback(modelsListTemp, markers);

        FuelLocationCardViewAdapter fuelLocationCardViewAdapter = new FuelLocationCardViewAdapter(
                modelsList,
                coordinatorLayout,
                parent.getContext(),
                behavior,
                fuelPumpDetails,
                fuelLocationPager,
                mMap,
                currentLocation,
                markers,
                parent);

        fuelLocationPager.setAdapter(fuelLocationCardViewAdapter);
        fuelLocationPager.setPageTransformer(new ZoomOutPageTransformer());
        fuelLocationPager.setCurrentItem(0);
        fuelLocationPager.setSaveEnabled(false);
        fuelLocationPager.setSaveFromParentEnabled(false);

        models = modelsListTemp;
        setUserPreferenceListener();
        fuelLocationPager.registerOnPageChangeCallback(onPageChangeCallback = new ViewPager2.OnPageChangeCallback() {
            int currentCardPostion;
            boolean isGoingToRight;
            Context context = parent.getContext();
            GoogleMap mMaps = mMap;

            @Override
            public void onPageSelected(int position) {
                currentCardPostion = position;

                marker = markers.get(position);
                marker.showInfoWindow();
                if (marker.getTag() == null) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(marker.getPosition());
                    marker = mMaps.addMarker(markerOptions);
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                    markers.remove(position);
                    markers.add(position, marker);
                }

                Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: modelsList size = " + models.size());

                Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: currentPosition = " + currentCardPostion);

                if (!models.isEmpty()) {
                    setPetrolPumpDetails(position);
                } else {
                    Toast.makeText(context, "Models List Empty!", Toast.LENGTH_SHORT).show();
                }

                Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: Markers size = " + markers.size());

                if (position == 0) {

                    Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: position == 0");

                    Log.d(TAG, "onPageSelected: GetNearbyPlacesData Class: Markers size = " + markers.size());
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                }
                mMaps.animateCamera(CameraUpdateFactory.newLatLngZoom(markers.get(position).getPosition(), 12), 400, null);

                Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: animated Camera at: lat = " + models.get(position).getLatLng().latitude + " | lng = " + models.get(position).getLatLng().longitude);

                if (isGoingToRight) {

                    Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: User Scrolling to the right: isGoingToRight = " + isGoingToRight);

                    if (position > 0) {
                        int previousPosition = position - 1;

                        Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: previousPosition = " + previousPosition);

                        if (markers.get(position) != null) {

                            Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + position + "] != null");

                            marker = markers.get(position);

                            marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                        }
                        if (markers.get(position) != null) {
                            if (markers.get(previousPosition) != null) {

                                Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + previousPosition + "] != null");

                                marker = markers.get(previousPosition);

                                if (marker.getTag() == null) {
                                    MarkerOptions markerOptions = new MarkerOptions();
                                    markerOptions.position(marker.getPosition());
                                    marker = mMaps.addMarker(markerOptions);
                                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                                    markers.remove(previousPosition);
                                    markers.add(previousPosition, marker);
                                }

                                marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                            }
                        }
                    }
                } else {

                    Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: User going Left");

                    if (position >= 0) {
                        if (markers.get(position) != null) {

                            Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + position + "] != null");

                            marker = markers.get(position);

                            marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));
                        }
                        if (position < markers.size()) {
                            int nextPosition = position + 1;
                            if (markers.get(nextPosition) != null) {

                                Log.d(TAG, "onPageScrolled: GetNearbyPlacesData Class: markers[" + nextPosition + "] != null");

                                marker = markers.get(nextPosition);

                                marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                            }
                        }
                    }
                }

            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                isGoingToRight = position == currentCardPostion;

                /*marker = markers.get(position);
                if (marker.getTag() == null) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(marker.getPosition());
                    marker = mMaps.addMarker(markerOptions);
                    marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));
                    markers.add(position,marker);
                }*/
            }
        });

        /*for (LatLng latlng : finalLatLngList) {
            markerOptions.position(latlng);
            markerOptions.icon(bitmapDescriptorFromVector(parent.getContext(), R.drawable.ic_fuel_pump_spotlight_marker));
            Marker marker = mMap.addMarker(markerOptions);
            marker.setTag(0);
        }*/
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    private String getURL(double latitude, double longitude, String nearbyPlace, String token) {

        Log.d(TAG, "getURL: Maps Activity Called");

        StringBuilder googlePlaceURL = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        if (token == null) {
            googlePlaceURL.append("location=" + latitude + "," + longitude);
            googlePlaceURL.append("&radius=" + PROXIMITY_RADIUS);
            googlePlaceURL.append("&type=" + nearbyPlace);
            googlePlaceURL.append("&hasNextPage=true");
            googlePlaceURL.append("&nextpage()=true");
            googlePlaceURL.append("&keyword=" + "petrolpump");
            googlePlaceURL.append("&sensor=true");
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        } else{
            googlePlaceURL.append("pagetoken="+token);
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        }

        Log.d(TAG, "getURL: Maps Acitivity: googlePlaceURL = " + googlePlaceURL.toString());

        return googlePlaceURL.toString();
    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: Called");

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: vectorResId = " + vectorResId);

        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        assert vectorDrawable != null;
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void setPetrolPumpDetails(int positionTemp) {
        DecimalFormat df = new DecimalFormat("0.00");
        TextView fuelPumpDetailsPetrolPumpName = fuelPumpDetails.findViewById(R.id.fuel_pump_details_petrol_pump_name);
        ImageView fuelPumpDetailsPetrolPumpImage = fuelPumpDetails.findViewById(R.id.fuel_pump_details_petrol_pump_image);
        TextView fuelPumpDetailsAddress = fuelPumpDetails.findViewById(R.id.fuel_pump_details_address);
        RatingBar fuelPumpDetailsRatingBar = fuelPumpDetails.findViewById(R.id.fuel_pump_details_rating_bar);
        TextView fuelPumpDetailsDistance = fuelPumpDetails.findViewById(R.id.fuel_pump_details_distance);

        Log.d(TAG, "setPetrolPumpDetails: GetNearbyPlaces Class: modelsList size = " + models.size());

        if (!models.isEmpty() && positionTemp<models.size()) {
            fuelPumpDetailsPetrolPumpName.setText(models.get(positionTemp).getPetrol_pump_name());
            fuelPumpDetailsDistance.setText("Distance : " + df.format(models.get(positionTemp).getDistance() / 1000) + " KM");
            fuelPumpDetailsRatingBar.setRating(Float.parseFloat(models.get(positionTemp).getRating()));
            fuelPumpDetailsAddress.setText(models.get(positionTemp).getAddress());
            Picasso.get().load(getPhotoURL(models, positionTemp)).error(R.drawable.ic_fuel_pump_spotlight_marker).placeholder(R.drawable.ic_background_red_can).into(fuelPumpDetailsPetrolPumpImage);
        } else {
            Toast.makeText(parent.getContext(), "Models is Empty!", Toast.LENGTH_SHORT).show();
        }
    }

    private String getPhotoURL(List<Model> models, int position) {
        String photo_reference;

        StringBuilder stringBuilder = new StringBuilder("https://maps.googleapis.com/maps/api/place/photo?");
        stringBuilder.append("maxwidth=400");

        if (models.get(position).getPhoto_reference() != null) {
            photo_reference = models.get(position).getPhoto_reference();
            photo_reference = photo_reference.substring(1, photo_reference.length() - 1);
            Log.d(TAG, "getPhotoURL: GetNearbyPlacesData Class: photo_reference = " + photo_reference);
            stringBuilder.append("&reference=" + photo_reference);
        }

        stringBuilder.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        String url = stringBuilder.toString();
        Log.d(TAG, "getPhotoURL: GetNearbyPlacesData Class: Photo_URL = " + url);
        return url;
    }

    private void setBackButtonListener() {
        hamburgerMenuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = parent.getContext();

                if (fuelLocationPager.getVisibility() != View.VISIBLE) {
                    mMap.clear();
                }

                hamburgerMenuIcon.setImageResource(R.drawable.ic_baseline_menu_24);

                searchTextView.clearFocus();

                searchTextView.setText("");

                searchTextView.setFocusableInTouchMode(false);
                searchTextView.setFocusable(false);

                gpsLocateMe.setVisibility(View.VISIBLE);
                showNearByPetrolPumpsButton.setVisibility(View.VISIBLE);
                userPreferenceButton.setVisibility(View.GONE);

                if (autocompleteRecyclerConstraint.getVisibility() == View.VISIBLE) {
                    autocompleteRecyclerConstraint.setVisibility(View.GONE);
                    slideView(autocompleteRecyclerConstraint, convertDPtoPix(400),
                            convertDPtoPix(50),
                            250);
                }

                InputMethodManager imm =
                        (InputMethodManager) parent.getContext().getSystemService(Activity.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(parent.getWindowToken(), 0);
                }

                profile_image.setVisibility(View.VISIBLE);
                searchTextClearButton.setVisibility(View.GONE);

                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.latitude, currentLocation.longitude), 17));

                if (placeInfoCardView.getVisibility() == View.VISIBLE) {
                    TranslateAnimation translateAnimation = new TranslateAnimation(0, 0, 0, 600);
                    translateAnimation.setDuration(300);
                    translateAnimation.setFillAfter(true);
                    translateAnimation.setInterpolator(context, android.R.interpolator.linear);

                    placeInfoCardView.startAnimation(translateAnimation);

                    placeInfoCardView.setVisibility(View.GONE);
                }

                if (fuelLocationPager.getVisibility() == View.VISIBLE) {
                    fuelLocationPager.unregisterOnPageChangeCallback(onPageChangeCallback);

                    constraintLayout = parent.findViewById(R.id.main_constraint);
                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(constraintLayout);
                    constraintSet.connect(R.id.gps_locate_me_button, ConstraintSet.BOTTOM, R.id.main_constraint, ConstraintSet.BOTTOM);
                    constraintSet.connect(R.id.fuel_locations_pager, ConstraintSet.BOTTOM, R.id.main_constraint, ConstraintSet.BOTTOM);
                    constraintSet.applyTo(constraintLayout);


                    for(Marker marker : markers) {
                        marker.remove();
                    }

                    mMap.clear();
                    markers.clear();

                    models.clear();
                    modelsList.clear();

                    fuelLocationPager.getAdapter().notifyDataSetChanged();

                    CoordinatorLayout bottomSheetCoordinatorLayout = (CoordinatorLayout)
                            parent.findViewById(R.id.bottomSheetCoordinatorLayout);

                    if (bottomSheetCoordinatorLayout.getVisibility() == View.VISIBLE) {
                        bottomSheetCoordinatorLayout.setVisibility(View.GONE);
                    }

                    fuelLocationPager.setVisibility(View.GONE);
                }
                //autocompleteRecyclerConstraint.setVisibility(View.GONE);
            }

        });
    }

    public static void slideView(final View view,
                                 int currentHeight,
                                 int newHeight,
                                 int duration) {

        ValueAnimator slideAnimator = ValueAnimator
                .ofInt(currentHeight, newHeight)
                .setDuration(duration);

        slideAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                Integer value = (Integer) animation.getAnimatedValue();
                view.getLayoutParams().height = value.intValue();
                view.requestLayout();
            }
        });

        AnimatorSet animationSet = new AnimatorSet();
        animationSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animationSet.setDuration(duration);
        animationSet.play(slideAnimator);
        animationSet.start();
    }

    private int convertDPtoPix(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                parent.getContext().getResources().getDisplayMetrics());
    }

    private void bottomSheetBehaviourCallback(List<Model> models, List<Marker> markers) {

        final CoordinatorLayout coordinatorLayout;
        RecyclerView recyclerView;
        Context context = parent.getContext();

        coordinatorLayout = parent.findViewById(R.id .bottomSheetCoordinatorLayout);
        recyclerView = parent.findViewById(R.id.petrol_pump_list_view);
        recyclerView.setHasFixedSize(false);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        View bottomSheet = parent.findViewById(R.id.bottomSheetBehaviour);
        behavior = BottomSheetBehavior.from(bottomSheet);
        recyclerView.setAdapter(new FuelLocationRecyclerViewAdapter(models, behavior, mMap,
                fuelLocationPager, markers, context, recyclerView, currentLocation, parent));

    }

    private void getPumpPreferences() {

        Log.d(TAG, "getPumpPreferences: Maps Activity: Called");

        Gson gson = new Gson();

        Context context = parent.getContext();

        SharedPreferences pumpPreference = context.getSharedPreferences("PUMP_PREFERENCES", Context.MODE_PRIVATE);
        String json = pumpPreference.getString(context.getResources().getString(R.string.selected_pump_pref), null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        selectedPumpPreferences = gson.fromJson(json, type);

        Log.d(TAG, "getPumpPreferences: Maps Activity: Selected Pump Preference is: selectedPumpPreference = " + selectedPumpPreferences);
    }

    private void setUserPreferenceListener() {
        userPreferenceButton = (ImageButton) parent.findViewById(R.id.user_preference_button);
        if (userPreferenceButton.getVisibility() == View.GONE) {
            userPreferenceButton.setVisibility(View.VISIBLE);
        }
        userPreferenceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isClicked) {
                    if (selectedPumpPreferences == null) {
                        Toast.makeText(parent.getContext(), "No User Preferred Petrol Pumps!", Toast.LENGTH_SHORT).show();
                    } else {

                        List<Model> modelsTemp = new ArrayList<>();
                        List<Marker> markerTemp = new ArrayList<>();

                        for (String petrolPump : selectedPumpPreferences) {
                            for (int i = 0; i < models.size(); i++) {
                                if (models.get(i).getPetrol_pump_name().contains(petrolPump)) {
                                    modelsTemp.add(models.get(i));
                                    markerTemp.add(markers.get(i));
                                } else {
                                    markers.get(i).setVisible(false);
                                }
                            }
                        }

                        if (modelsTemp.size() == 0) {
                            Toast.makeText(parent.getContext(), "No User Preferred Petrol Pumps found on Route!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(parent.getContext(), "Show User Preferred Petrol Pumps!", Toast.LENGTH_SHORT).show();
                            updateViewPager(modelsTemp, markerTemp);
                            userPreferenceButton.setImageResource(R.drawable.ic_round_account_circle_24);
                            isClicked = true;
                        }
                    }
                } else {
                    for(Marker marker : markers) {
                        marker.setVisible(true);
                    }
                    Toast.makeText(parent.getContext(), "Show All Petrol Pumps!", Toast.LENGTH_SHORT).show();
                    userPreferenceButton.setImageResource(R.drawable.ic_round_map_24);
                    isClicked=false;
                    updateViewPager(modelsList, markers);
                }
            }
        });
    }
    private void updateViewPager(final List<Model> models, List<Marker> markerTemp) {

        Log.d(TAG, "updateViewPager: GetNearbyPlacesData Class: Called");

        if (fuelLocationPager.getVisibility() == View.GONE) {
            fuelLocationPager.setVisibility(View.VISIBLE);
        }

        Log.d(TAG, "updateViewPager: GetNearbyPlacesData Class: Models Size : " + models.size());

        for (int i = 0; i < models.size(); i++) {
            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: models[" + i + "] = " + models.get(i));
            Log.d(TAG, "setViewPager: GetNearbyPlacesData Class: models[" + i + "]: " + "Place Name = " + models.get(i).getPetrol_pump_name() + " | lat = " + models.get(i).getLatLng().latitude + " | lng = " + models.get(i).getLatLng().longitude + " | distance = " + models.get(i).getDistance());
        }
        CoordinatorLayout coordinatorLayout = parent.findViewById(R.id.bottomSheetCoordinatorLayout);

        FuelLocationCardViewAdapter fuelLocationCardViewAdapter = new FuelLocationCardViewAdapter(models,
                coordinatorLayout,
                parent.getContext(),
                behavior,
                fuelPumpDetails,
                fuelLocationPager,
                mMap,
                currentLocation,
                markerTemp,
                parent);
        fuelLocationPager.setAdapter(fuelLocationCardViewAdapter);
        bottomSheetBehaviourCallback(models, markerTemp);
        fuelLocationCardViewAdapter.notifyDataSetChanged();
        for (int i = 0; i < markers.size(); i++) {
            marker = markers.get(i);
            marker.setIcon(bitmapDescriptorFromVector(parent.getContext(), R.drawable.ic_fuel_pump_marker));

            Log.d(TAG, "RadiusSearchButton onClick: GetNearbyPlacesData Class: marker: lat = " + marker.getPosition().latitude + " | lng = " + marker.getPosition().longitude);
        }
    }

}
