package com.tyche.fuelmaps;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.RemoteInput;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.StrictMode;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FetchPlaceResponse;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.maps.android.PolyUtil;
import com.tyche.fuelmaps.models.Model;
import com.tyche.fuelmaps.parser.DataParser;

import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static com.tyche.fuelmaps.MapsActivity.CHANNEL_ID;

public class FuelMapsBackgroundService extends Service {

    private static final String PROXIMITY_RADIUS = "500";
    String TAG = "FuelMapsBackgroundService";
    NotificationCompat.Builder notificationBuilder, notificationBuilderLowFuel;
    Notification notification, lowFuelNotification;
    public static final String KEY_TEXT_DESTINATION = "KEY_TEXT_DESTINATION";
    Location currentLocation = null;
    NotificationManager notificationManager, notificationManagerLowFuel;
    Intent mainServiceDestination, mainServiceFuel;
    RemoteInput remoteInputFuelLevel, remoteInputDestination;
    NotificationCompat.Action inputFuelLevel, inputDestination, cancelJourney;
    PendingIntent mapsActivityPend;
    List<String> destinationPlaceIDList = new ArrayList<>();
    String destinationPlaceID;
    PlacesClient placesClient;
    Place destination;
    String getDirectionsURL;
    List<LatLng> latLngList = new ArrayList<>();
    List<LatLng> polylineLatLngList = new ArrayList<>();
    String duration;
    String distance;
    PendingIntent mainServiceDestinationPend, mainServiceFuelPend, mapsActivityPend2;
    public static final String CHANNEL_ID_2 = "FuelMapsBackgroundServiceFuelLow";
    List<LatLng> finalLatLngList = new ArrayList<>();
    List<HashMap<String, String>> nearbyPlacesListMaster = new ArrayList<>();
    ArrayList<Model> modelsList = new ArrayList<>();
    Intent mapsActivity, mapsActivity2;
    int index;
    String nearestPetrolPumpDistance, nearestPetrolPumpDuration;
    PolylineOptions options;
    Double fuelLevel, approxFuelReq;

    public FuelMapsBackgroundService() {
        super();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        IntentFilter filter = new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION);
        filter.addAction(Intent.ACTION_PROVIDER_CHANGED);
        registerReceiver(mGPSState, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        //Log.d(TAG, "onStartCommand: Action = " + intent.getAction());

        if (intent.getAction() == "DESTINATION") {
            CharSequence destinationChar = getMessageText(intent);
            if (destinationChar != null && currentLocation != null) {
                Log.d(TAG, "onReceive: destination = " + destinationChar);
                getPredictions(destinationChar.toString());
            }
        } else if (intent.getAction() == "FUEL") {
            CharSequence fuelLevel = getMessageText(intent);
            Log.d(TAG, "onStartCommand: Fuel Level = " + fuelLevel);
            checkFuelLevel(fuelLevel.toString());
        }

        if (notification == null) {
            notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID);

            mapsActivity = new Intent(this, MapsActivity.class);

            mapsActivityPend = PendingIntent.getActivity(this,
                    0,
                    mapsActivity,
                    0
            );

            mainServiceDestination = new Intent(this, FuelMapsBackgroundService.class);
            mainServiceDestination.setAction("DESTINATION");

            mainServiceFuel = new Intent(this, FuelMapsBackgroundService.class);
            mainServiceFuel.setAction("FUEL");

            mainServiceDestinationPend = PendingIntent.getService(this,
                    1,
                    mainServiceDestination,
                    PendingIntent.FLAG_UPDATE_CURRENT);

            mainServiceFuelPend = PendingIntent.getService(this,
                    1,
                    mainServiceFuel,
                    PendingIntent.FLAG_UPDATE_CURRENT);

            remoteInputDestination = new RemoteInput.Builder(KEY_TEXT_DESTINATION)
                    .setLabel("Enter Destination")
                    .build();

            remoteInputFuelLevel = new RemoteInput.Builder(KEY_TEXT_DESTINATION)
                    .setLabel("Enter Fuel Level")
                    .build();

            inputDestination = new NotificationCompat.Action.Builder(R.mipmap.ic_launcher_round,
                    "Enter Destination", mainServiceDestinationPend)
                    .addRemoteInput(remoteInputDestination)
                    .build();

            inputFuelLevel = new NotificationCompat.Action.Builder(R.mipmap.ic_launcher_round,
                    "Enter Fuel Level", mainServiceFuelPend)
                    .addRemoteInput(remoteInputFuelLevel)
                    .build();

            notification = notificationBuilder
                    .setContentTitle("Enter Destination to Start Journey")
                    .setContentText("Connect to Bluetooth")
                    .setSmallIcon(R.drawable.fuel_pump_marker)
                    .setContentIntent(mapsActivityPend)
                    .addAction(inputDestination)
                    .addAction(inputFuelLevel)
                    .build();
        }

        startForeground(1, notification);

        if (locationServicesEnabled(this)) {
            createLocationRequest();
        } else {
            updateNotification("gps");
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mGPSState);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
    }

    @Override
    protected void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        super.dump(fd, writer, args);
    }

    private void stop() {
        stopSelf();
    }

    private CharSequence getMessageText(Intent intent) {
        Bundle remoteInput = RemoteInput.getResultsFromIntent(intent);
        if (remoteInput != null) {
            return remoteInput.getCharSequence(KEY_TEXT_DESTINATION);
        }
        return null;
    }

    private void createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }

        LocationCallback locationCallback;

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    currentLocation = location;
                    Log.d(TAG, "onLocationResult: currentLocation = " + currentLocation.getLatitude() + " | " + currentLocation.getLongitude());
                }
            }
        };

        fusedLocationClient.requestLocationUpdates(locationRequest,
                locationCallback,
                Looper.getMainLooper());
    }

    public boolean locationServicesEnabled(Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean net_enabled = false;

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
            Log.e(TAG,"Exception gps_enabled");
        }

        try {
            net_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ex) {
            Log.e(TAG,"Exception network_enabled");
        }
        return gps_enabled && net_enabled;
    }

    private void createNotificationChannel() {
        NotificationChannel fuelMapsBackgroundServiceNotificationChannel = new NotificationChannel(
                CHANNEL_ID,
                "Fuel Maps Background Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(fuelMapsBackgroundServiceNotificationChannel);

        NotificationChannel fuelMapsBackgroundServiceNotificationChannelLowFuel = new NotificationChannel(
                CHANNEL_ID_2,
                "Fuel Maps Background Service Channel Low Fuel",
                NotificationManager.IMPORTANCE_HIGH
        );

        notificationManagerLowFuel = getSystemService(NotificationManager.class);
        notificationManagerLowFuel.createNotificationChannel(fuelMapsBackgroundServiceNotificationChannelLowFuel);

        Log.d(TAG, "createNotificationChannel: Notification Channel Created!");

    }

    @SuppressLint("RestrictedApi")
    private void updateNotification(String updateCommand) {
        if (updateCommand.equals("gps")) {
            notification = notificationBuilder
                    .setContentTitle("Please Turn On GPS")
                    .build();

            notificationManager.notify(1, notification);
        } else if (updateCommand.equals("place")) {

            cancelJourney = new NotificationCompat.Action.Builder(R.mipmap.ic_launcher_round,
                    "Cancel Journey", mainServiceDestinationPend)
                    .build();

            notificationBuilder.mActions.clear();

            notification = notificationBuilder
                    .setContentTitle("Destination Entered : " + destination.getName())
                    .addAction(cancelJourney)
                    .addAction(inputFuelLevel)
                    .build();

            notificationManager.notify(1, notification);
        } else if (updateCommand.equals("duration & distance")) {
            notification = notificationBuilder
                    .setContentText(duration + " Left to Arrive And " + distance + " To go!")
                    .build();

            notificationManager.notify(1, notification);
        } else if (updateCommand.equals("default")) {
            notification = notificationBuilder
                    .setContentTitle("Enter Destination to Start Journey")
                    .build();

            notificationManager.notify(1, notification);
        } else if (updateCommand.equals("getPetrolPumps")) {
            notification = notificationBuilder
                    .setContentTitle("Getting On Route Petrol Pumps")
                    .build();

            notificationManager.notify(1, notification);
        } else if (updateCommand.equals("lowFuel")) {
            DecimalFormat df = new DecimalFormat("0.00");

            notification = notificationBuilder
                    .setContentTitle("Low Fuel")
                    .setStyle(new NotificationCompat.BigTextStyle()
                    .bigText("Your Fuel level is : " + df.format(fuelLevel) + "L and " + df.format(approxFuelReq) + "L is required to reach your destination"))
                    .build();

            notificationManager.notify(1, notification);
        }
    }

    private void getPredictions(String s) {

        AutocompleteSessionToken token = AutocompleteSessionToken.newInstance();

        RectangularBounds bounds = RectangularBounds.newInstance(
                new LatLng(23.63936, 68.14712),
                new LatLng(28.20453, 97.34466)
        );

        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setLocationBias(bounds)
                .setTypeFilter(TypeFilter.CITIES)
                .setOrigin(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()))
                .setSessionToken(token)
                .setQuery(s)
                .build();

        Places.initialize(getApplicationContext(), "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        placesClient = Places.createClient(getApplicationContext());

        placesClient.findAutocompletePredictions(request).addOnSuccessListener(new OnSuccessListener<FindAutocompletePredictionsResponse>() {
            @Override
            public void onSuccess(FindAutocompletePredictionsResponse findAutocompletePredictionsResponse) {

                for (AutocompletePrediction prediction : findAutocompletePredictionsResponse.getAutocompletePredictions()) {
                    destinationPlaceIDList.add(prediction.getPlaceId());
                    Log.d(TAG, "onSuccess: Place = " + prediction.getPrimaryText(null).toString()  + " Place ID = " + prediction.getPlaceId());
                }

                destinationPlaceID = destinationPlaceIDList.get(0);
                Log.d(TAG, "onSuccess: Place ID = " + destinationPlaceID);
                getPlace(destinationPlaceID);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d(TAG, "onFailure: Autocomplete Prediction = " + e);
            }
        });
    }

    private void getPlace(String s) {

        final List<Place.Field> placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);

        final FetchPlaceRequest request = FetchPlaceRequest.newInstance(s, placeFields);

        placesClient.fetchPlace(request).addOnSuccessListener(new OnSuccessListener<FetchPlaceResponse>() {
            @Override
            public void onSuccess(FetchPlaceResponse fetchPlaceResponse) {
                destination = fetchPlaceResponse.getPlace();
                if (destination != null) {
                    Log.d(TAG, "onSuccess: getPlace: Destination != null");
                    Log.d(TAG, "getPlace: destination = " + destination.getName());
                    updateNotification("place");
                    getPolyline(destination);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d(TAG, "onFailure: getPlace = " + e);
            }
        });
    }

    private void getPolyline(Place place) {

        try {
            String url = getDirectionsURL(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), place.getLatLng());
            Log.d(TAG, "doInBackground: url generated: url = " + url);
            getDirectionsURL = readURL(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] directionsList = null;
        DataParser parser = new DataParser();
        List<Object> polyLines = new ArrayList<>();

        polyLines = parser.parseDirections(getDirectionsURL);

        directionsList = (String[]) polyLines.get(0);

        distance = (String) polyLines.get(1);

        duration = (String) polyLines.get(2);

        for (String s : directionsList) {
            latLngList = PolyUtil.decode(s);
            polylineLatLngList.addAll(latLngList);
        }

        updateNotification("duration & distance");

        if (polylineLatLngList != null) {
            getOnRoutePetrolPumps();
        }
    }

    private String getDirectionsURL(LatLng currentLocation, LatLng destination) {
        StringBuilder directionURL = new StringBuilder("https://maps.googleapis.com/maps/api/directions/json?");
        directionURL.append("origin=" + currentLocation.latitude + "," + currentLocation.longitude);
        directionURL.append("&destination=" + destination.latitude + "," + destination.longitude);
        directionURL.append("&alternatives=true");
        directionURL.append("&units=metric");
        directionURL.append("&departure_time=now");
        directionURL.append("&traffic_model=best_guess");
        directionURL.append("&key=AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");

        String url = directionURL.toString();

        Log.d(TAG, "getDirectionsURL: url = " + url);
        return url;
    }

    public String readURL(String myURL) throws IOException {
        String data = "";
        InputStream inputStream = null;
        String TAG = "Fuel Maps";
        HttpURLConnection httpURLConnection = null;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
            java.net.URL url = new URL(myURL);
            httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();

            inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuffer stringBuffer = new StringBuffer();

            String line = "";
            while((line = bufferedReader.readLine()) != null) {
                stringBuffer.append(line);
            }

            data = stringBuffer.toString();
            Log.d(TAG, "readURL: data = " + data);
            bufferedReader.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
        }

        return data;
    }

    private void checkFuelLevel(String s) {
        fuelLevel = Double.parseDouble(s);

        String distanceTemp = distance;

        distanceTemp = distance.replace("km", "");

        approxFuelReq = Double.parseDouble(distanceTemp)/50.0;

        Log.d(TAG, "checkFuelLevel: Approximate Fuel Level Required = " + approxFuelReq);

        if (fuelLevel <= approxFuelReq) {

            Bundle bundle = new Bundle();
            bundle.putParcelable("polylineOptions", options);
            bundle.putParcelable("destinationLatLng", modelsList.get(index).getLatLng());
            bundle.putString("placeName", modelsList.get(index).getPetrol_pump_name());
            bundle.putString("placeAddress", modelsList.get(index).getAddress());
            bundle.putString("placeRating", modelsList.get(index).getRating());
            bundle.putString("duration", nearestPetrolPumpDuration);
            bundle.putString("distance", nearestPetrolPumpDistance);

            mapsActivity2 = new Intent(this, MapsActivity.class);
            mapsActivity2.setAction("SHOW_POLYLINE");
            mapsActivity2.putExtras(bundle);
            mapsActivity2.putParcelableArrayListExtra("model", modelsList);
            
            if (bundle == null) {
                Log.d(TAG, "checkFuelLevel: Bundle == null");
            }

            mapsActivityPend2 = PendingIntent.getActivity(this,
                    0,
                    mapsActivity2,
                    PendingIntent.FLAG_UPDATE_CURRENT
            );

            final Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

            notificationBuilderLowFuel = new NotificationCompat.Builder(this, CHANNEL_ID_2);
            MediaSessionCompat mMediaSessionCompat = new MediaSessionCompat(getApplication(), "Low Fuel Level", null, null);
            lowFuelNotification = notificationBuilderLowFuel
                    .setSmallIcon(R.drawable.ic_round_error_24)
                    .setContentTitle("Low Fuel! Refill You Vehicle!")
                    .setContentText("Click to get Route to nearest Petrol Pump")
                    .setContentIntent(mapsActivityPend2)
                    .setColor(Color.RED)
                    .setVibrate(null)
                    .setStyle(new androidx.media.app.NotificationCompat.MediaStyle().setMediaSession(mMediaSessionCompat.getSessionToken()))
                    .build();

            updateNotification("lowFuel");

            CountDownTimer countDownTimer = new CountDownTimer(4000, 1000) {
                long[] vibrationPattern = {500, 500, 500, 500};
                @Override
                public void onTick(long millisUntilFinished) {
                    vibrator.vibrate(VibrationEffect.createWaveform(vibrationPattern, 0));
                }

                @Override
                public void onFinish() {
                    vibrator.cancel();
                }
            }.start();

            notificationManagerLowFuel.notify(2, lowFuelNotification);
        }
    }

    private BroadcastReceiver mGPSState = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (LocationManager.PROVIDERS_CHANGED_ACTION.equals(intent.getAction())) {
                LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
                if (!isGPSEnabled) {
                    updateNotification("gps");
                } else {
                    if (currentLocation == null) {
                        createLocationRequest();
                    }
                    updateNotification("default");
                }
            }
        }
    };

    private void getOnRoutePetrolPumps() {

        updateNotification("getPetrolPumps");

        for (int i = 0; i<polylineLatLngList.size(); i++) {
            for (int k = i + 1; k<polylineLatLngList.size(); k++) {
                float[] result = new float[1];
                Location.distanceBetween(polylineLatLngList.get(i).latitude, polylineLatLngList.get(i).longitude, polylineLatLngList.get(k).latitude, polylineLatLngList.get(k).longitude, result);

                if (result[0] >= 1000) {
                    i = k;
                    finalLatLngList.add(polylineLatLngList.get(k));
                    break;
                }
            }
        }

        Log.d(TAG, "getOnRoutePetrolPumps: finalLatLngList.size() = " + finalLatLngList.size());

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i =0; i<finalLatLngList.size()/2; i++) {

                    String googleNearbyPlaceParsed = "";
                    LatLng latlng = finalLatLngList.get(i);

                    String url = getURL(latlng.latitude, latlng.longitude, "petrolPumps", null);

                    try {
                        googleNearbyPlaceParsed = readURL(url);
                    } catch (IOException e) {
                        Log.d(TAG, "doInBackground: " + e);
                    }

                    Log.d(TAG, "getOnRoutePetrolPumps : googleNearbyPlaceParsed : " + googleNearbyPlaceParsed);

                    nearbyPlacesListMaster = new DataParser().parse(googleNearbyPlaceParsed);

                    Log.d(TAG, "getOnRoutePetrolPumps: nearbyPlacesListMaster = " + nearbyPlacesListMaster);

                    Log.d(TAG, "getOnRoutePetrolPumps: nearbyPlaceListMaster.size() = " + nearbyPlacesListMaster.size());

                    for (int j=0; j<nearbyPlacesListMaster.size(); j++) {
                        HashMap<String, String> googlePlace = nearbyPlacesListMaster.get(j);

                        String placeName = googlePlace.get("place_name");
                        String vicinity = googlePlace.get("vicinity");

                        double lat = 0.00;
                        double lng = 0.00;

                        if (!googlePlace.get("lat").isEmpty() && !googlePlace.get("lng").isEmpty() && googlePlace.get("lat") != null && googlePlace.get("lng") != null) {
                            lat = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lat")))));
                            lng = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lng")))));
                        }

                        LatLng latLng = new LatLng(lat, lng);

                        float[] result = new float[1];

                        Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(), lat, lng, result);

                        modelsList.add(new Model(R.id.petrol_pump_image, placeName, "Petrol Pump", vicinity, latLng, result[0],googlePlace.get("rating"), googlePlace.get("photo_reference")));
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t1.start();

        for (int i =finalLatLngList.size()/2; i<finalLatLngList.size(); i++) {

            String googleNearbyPlaceParsed = "";
            LatLng latlng = finalLatLngList.get(i);

            String url = getURL(latlng.latitude, latlng.longitude, "petrolPumps", null);

            try {
                googleNearbyPlaceParsed = readURL(url);
            } catch (IOException e) {
                Log.d(TAG, "getOnRoutePetrolPumps: " + e);
            }

            Log.d(TAG, "getOnRoutePetrolPumps: googleNearbyPlaceParsed : " + googleNearbyPlaceParsed);

            nearbyPlacesListMaster = new DataParser().parse(googleNearbyPlaceParsed);

            Log.d(TAG, "getOnRoutePetrolPumps: nearbyPlacesListMaster = " + nearbyPlacesListMaster);

            Log.d(TAG, "getOnRoutePetrolPumps: nearbyPlaceListMaster.size() = " + nearbyPlacesListMaster.size());

            for (int j=0; j<nearbyPlacesListMaster.size(); j++) {
                HashMap<String, String> googlePlace = nearbyPlacesListMaster.get(j);

                String placeName = googlePlace.get("place_name");
                String vicinity = googlePlace.get("vicinity");

                double lat = 0.00;
                double lng = 0.00;

                if (!googlePlace.get("lat").isEmpty() && !googlePlace.get("lng").isEmpty() && googlePlace.get("lat") != null && googlePlace.get("lng") != null) {
                    lat = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lat")))));
                    lng = Double.parseDouble(((Objects.requireNonNull(googlePlace.get("lng")))));
                }

                LatLng latLng = new LatLng(lat, lng);

                float[] result = new float[1];

                Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(), lat, lng, result);

                modelsList.add(new Model(R.id.petrol_pump_image, placeName, "Petrol Pump", vicinity, latLng, result[0],googlePlace.get("rating"), googlePlace.get("photo_reference")));
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (modelsList != null) {
            getNearestPetrolPump();
        }
    }

    private String getURL(double latitude, double longitude, String nearbyPlace, String token) {

        Log.d(TAG, "getURL: Maps Activity Called");

        StringBuilder googlePlaceURL = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        if (token == null) {
            googlePlaceURL.append("location=" + latitude + "," + longitude);
            googlePlaceURL.append("&radius=" + PROXIMITY_RADIUS);
            googlePlaceURL.append("&type=" + nearbyPlace);
            googlePlaceURL.append("&hasNextPage=true");
            googlePlaceURL.append("&nextpage()=true");
            googlePlaceURL.append("&keyword=" + "petrolpump");
            googlePlaceURL.append("&sensor=true");
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        } else{
            googlePlaceURL.append("pagetoken="+token);
            googlePlaceURL.append("&key=" + "AIzaSyALoJx2oCY_3ZhE-QKvLgdG-IZ4l2tV5k4");
        }

        Log.d(TAG, "getURL: Maps Acitivity: googlePlaceURL = " + googlePlaceURL.toString());

        return googlePlaceURL.toString();
    }

    private void getNearestPetrolPump() {
        List<Float> fuelPumpDistance = new ArrayList<>();
        index = 0;
        float[] result = new float[1];

        for (Model model : modelsList) {
            Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(), model.getLatLng().latitude, model.getLatLng().longitude, result);
            fuelPumpDistance.add(result[0]);
        }

        List<Float> fuelPumpDistanceBak = new ArrayList<>();
        fuelPumpDistanceBak = fuelPumpDistance;
        Float temp;

        for (int i=0; i<fuelPumpDistance.size(); i++) {
            for (int j=i+1; j<fuelPumpDistance.size(); j++) {
                if (fuelPumpDistance.get(i) > fuelPumpDistance.get(j)) {
                    temp = fuelPumpDistance.get(i);
                    fuelPumpDistance.set(i, fuelPumpDistance.get(j));
                    fuelPumpDistance.set(j, temp);
                }
            }
        }

        index = fuelPumpDistanceBak.indexOf(fuelPumpDistance.get(0));

        LatLng nearestPetrolPumpLatLng = modelsList.get(index).getLatLng();

        getNearestPetrolPumpsPolyline(nearestPetrolPumpLatLng, index);

        Log.d(TAG, "getNearestPetrolPumps : nearestPetrolPumpLatLng = " + nearestPetrolPumpLatLng.latitude + " | " + nearestPetrolPumpLatLng.longitude);
    }

    private void getNearestPetrolPumpsPolyline(LatLng nearestPetrolPumpLatLng, int k) {
        try {
            String url = getDirectionsURL(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), nearestPetrolPumpLatLng);
            Log.d(TAG, "getNearestPetrolPumpsPolyline : url generated: url = " + url);
            getDirectionsURL = readURL(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] directionsList = null;
        DataParser parser = new DataParser();
        List<Object> polyLines = new ArrayList<>();

        polyLines = parser.parseDirections(getDirectionsURL);

        directionsList = (String[]) polyLines.get(0);

        nearestPetrolPumpDistance = (String) polyLines.get(1);

        nearestPetrolPumpDuration = (String) polyLines.get(2);

        options = new PolylineOptions();
        options.color(Color.argb(255, 110, 73, 161));
        options.width(15);
        options.jointType(2);

        for (int i = 0; i < directionsList.length; i++) {
            options.addAll(PolyUtil.decode(directionsList[i]));
        }

        updateNotification("place");
    }

}
