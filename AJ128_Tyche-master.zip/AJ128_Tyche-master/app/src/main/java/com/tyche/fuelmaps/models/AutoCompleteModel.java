package com.tyche.fuelmaps.models;

public class AutoCompleteModel {

    private String primaryText;
    private String secondaryText;
    private int distance;
    private String placeID;

    public AutoCompleteModel(String primaryText, String secondaryText, int i, String placeID) {
        this.primaryText = primaryText;
        this.secondaryText = secondaryText;
        this.distance = i;
        this.placeID = placeID;
    }

    public String getPrimaryText() {
        return primaryText;
    }

    public void setPrimaryText(String primaryText) {
        this.primaryText = primaryText;
    }

    public String getSecondaryText() {
        return secondaryText;
    }

    public void setSecondaryText(String secondaryText) {
        this.secondaryText = secondaryText;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public String getPlaceID() {
        return placeID;
    }

    public void setPlaceID(String placeID) {
        this.placeID = placeID;
    }

}
