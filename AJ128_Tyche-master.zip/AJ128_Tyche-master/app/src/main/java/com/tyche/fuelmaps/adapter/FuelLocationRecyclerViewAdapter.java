package com.tyche.fuelmaps.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.tyche.fuelmaps.GetDirectionData;
import com.tyche.fuelmaps.models.Model;
import com.tyche.fuelmaps.R;

import java.text.DecimalFormat;
import java.util.List;

public class FuelLocationRecyclerViewAdapter extends RecyclerView.Adapter<FuelLocationRecyclerViewAdapter.FuelLocationRecyclerViewCardViewHolder> {

    List<Model> modelList;
    String TAG = "Fuel Maps";
    CardView recyclerViewCardView;
    BottomSheetBehavior behavior;
    GoogleMap mMap;
    int position2;
    ViewPager2 fuelLocationPager;
    List<Marker> markers;
    Context context;
    Boolean isLocationSelected = false;
    RecyclerView recyclerView;
    Marker marker;
    LatLng currentLocation;
    ViewGroup parent;

    public FuelLocationRecyclerViewAdapter(List<Model> models, BottomSheetBehavior behavior,
                                           GoogleMap map, ViewPager2 fuelLocationPager,
                                           List<Marker> markers, Context context,
                                           RecyclerView recyclerView, LatLng currentLocation,
                                           ViewGroup parent) {
        this.modelList = models;
        this.behavior = behavior;
        this.mMap = map;
        this.fuelLocationPager = fuelLocationPager;
        this.markers = markers;
        this.context = context;
        this.recyclerView = recyclerView;
        this.currentLocation = currentLocation;
        this.parent = parent;
    }

    @NonNull
    @Override
    public FuelLocationRecyclerViewCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_vew_card_view, parent, false);
        return new FuelLocationRecyclerViewCardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final FuelLocationRecyclerViewCardViewHolder holder, int position) {
        position2 = position;

        holder.setPetrolPumpData(modelList.get(position));
        holder.petrolPumpName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int position3 = fuelLocationPager.getCurrentItem();

                fuelLocationPager.setCurrentItem(holder.getAdapterPosition());


                marker = markers.get(position3);

                marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_marker));

                behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

                marker = markers.get(fuelLocationPager.getCurrentItem());

                marker.setIcon(bitmapDescriptorFromVector(context, R.drawable.ic_fuel_pump_spotlight_marker));

                if(modelList.get(fuelLocationPager.getCurrentItem()).getLatLng()!=null) {
                    position2 = fuelLocationPager.getCurrentItem();
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.getPosition(),
                            15), 400, null);
                    isLocationSelected = true;
                }
            }
        });
        behavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                    if (fuelLocationPager.getVisibility() == View.GONE) {
                        fuelLocationPager.setVisibility(View.VISIBLE);
                    }
                    recyclerView.setScrollY(0);

                    isLocationSelected = false;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                Log.d(TAG, "onSlide: GetNearbyPlacesData Class: slideOffset = " + slideOffset);
                CameraPosition cameraPosition = mMap.getCameraPosition();
                if (slideOffset < 0.0 && isLocationSelected && cameraPosition.zoom <= 15) {
                    float cameraZoom = (((slideOffset - -1) / (-1)) * (15 - 12) - 12) * -1;
                    Log.d(TAG, "onSlide: GetNearbyPlacesData Class: cameraZoom = " + cameraZoom);
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.getPosition(),
                            cameraZoom), 1, null);
                }
            }
        });
        holder.directions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int post = fuelLocationPager.getCurrentItem();
                int post1 = holder.getAdapterPosition();
                fuelLocationPager.setCurrentItem(post1);
                LatLng destination = modelList.get(post1).getLatLng();

                Object[] dataTransfer = new Object[5];
                dataTransfer[0] = currentLocation;
                dataTransfer[1] = destination;
                dataTransfer[2] = mMap;
                dataTransfer[3] = markers;
                dataTransfer[4] = parent;

                GetDirectionData getDirectionData = new GetDirectionData();
                getDirectionData.execute(dataTransfer);

                behavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });
    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    public class FuelLocationRecyclerViewCardViewHolder extends RecyclerView.ViewHolder {

        ImageView petrolPumpImage;
        TextView petrolPumpName, locationType, petrolPumpAddress, distance;
        ImageButton listViewButton, directions;
        float rating;
        RatingBar ratingBar;

        public FuelLocationRecyclerViewCardViewHolder(@NonNull View itemView) {
            super(itemView);

            petrolPumpImage = itemView.findViewById(R.id.petrol_pump_image);
            petrolPumpName = itemView.findViewById(R.id.petrol_pump_name);
            locationType = itemView.findViewById(R.id.location_type);
            petrolPumpAddress = itemView.findViewById(R.id.petrol_pump_address);
            distance = itemView.findViewById(R.id.fuel_locations_card_distance);
            ratingBar = itemView.findViewById(R.id.ratingBar);
            listViewButton = itemView.findViewById(R.id.list_view_button);
            directions = itemView.findViewById(R.id.directions);
        }

        @SuppressLint("SetTextI18n")
        void setPetrolPumpData(Model model) {
            DecimalFormat df = new DecimalFormat("0.00");
            petrolPumpImage.setImageResource(R.drawable.ic_background_red_can);
            petrolPumpName.setText(model.getPetrol_pump_name());
            locationType.setText(model.getLocation_type());
            petrolPumpAddress.setText(model.getAddress());
            distance.setText("Distance : " + df.format(model.getDistance()/1000) + " KM");
            ratingBar.setRating(Float.parseFloat(model.getRating()));

            if (model.getPetrol_pump_name().contains("HP")
                    || model.getPetrol_pump_name().contains("HP Petrol Pump")
                    || model.getPetrol_pump_name().contains("Hindustan")
                    || model.getPetrol_pump_name().contains("Hindustance Petroleum")
                    || model.getPetrol_pump_name().contains("HP PETROL PUMP")
                    || model.getPetrol_pump_name().contains("hp")
                    || model.getPetrol_pump_name().contains("hindustan")) {
                petrolPumpImage.setImageResource(R.drawable.ic_hindustan_petroleum);
            } else if (model.getPetrol_pump_name().contains("Indian Oil")
                    || model.getPetrol_pump_name().contains("Indian Oil Petrol Pump")
                    || model.getPetrol_pump_name().contains("Indian")
                    || model.getPetrol_pump_name().contains("Indian Oil Petroleum")
                    || model.getPetrol_pump_name().contains("INDIAN OIL PETROL PUMP")
                    || model.getPetrol_pump_name().contains("indian oil")
                    || model.getPetrol_pump_name().contains("indian")) {
                petrolPumpImage.setImageResource(R.drawable.ic_indian_oil);
            } else if (model.getPetrol_pump_name().contains("Bharat")
                    || model.getPetrol_pump_name().contains("Bharat Petroleum")
                    || model.getPetrol_pump_name().contains("Bharat Petrol Pump")
                    || model.getPetrol_pump_name().contains("bharat")
                    || model.getPetrol_pump_name().contains("bharat petrol pump")
                    || model.getPetrol_pump_name().contains("BHARAT PETROL PUMP")
                    || model.getPetrol_pump_name().contains("BHARAT PETROLEUM")) {
                petrolPumpImage.setImageResource(R.drawable.ic_bharat_petroleum);
            } else if (model.getPetrol_pump_name().contains("Shell")
                    || model.getPetrol_pump_name().contains("Shell Petrol Pump")
                    || model.getPetrol_pump_name().contains("Shell Petroleum")
                    || model.getPetrol_pump_name().contains("SHELL")
                    || model.getPetrol_pump_name().contains("SHELL PETROLEUM")
                    || model.getPetrol_pump_name().contains("shell")
                    || model.getPetrol_pump_name().contains("shell petroleum")) {
                petrolPumpImage.setImageResource(R.drawable.ic_shell);
            } else if (model.getPetrol_pump_name().contains("Essar")
                    || model.getPetrol_pump_name().contains("Essar Oil")
                    || model.getPetrol_pump_name().contains("Essar Petrol Pump")
                    || model.getPetrol_pump_name().contains("ESSAR")
                    || model.getPetrol_pump_name().contains("Essar Petroleum")
                    || model.getPetrol_pump_name().contains("essar")
                    || model.getPetrol_pump_name().contains("essar petroleum")) {
                petrolPumpImage.setImageResource(R.drawable.ic_essar_oil);
            } else if (model.getPetrol_pump_name().contains("Reliance")
                    || model.getPetrol_pump_name().contains("Reliance Petrol Pump")
                    || model.getPetrol_pump_name().contains("Reliance Petroleum")
                    || model.getPetrol_pump_name().contains("RELIANCE")
                    || model.getPetrol_pump_name().contains("RELIACNCE PETROL PUMP")
                    || model.getPetrol_pump_name().contains("reliance")
                    || model.getPetrol_pump_name().contains("reliance petrol pump")) {
                petrolPumpImage.setImageResource(R.drawable.ic_reliance_petroleum);
            } else {
                petrolPumpImage.setImageResource(R.drawable.ic_background_red_can);
            }
        }
    }

    // To convert vector to BitmapDescriptor
    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: Called");

        Log.d(TAG, "bitmapDescriptorFromVector: GetNearbyPlacesData Class: vectorResId = " + vectorResId);

        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        assert vectorDrawable != null;
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}
