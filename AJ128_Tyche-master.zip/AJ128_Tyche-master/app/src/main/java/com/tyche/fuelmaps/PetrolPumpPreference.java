package com.tyche.fuelmaps;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Map;

public class PetrolPumpPreference extends AppCompatActivity {

    String TAG = "Fuel Maps";
    String TAG2 = "PetrolPumpPreference Activity:";
    ArrayList<String> mSelectedItems = new ArrayList<>();
    SharedPreferences selectedItems;
    SharedPreferences.Editor selectedItemsEditor;
    Gson gson;
    String json;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petrol_pump_preference);

        Log.d(TAG, "onCreate: " + TAG2 + " Called");

        selectedItems = getSharedPreferences("PUMP_PREFERENCES", Context.MODE_PRIVATE);
        selectedItemsEditor =selectedItems.edit();
        gson = new Gson();
        json = gson.toJson(mSelectedItems);
        selectedItemsEditor.putString(getResources().getString(R.string.selected_pump_pref), json);
        selectedItemsEditor.apply();

        Button selectButton = (Button) findViewById(R.id.select);
        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "SelectButton onClick: " + TAG2 + " Button Clicked");

                getPumpPreferences();
            }
        });
    }

    private void getPumpPreferences() {

        Log.d(TAG, "getPumpPreferences: " + TAG2 + " Called");

        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.user_pump_preference_dialog);
        dialog.setCancelable(false);

        final CheckBox indianOil = (CheckBox) dialog.findViewById(R.id.indian_oil);
        final CheckBox bharatPetroleum = (CheckBox) dialog.findViewById(R.id.bharat_petroleum);
        final CheckBox hindustanPetroleum = (CheckBox) dialog.findViewById(R.id.hindustan_petroleum);
        final CheckBox reliancePetroleum = (CheckBox) dialog.findViewById(R.id.reliance_petroleum);
        final CheckBox shell = (CheckBox) dialog.findViewById(R.id.shell);
        final CheckBox essarOil = (CheckBox) dialog.findViewById(R.id.essar_oil);
        final CheckBox any = (CheckBox) dialog.findViewById(R.id.any);
        Button okButton = (Button) dialog.findViewById(R.id.ok_button);
        Button skipButton = (Button) dialog.findViewById(R.id.skip_button);
        TextView clearAll = (TextView) dialog.findViewById(R.id.clear_all);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "DialogOKButton onClick: " + TAG2 + " Button Clicked");

                if (mSelectedItems.size()>0) {

                    Log.d(TAG, "DialogOKButton onClick: " + TAG2 + " mSelectedItems > 0");

                    Log.d(TAG, "DialogOKButton onClick: " + TAG2 + " mSelectedItems = " + mSelectedItems);

                    json = gson.toJson(mSelectedItems);
                    selectedItemsEditor.putString(getResources().getString(R.string.selected_pump_pref), json);
                    selectedItemsEditor.apply();

                    Log.d(TAG, "DialogOKButton onClick: " + TAG2 + " Shared Preferences Saved");

                    dialog.dismiss();

                    Log.d(TAG, "DialogOKButton onClick: " + TAG2 + " Dialog Dismissed");

                    start();
                } else {

                    Toast.makeText(getApplicationContext(), "Please select at-least one option!", Toast.LENGTH_LONG).show();

                    Log.d(TAG, "DialogOKButton onClick: " + TAG2 + " Toast Shown: toast = Please select at-least one option!");
                }
            }
        });

        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "DialogSKIPButton onClick: " + TAG2 + " Button Clicked");

                dialog.dismiss();

                Log.d(TAG, "DialogSKIPButton onClick: " + TAG2 + " Dialog Dismissed");

                start();
            }
        });

        clearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "DialogClearAllButton onClick: " + TAG2 + " Button Clicked");

                if (mSelectedItems.size()>0) {

                    Log.d(TAG, "DialogClearAllButton onClick: " + TAG2 + " SelectedItems were = " + mSelectedItems.size());

                    indianOil.setChecked(false);
                    bharatPetroleum.setChecked(false);
                    hindustanPetroleum.setChecked(false);
                    reliancePetroleum.setChecked(false);
                    shell.setChecked(false);
                    essarOil.setChecked(false);
                    any.setChecked(false);
                } else {
                    Toast.makeText(getApplicationContext(), "No options are selected!", Toast.LENGTH_SHORT).show();

                    Log.d(TAG, "DialogClearAllButton onClick: " + TAG2 + " Toast shown: toast = No options are selected!");

                }
            }
        });

        indianOil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "IndianOilCheckBox onClick: " + TAG2 + " Clicked");

                if (indianOil.isChecked()) {

                    Log.d(TAG, "IndianOilCheckBox onClick: " + TAG2 + " isChecked");

                    if (!mSelectedItems.contains(getResources().getString(R.string.indian_oil))) {

                        mSelectedItems.add(getResources().getString(R.string.indian_oil));
                        mSelectedItems.add("indian");
                        mSelectedItems.add("Indian");

                        Log.d(TAG, "IndianOilCheckBox onClick: " + TAG2 + " ItemAdded to mSelecteditems: item = " + getResources().getString(R.string.indian_oil));
                    }
                } else {

                    Log.d(TAG, "IndianOilCheckBox onClick: " + TAG2 + " isNotChecked");

                    if (mSelectedItems.contains(getResources().getString(R.string.indian_oil))) {
                        mSelectedItems.remove(getResources().getString(R.string.indian_oil));
                        mSelectedItems.remove("indian");
                        mSelectedItems.remove("Indian");

                        Log.d(TAG, "IndianOilCheckBox onClick: " + TAG2 + " ItemRemoved from mSelecteditems: item = " + getResources().getString(R.string.indian_oil));
                    }
                }
            }
        });

        bharatPetroleum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "BharatPetroleumCheckBox onClick: " + TAG2 + " Clicked");

                if (bharatPetroleum.isChecked()) {

                    Log.d(TAG, "BharatPetroleumCheckBox onClick: " + TAG2 + " isChecked");

                    if (!mSelectedItems.contains(getResources().getString(R.string.bharat_petroleum))) {
                        mSelectedItems.add(getResources().getString(R.string.bharat_petroleum));
                        mSelectedItems.add("Bharat");
                        mSelectedItems.add("bharat");

                        Log.d(TAG, "BharatPetroleumCheckBox onClick: " + TAG2 + " Item Added to mSelectedItems: item = "  + getResources().getString(R.string.bharat_petroleum));
                    }
                } else {

                    Log.d(TAG, "BharatPetroleumCheckBox onClick: " + TAG2 + " isNotChecked");

                    if (mSelectedItems.contains(getResources().getString(R.string.bharat_petroleum))) {
                        mSelectedItems.remove(getResources().getString(R.string.bharat_petroleum));
                        mSelectedItems.remove("Bharat");
                        mSelectedItems.remove("bharat");

                        Log.d(TAG, "BharatPetroleumCheckBox onClick: " + TAG2 + " Item removed from mSelectedItems: item = "  + getResources().getString(R.string.bharat_petroleum));
                    }
                }
            }
        });

        hindustanPetroleum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "HindustanPetroleumCheckBox onClick: " + TAG2 + " Clicked");

                if (hindustanPetroleum.isChecked()) {

                    Log.d(TAG, "HindustanPetroleumCheckBox onClick: " + TAG2 + " isChecked");

                    if (!mSelectedItems.contains(getResources().getString(R.string.hindustan_petroleum))) {
                        mSelectedItems.add(getResources().getString(R.string.hindustan_petroleum));
                        mSelectedItems.add("HP");
                        mSelectedItems.add("hp");
                        mSelectedItems.add("hindustan");
                        mSelectedItems.add("Hindustan");

                        Log.d(TAG, "HindustanPetroleumCheckBox onClick: " + TAG2 + " Item Added to SelectedItems: item = " + getResources().getString(R.string.hindustan_petroleum));
                    }
                } else {

                    Log.d(TAG, "HindustanPetroleumCheckBox onClick: " + TAG2 + " isNotChecked");

                    if (mSelectedItems.contains(getResources().getString(R.string.hindustan_petroleum))) {
                        mSelectedItems.remove(getResources().getString(R.string.hindustan_petroleum));
                        mSelectedItems.remove("HP");
                        mSelectedItems.remove("hp");
                        mSelectedItems.remove("hindustan");
                        mSelectedItems.remove("Hindustan");

                        Log.d(TAG, "HindustanPetroleumCheckBox onClick: " + TAG2 + " Item removed from SelectedItems: item = " + getResources().getString(R.string.hindustan_petroleum));
                    }
                }
            }
        });

        reliancePetroleum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "ReliancePetroleumCheckBox onClick: " + TAG2 + " Clicked");

                if (reliancePetroleum.isChecked()) {

                    Log.d(TAG, "ReliancePetroleumCheckBox onClick: " + TAG2 + " isChecked");

                    if (!mSelectedItems.contains(getResources().getString(R.string.reliance_petroleum))) {
                        mSelectedItems.add(getResources().getString(R.string.reliance_petroleum));
                        mSelectedItems.add("reliance");
                        mSelectedItems.add("Reliance");

                        Log.d(TAG, "ReliancePetroleumCheckBox onClick: " + TAG2 + " Item added to Selected Items: items = " + getResources().getString(R.string.reliance_petroleum));
                    }
                } else {

                    Log.d(TAG, "ReliancePetroleumCheckBox onClick: " + TAG2 + " isNotChecked");

                    if (mSelectedItems.contains(getResources().getString(R.string.reliance_petroleum))) {
                        mSelectedItems.remove(getResources().getString(R.string.reliance_petroleum));
                        mSelectedItems.remove("reliance");
                        mSelectedItems.remove("Reliance");

                        Log.d(TAG, "ReliancePetroleumCheckBox onClick: " + TAG2 + " Item removed from Selected Items: items = " + getResources().getString(R.string.reliance_petroleum));
                    }
                }
            }
        });

        shell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "ShellPetroleumCheckBox onClick: " + TAG2 + " Clicked");

                if (shell.isChecked()) {

                    Log.d(TAG, "ShellPetroleumCheckBox onClick: " + TAG2 + " isChecked");

                    if (!mSelectedItems.contains(getResources().getString(R.string.shell))) {
                        mSelectedItems.add(getResources().getString(R.string.shell));
                        mSelectedItems.add("shell");

                        Log.d(TAG, "ShellPetroleumCheckBox onClick: " + TAG2 + " Item added to SelectedItems: item = " + getResources().getString(R.string.shell));
                    }
                } else {

                    Log.d(TAG, "ShellPetroleumCheckBox onClick: " + TAG2 + " isNotChecked");

                    if (mSelectedItems.contains(getResources().getString(R.string.shell))) {
                        mSelectedItems.remove(getResources().getString(R.string.shell));
                        mSelectedItems.remove("shell");

                        Log.d(TAG, "ShellPetroleumCheckBox onClick: " + TAG2 + " Item removed from SelectedItems: item = " + getResources().getString(R.string.shell));
                    }
                }
            }
        });

        essarOil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "EssarOilCheckBox onClick: " + TAG2 + " Clicked");

                if (essarOil.isChecked()) {

                    Log.d(TAG, "EssarOilCheckBox onClick: " + TAG2 + " isChecked");

                    if (!mSelectedItems.contains(getResources().getString(R.string.essar_oil))) {
                        mSelectedItems.add(getResources().getString(R.string.essar_oil));
                        mSelectedItems.add("Essar");
                        mSelectedItems.add("essar");

                        Log.d(TAG, "EssarOilCheckBox onClick: " + TAG2 + " Item Added to Selected Items: item = " + getResources().getString(R.string.essar_oil));
                    }
                } else {

                    Log.d(TAG, "EssarOilCheckBox onClick: " + TAG2 + " isNotChecked");

                    if (mSelectedItems.contains(getResources().getString(R.string.essar_oil))) {
                        mSelectedItems.remove(getResources().getString(R.string.essar_oil));
                        mSelectedItems.remove("Essar");
                        mSelectedItems.remove("essar");

                        Log.d(TAG, "EssarOilCheckBox onClick: " + TAG2 + " Item Removed to Selected Items: item = " + getResources().getString(R.string.essar_oil));
                    }
                }
            }
        });

        any.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "AnyCheckBox onClick: " + TAG2 + " Clicked");

                if (any.isChecked()) {
                    indianOil.setChecked(true);
                    bharatPetroleum.setChecked(true);
                    hindustanPetroleum.setChecked(true);
                    reliancePetroleum.setChecked(true);
                    shell.setChecked(true);
                    essarOil.setChecked(true);

                    if (!mSelectedItems.contains(getResources().getString(R.string.indian_oil))) {
                        mSelectedItems.add(getResources().getString(R.string.indian_oil));
                        mSelectedItems.add("indian");
                        mSelectedItems.add("Indian");
                    }
                    if (!mSelectedItems.contains(getResources().getString(R.string.bharat_petroleum))) {
                        mSelectedItems.add(getResources().getString(R.string.bharat_petroleum));
                        mSelectedItems.add("Bharat");
                        mSelectedItems.add("bharat");
                    }
                    if (!mSelectedItems.contains(getResources().getString(R.string.hindustan_petroleum))) {
                        mSelectedItems.add(getResources().getString(R.string.hindustan_petroleum));
                        mSelectedItems.add("HP");
                        mSelectedItems.add("hp");
                        mSelectedItems.add("hindustan");
                        mSelectedItems.add("Hindustan");
                    }
                    if (!mSelectedItems.contains(getResources().getString(R.string.reliance_petroleum))) {
                        mSelectedItems.add(getResources().getString(R.string.reliance_petroleum));
                        mSelectedItems.add("reliance");
                        mSelectedItems.add("Reliance");
                    }
                    if (!mSelectedItems.contains(getResources().getString(R.string.shell))) {
                        mSelectedItems.add(getResources().getString(R.string.shell));
                        mSelectedItems.add("shell");
                    }
                    if (!mSelectedItems.contains(getResources().getString(R.string.essar_oil))) {
                        mSelectedItems.add(getResources().getString(R.string.essar_oil));
                        mSelectedItems.add("Essar");
                        mSelectedItems.add("essar");
                    }

                    Log.d(TAG, "AnyCheckBox onClick: " + TAG2 + " All Items Added");

                } else {
                    indianOil.setChecked(false);
                    bharatPetroleum.setChecked(false);
                    hindustanPetroleum.setChecked(false);
                    reliancePetroleum.setChecked(false);
                    shell.setChecked(false);
                    essarOil.setChecked(false);

                    if (mSelectedItems.contains(getResources().getString(R.string.indian_oil))) {
                        mSelectedItems.remove(getResources().getString(R.string.indian_oil));
                        mSelectedItems.remove("indian");
                        mSelectedItems.remove("Indian");
                    }
                    if (mSelectedItems.contains(getResources().getString(R.string.bharat_petroleum))) {
                        mSelectedItems.remove(getResources().getString(R.string.bharat_petroleum));
                        mSelectedItems.remove("Bharat");
                        mSelectedItems.remove("bharat");
                    }
                    if (mSelectedItems.contains(getResources().getString(R.string.hindustan_petroleum))) {
                        mSelectedItems.remove(getResources().getString(R.string.hindustan_petroleum));
                        mSelectedItems.remove("HP");
                        mSelectedItems.remove("hp");
                        mSelectedItems.remove("hindustan");
                        mSelectedItems.remove("Hindustan");
                    }
                    if (mSelectedItems.contains(getResources().getString(R.string.reliance_petroleum))) {
                        mSelectedItems.remove(getResources().getString(R.string.reliance_petroleum));
                        mSelectedItems.remove("reliance");
                        mSelectedItems.remove("Reliance");
                    }
                    if (mSelectedItems.contains(getResources().getString(R.string.shell))) {
                        mSelectedItems.remove(getResources().getString(R.string.shell));
                        mSelectedItems.remove("shell");
                    }
                    if (mSelectedItems.contains(getResources().getString(R.string.essar_oil))) {
                        mSelectedItems.remove(getResources().getString(R.string.essar_oil));
                        mSelectedItems.remove("Essar");
                        mSelectedItems.remove("essar");
                    }

                    Log.d(TAG, "AnyCheckBox onClick: " + TAG2 + " All Items Removed");
                }
            }
        });

        dialog.create();
        dialog.show();

        Log.d(TAG, "getPumpPreferences: " + TAG2 + " Dialog Shown");

    }

    private void start() {

        Log.d(TAG, "start: " + TAG2 + " Called");

        Intent maps = new Intent("com.tyche.fuelmaps.maps");
        startActivity(maps);
        Log.d(TAG, "start: " + TAG2 + " Intent to maps");

        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
