package com.tyche.fuelmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
//import android.os.Parcelable;
import android.util.Log;
//import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
//import com.google.android.gms.auth.api.signin.GoogleSignInApi;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
//import com.google.android.gms.auth.api.signin.GoogleSignInResult;
//import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.squareup.picasso.Picasso;

//import java.io.OptionalDataException;

public class ProfileActivity extends AppCompatActivity {

    // Variables

        // Local
            ImageView profileImage;
            TextView userName;
            TextView userEmail;
            Button start;
            Button signOut;
            Intent login;
            Intent permissions;
            String TAG = "Fuel Maps";


        // Google
            GoogleSignInOptions gso;
            GoogleSignInClient googleSignInClient;
            GoogleSignInAccount account;
            //GoogleSignInResult result;

    // Life Cycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Log.d(TAG, "onCreate: Profile Activity");

        // Local View Elements
        profileImage = findViewById(R.id.profile_image);

        userName = findViewById(R.id.user_name);

        userEmail = findViewById(R.id.user_email);

        start = findViewById(R.id.start_button);

        signOut = findViewById(R.id.sign_out_button);

        // Google SignIn Elements
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        Log.d(TAG, "onCreate: Profile Activity: gso client build()");

        googleSignInClient = GoogleSignIn.getClient(this, gso);

        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: Profile Activity: Sign Out Button Clicked");
                signOut();
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: Profile Activity: Start Button Clicked");
                start();
            }
        });
    }

    @Override
    protected void onStart() {

        super.onStart();
        Log.d(TAG, "onStart: Profile Activity");
        account = GoogleSignIn.getLastSignedInAccount(this);
        assert account != null;
        handleSignInResult(account);

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Profile Activity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Profile Activity");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Profile Activity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy: Profile Activity");
    }

    // Local Methods

    private void start() {
        Log.d(TAG, "start: Profile Activity: Called");
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions = new Intent("com.tyche.fuelmaps.permissions");
            startActivity(permissions);
            Log.d(TAG, "start: Profile Activity: Intent LocationPermission Activity");
        } else {
            Intent maps = new Intent("com.tyche.fuelmaps.maps");
            startActivity(maps);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    }

    // Google methods

    // Sign Out user of there account
    private void signOut() {
        Log.d(TAG, "signOut: Profile Activity: Called");
        
        googleSignInClient.signOut().addOnCompleteListener(this, new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(ProfileActivity.this, "Signed Out!", Toast.LENGTH_SHORT).show();
               login = new Intent("com.tyche.fuelmaps.login");
               startActivity(login);
               overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                Log.d(TAG, "onComplete (signOut()): Profile Activity: Intent Login Activity");
            }
        });
    }

    // Display the info on profile screen
    private void handleSignInResult (GoogleSignInAccount account) {
        Log.d(TAG, "handleSignInResult: Profile Activity: Called");

        assert account != null;

        userName.setText(account.getDisplayName());

        userEmail.setText(account.getEmail());

        Picasso.get().load(account.getPhotoUrl()).placeholder(R.mipmap.ic_launcher).into(profileImage);
    }
}
