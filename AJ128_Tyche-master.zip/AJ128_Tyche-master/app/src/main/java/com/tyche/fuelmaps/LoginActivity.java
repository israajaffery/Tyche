package com.tyche.fuelmaps;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
//import android.os.Parcelable;
import android.util.Log;
import android.view.View;
//import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;

//import java.util.prefs.Preferences;

public class LoginActivity extends AppCompatActivity {

    // Variables

        // Google
            GoogleSignInOptions gso;
            GoogleSignInClient googleSignInClient;
            GoogleSignInAccount account;
            GoogleSignInResult result;

        // Local
            //Intent maps;
            Intent self;
            Intent profile;
            Intent signInIntent;
            TextView skip_but;
            ImageButton google_login_button;
            String TAG = "Fuel Maps";
            private static final int SIGN_IN = 1;
            SharedPreferences SKIP_CHECK;
            SharedPreferences.Editor SKIP_CHECK_EDITOR;
            Boolean SKIP_CHECK_VALUE;

    // Life-Cycles
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Log.d(TAG, "onCreate: LogIn Activity");

        Log.d(TAG, "onClick: OnCreate: Login Activity: SKIP VALUE: " + SKIP_CHECK_VALUE);

        // Google Sign In Variables
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, gso);

        // Google Sign In Button
        google_login_button = findViewById(R.id.google_login_button);
        // Onclick Listener for Google Sign In Button
        google_login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });

        SKIP_CHECK = getPreferences(MODE_PRIVATE);
        SKIP_CHECK_EDITOR = SKIP_CHECK.edit();

        skip_but = findViewById(R.id.skip_text_but);
        skip_but.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ApplySharedPref")
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick (Skip Button): OnCreate: Login Activity: SKIP Button Clicked");
                SKIP_CHECK_EDITOR.putBoolean(getString(R.string.SKIP_CHECK), true);
                SKIP_CHECK_EDITOR.commit();
                Log.d(TAG, "onClick (Skip Button): OnCreate: Login Activity: SKIP VALUE: " + SKIP_CHECK_VALUE);
                if (ContextCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    startlocationPermission();
                } else {
                    Intent Maps = new Intent("com.tyche.fuelmaps.maps");
                    startActivity(Maps);
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    Log.d(TAG, "onClick (Skip Button): Login Activity: Intent Maps Activity");
                }
                finish();
            }
        });

        checkSkip();

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: Login Activity");

        // Check for existing Google Sign In account
        account = GoogleSignIn.getLastSignedInAccount(this);
        updateUI(account);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Login Activity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Login Activity");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Login Activity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: Login Activity");
    }

    // Local Methods

    // Override onActivityResult for result handling
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult: Login Activity: Called");

        // Check is request code is equal to the one we sent
        if (requestCode == SIGN_IN) {
            Log.d(TAG, "onActivityResult: Login Activity: requestCode == SIGN_IN");

            // If true, get sign in result
            result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);

            // If result is successful, start next activity
            assert result != null;

            if (result.isSuccess()) {
                Log.d(TAG, "onActivityResult: Login Activity: Result Success");
                
                profile = new Intent("com.tyche.fuelmaps.profile");
                startActivity(profile);
                finish();
            }
            else {
                Log.d(TAG, "onActivityResult: Login Activity: Result Failed");
                
                Toast.makeText(this, "Login Failed!", Toast.LENGTH_LONG).show();
                self = new Intent(LoginActivity.this, LoginActivity.class);
                startActivity(self);
            }
        }
    }

    // Start Maps Activity
    private void startlocationPermission() {
        Log.d(TAG, "startlocation: Login Activity: Called");
        Intent location = new Intent("com.tyche.fuelmaps.permissions");
        startActivity(location);
        Log.d(TAG, "startMaps: Login Activity: Intent LocationPermission Activity");
    }

    // Check if user has pressed SKIP previously
    private void checkSkip() {
        // Store Skip Value
        Log.d(TAG, "checkSkip: Login Activity: called ");
        SKIP_CHECK_VALUE = SKIP_CHECK.getBoolean(getString(R.string.SKIP_CHECK), false);
        Log.d(TAG, "checkSkip: Login Activity: SKIP_VALUE: "+ SKIP_CHECK_VALUE);

        if (SKIP_CHECK_VALUE) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                startlocationPermission();
            } else {
                Intent Maps = new Intent("com.tyche.fuelmaps.maps");
                startActivity(Maps);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                Log.d(TAG, "onClick (Skip Button): Login Activity: Intent Maps Activity");
            }
        }
    }


    // Google Methods

    // Function to check is user is already logged in
    private void updateUI(GoogleSignInAccount account) {
        Log.d(TAG, "updateUI: Login Activity");
        // If user is not logged in (returns null), start this activity
        if (account == null) {
            Log.d(TAG, "updateUI: Login Acitivity: account==null");

        }
        // Else start maps activity (returns  GoogleSignInAccount object)
        else {
            Log.d(TAG, "updateUI: Login Activity: account != null");
            Intent maps = new Intent("com.tyche.fuelmaps.maps");
            startActivity(maps);
        }
    }

    // Sign In Method
    private void signIn() {
        Log.d(TAG, "signIn: Login Activity: Called");

        signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, SIGN_IN);
    }
}
