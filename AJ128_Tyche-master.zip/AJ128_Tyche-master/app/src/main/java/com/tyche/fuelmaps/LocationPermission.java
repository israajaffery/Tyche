package com.tyche.fuelmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
//import android.content.IntentSender;
//import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.icu.text.UnicodeSetSpanner;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/*import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;*/

public class LocationPermission extends AppCompatActivity {

    // Constants

        //private static final int REQUEST_CHECK_SETTINGS = 1;
        //private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
        private static final String TAG = "Fuel Maps";
        private static final int PERMISSIONS_REQUEST_ACCESS_LOCATION = 1;
        //private static final int PERMISSIONS_REQUEST_ACCESS_BACKGROUND_LOCATION = 101;
        private static final int PERMISSIONS_REQUEST_ENABLE_GPS = 9002;

        // Variables
        private boolean locationPermissionGranted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_permission);

        Log.d(TAG, "onCreate: Location Permission Activity");

        Button allow = findViewById(R.id.allow_button);
        allow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: Location Permission Activity: Allow Button Clicked!");
                check();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Location Permission Activity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Location Permission Activity");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Location Permission Activity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: Location Permission Activity");
    }

    // To get location Permission
    private void getLocationPermission() {
        Log.d(TAG, "getLocationPermission: LocationPermission Activity: Called");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_BACKGROUND_LOCATION};

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "getLocationPermission: LocationPermission Activity: Location Permissions FINE Not Satisfied.");
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "getLocationPermission: LocationPermission Activity: All Location Permissions Not Satisfied.");
                ActivityCompat.requestPermissions(this,
                        permissions,
                        PERMISSIONS_REQUEST_ACCESS_LOCATION);
            } else {
                Log.d(TAG, "getLocationPermission: LocationPermission Activity: Location Permissions BACKGROUND Satisfied.");
                change();
                start();
            }
        } else {
            Log.d(TAG, "getLocationPermission: LocationPermission Activity: Location FINE Satisfied.");
            ActivityCompat.requestPermissions(this,
                    permissions,
                    PERMISSIONS_REQUEST_ACCESS_LOCATION);
        }
    }

    // To check user response to getLocationPermission
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult: LocationPermission Activity: (Response to getLocationPermission)Called");
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_LOCATION: {
                if (grantResults.length > 0 &&
                        grantResults[0]
                                + grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "onRequestPermissionsResult: LocationPermission Activity: (Response to getLocationPermission) All Location Permission Granted");
                    change();
                    start();
                } else {
                    Log.d(TAG, "onRequestPermissionsResult: LocationPermission Activity: (Response to getLocationPermission) Permission Not Granted");
                    permissionNotGranted();
                    //Toast.makeText(this, "Permission Not Granted!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // Start Activity
    protected void start() {
        Log.d(TAG, "start: LocationPermission Activity: Called!");
        Intent preferences = new Intent("com.tyche.fuelmaps.preferences");
        startActivity(preferences);
        Log.d(TAG, "start: LocationPermission Activity: Intent MapsActivity!");
        //overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    // Change locationpermissiongranted value
    private void change() {
        Log.d(TAG, "change: LocationPermission Activity: Called!");
        locationPermissionGranted = true;
        Log.d(TAG, "change: LocationPermission Activity: locationPermissionGranted = " + true);
    }

    // Check location permission value
    private void check() {
        Log.d(TAG, "check: LocationPermission Activity: Called!");
        if (locationPermissionGranted) {
            Log.d(TAG, "check: LocationPermission Activity: locationPermissionGranted = " + true);
            start();
        } else {
            Log.d(TAG, "check: LocationPermission Activity: locationPermissionGranted = " + false);
            getLocationPermission();
        }
    }

    // Permission Not granted
    private void permissionNotGranted() {
        Log.d(TAG, "permissionNotGranted: LocationPermission Activity: Called");
        if(ActivityCompat.shouldShowRequestPermissionRationale(LocationPermission.this, Manifest.permission.ACCESS_FINE_LOCATION)
                || ActivityCompat.shouldShowRequestPermissionRationale(LocationPermission.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(LocationPermission.this);
            builder.setMessage(" Please allow the Location Permission for background location as the app needs to track you properly! Press select [Allow all the time]");
            builder.setTitle("Permission Not Granted!");
            builder.setCancelable(false);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    getLocationPermission();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    moveTaskToBack(true);
                }
            });
            builder.create();
            builder.show();
            Log.d(TAG, "permissionNotGranted: LocationPermission Activity: Dialog Shown");
        } else {
            Log.d(TAG, "permissionNotGranted: LocationPermission Activity: Asking Permission Manually");
        }
    }
}
